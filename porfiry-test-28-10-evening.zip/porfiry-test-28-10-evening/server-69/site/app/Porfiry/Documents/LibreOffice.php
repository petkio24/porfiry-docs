<?php

namespace App\Porfiry\Documents;

use Illuminate\Contracts\Process\ProcessResult;
use Illuminate\Process\Exceptions\ProcessTimedOutException;
use Illuminate\Support\Facades\Process;
use RuntimeException;

/** Перевод документа в другой формат через LibreOffice без окон, со своим профилем на вызов. */
final class LibreOffice
{
    /** soffice.bin создал новый профиль и просит перезапуск (обычно это делает запускатель soffice). */
    private const RESTART = 81;

    public function __construct(private string $binary, private int $timeout = 120)
    {
    }

    /** @return string путь к результату в $outdir */
    public function convert(string $file, string $target, string $outdir): string
    {
        $ext = explode(':', $target)[0];
        $result = $this->run($file, $target, $outdir);
        if ($result->exitCode() === self::RESTART) {
            $result = $this->run($file, $target, $outdir);
        }

        $out = $outdir . '/' . pathinfo($file, PATHINFO_FILENAME) . '.' . $ext;
        if (! $result->successful() || ! is_file($out) || filesize($out) === 0) {
            $why = self::reason($result->errorOutput() . "\n" . $result->output());

            throw new RuntimeException('LibreOffice не смог сделать ' . strtoupper($ext) . ($why !== '' ? ": {$why}" : ''));
        }

        return $out;
    }

    private function run(string $file, string $target, string $outdir): ProcessResult
    {
        try {
            // Свой профиль: параллельные вызовы не мешают друг другу, у www-data нет домашней папки.
            // Без экрана: на Astra LibreOffice собран с Qt и иначе ищет X-сервер («plugin xcb»).
            return Process::timeout($this->timeout)->env([
                'HOME' => $outdir,
                'XDG_RUNTIME_DIR' => $outdir,
                'SAL_USE_VCLPLUGIN' => 'svp',
                'QT_QPA_PLATFORM' => 'offscreen',
            ])->run([
                $this->program(), '--headless', '--norestore', '--nologo', '--nolockcheck',
                '-env:UserInstallation=file://' . str_replace('\\', '/', $outdir) . '/lo-profile',
                '--convert-to', $target, '--outdir', $outdir, $file,
            ]);
        } catch (ProcessTimedOutException) {
            throw new RuntimeException("LibreOffice не успел за {$this->timeout} с");
        }
    }

    /** Запускатель program/soffice на Astra сам ставит SAL_USE_VCLPLUGIN=kf5 поверх svp — берём soffice.bin рядом. */
    private function program(): string
    {
        $real = realpath($this->binary);
        if ($real === false || basename($real) !== 'soffice') {
            return $this->binary;
        }
        $bin = dirname($real) . DIRECTORY_SEPARATOR . 'soffice.bin';

        return is_file($bin) ? $bin : $this->binary;
    }

    /** Последние строки вывода без шума Astra (java, Qt): там настоящая причина. */
    private static function reason(string $log): string
    {
        $lines = array_filter(array_map('trim', explode("\n", $log)), fn (string $line) => $line !== ''
            && ! preg_match('/javaldx|java may not function|QStandardPaths|XDG_RUNTIME_DIR/i', $line));

        return mb_substr(implode(' | ', array_slice($lines, -3)), -300);
    }
}
