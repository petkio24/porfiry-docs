#!/bin/bash
# porfiry-check: ресурсы сервера «Порфирия» — выводы вместо цифр.
SUM=""
say() {
  echo "$1  $2: $3"
  case "$1" in ВНИМАНИЕ|ПРОБЛЕМА) SUM="$SUM $2";; esac
}
gt() { awk -v a="$1" -v b="$2" 'BEGIN{exit !(a > b)}'; }
mem() { awk -v k="$1" '$1 == k":" {print int($2/1024)}' /proc/meminfo; }

C=$(nproc); L=$(cut -d' ' -f1 /proc/loadavg)
if ! grep -qw avx2 /proc/cpuinfo; then
  say ПРОБЛЕМА ПРОЦЕССОР "$C ядер, нет AVX2 — модель очень медленная"
elif [ "$C" -lt 4 ]; then
  say ВНИМАНИЕ ПРОЦЕССОР "$C ядра, AVX2 есть — ядер мало"
else
  say OK ПРОЦЕССОР "$C ядер, AVX2 есть"
fi
if gt "$L" "$((C * 3 / 2))"; then
  say ПРОБЛЕМА НАГРУЗКА "$L при $C ядрах — процессор перегружен"
elif gt "$L" "$C"; then
  say ВНИМАНИЕ НАГРУЗКА "$L при $C ядрах — на пределе"
else
  say OK НАГРУЗКА "$L при $C ядрах"
fi

MT=$(mem MemTotal); MA=$(mem MemAvailable)
if [ "$MA" -lt 1500 ]; then
  say ПРОБЛЕМА ПАМЯТЬ "свободно $MA из $MT МБ — критически мало"
elif [ "$MA" -lt 3000 ]; then
  say ВНИМАНИЕ ПАМЯТЬ "свободно $MA из $MT МБ — мало"
else
  say OK ПАМЯТЬ "свободно $MA из $MT МБ"
fi
SU=$(( $(mem SwapTotal) - $(mem SwapFree) ))
if [ "$SU" -gt 500 ]; then
  say ВНИМАНИЕ ПОДКАЧКА "занято $SU МБ — памяти не хватает"
else
  say OK ПОДКАЧКА "занято $SU МБ"
fi

for m in $(df -P / /var /usr /home /tmp 2>/dev/null | awk 'NR>1{print $6}' | sort -u); do
  u=$(df -P "$m" | awk 'NR==2{print int($5)}')
  if [ "$u" -ge 95 ]; then
    say ПРОБЛЕМА ДИСК "$m занят на $u% — нет места"
  elif [ "$u" -ge 85 ]; then
    say ВНИМАНИЕ ДИСК "$m занят на $u%"
  else
    say OK ДИСК "$m занят на $u%"
  fi
done

K=$( { dmesg -T; journalctl -k --since "-7 days" --no-pager; } 2>/dev/null )
K=$(echo "$K" | grep -oiE 'killed process [0-9]+ \([^)]+\)' | tail -1)
if [ -n "$K" ]; then
  say ПРОБЛЕМА УБИЙСТВА "ядро убивало процессы из-за памяти: $K"
else
  say OK УБИЙСТВА "ядро процессы не убивало"
fi

if [ "$(systemctl is-active ollama)" = active ]; then
  R=$(ps -C llama-server -o rss= | awk '{s+=$1} END{printf "%.1f", s/1048576}')
  say OK OLLAMA "служба работает, модель в памяти: $R ГБ"
else
  say ПРОБЛЕМА OLLAMA "служба не запущена"
fi
X=$(ps -eo user=,args= | grep "ollama serve" | grep -v grep | grep -vc '^ollama ')
if [ "$X" -gt 0 ]; then
  say ВНИМАНИЕ OLLAMA "ручных запусков ollama serve: $X — остановите их"
fi
U=/etc/systemd/system/ollama.service
S=$(grep -oE '(NUM_PARALLEL|CACHE_RAM)=[0-9]+' "$U" 2>/dev/null | tr '\n' ' ')
say ИНФО НАСТРОЙКИ "${S:-не найдены}"
say ИНФО FTP "vsftpd: $(systemctl is-active vsftpd)"
T=$(ps -eo rss=,comm= | awk '{a[$2]+=$1} END{for (k in a) print int(a[k]/1024), k}')
T=$(echo "$T" | sort -rn | head -3 | awk '{printf "%s %s МБ; ", $2, $1}')
say ИНФО ТОП-ПАМЯТЬ "$T"
T=$(ps -eo pcpu=,comm= --sort=-pcpu | head -3 | awk '{printf "%s %s%%; ", $2, $1}')
say ИНФО ТОП-ЦП "$T"
echo "ИТОГ:${SUM:- проблем с ресурсами не видно}"
