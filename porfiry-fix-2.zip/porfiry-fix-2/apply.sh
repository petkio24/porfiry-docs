#!/bin/bash
# Ставит исправление 2: копия старых файлов, новые файлы, кэши, перезапуск.
# Запуск: sudo bash apply.sh /путь/к/сайту
HERE=$(cd "$(dirname "$0")" && pwd)
SITE=$(cd "$1" 2>/dev/null && pwd)
CTL=app/Http/Controllers/ChatController.php
TST=tests/Feature/ChatTest.php

if [ "$(id -u)" != 0 ]; then
  echo "ОШИБКА: запустите через sudo"; exit 1
fi
if [ ! -f "$SITE/artisan" ]; then
  echo "ОШИБКА: в «$1» нет artisan — укажите путь к сайту"; exit 1
fi
if ! php -l "$HERE/site/$CTL" > /dev/null; then
  echo "ОШИБКА: файл контроллера в архиве повреждён — распакуйте заново"; exit 1
fi

# Повторный запуск не должен затирать копию старых файлов копией новых.
if cmp -s "$HERE/site/$CTL" "$SITE/$CTL"; then
  BAK=$(ls -d "$HERE"/backup-* 2>/dev/null | head -1)
  echo "OK  исправление уже стоит, копия старых файлов: ${BAK:-нет}"
else
  BAK="$HERE/backup-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$BAK"
  cp -p "$SITE/$CTL" "$BAK/ChatController.php"
  if [ -f "$SITE/$TST" ]; then
    cp -p "$SITE/$TST" "$BAK/ChatTest.php"
  fi
  echo "OK  копия старых файлов: $BAK"
fi

cp "$HERE/site/$CTL" "$SITE/$CTL"
if [ -d "$SITE/tests/Feature" ]; then
  cp "$HERE/site/$TST" "$SITE/$TST"
fi
echo "OK  новый контроллер и тест на месте"

cd "$SITE" || exit 1
chown -R www-data:www-data storage bootstrap/cache
FAIL=0
for c in config:cache cache:clear; do
  if ! OUT=$(sudo -u www-data php artisan "$c" 2>&1); then
    echo "ОШИБКА: php artisan $c"; echo "$OUT" | tail -3; FAIL=1
  fi
done
if [ "$FAIL" = 0 ]; then echo "OK  права и кэши"; fi

FAIL=0
for s in ollama apache2; do
  if ! systemctl restart "$s"; then
    echo "ОШИБКА: не перезапустилась служба $s"; FAIL=1
  fi
done
if systemctl cat php8.1-fpm > /dev/null 2>&1; then
  if ! systemctl restart php8.1-fpm; then
    echo "ОШИБКА: не перезапустилась служба php8.1-fpm"; FAIL=1
  fi
fi
if [ "$FAIL" = 0 ]; then echo "OK  службы перезапущены"; fi

echo ""
echo "Проверка:"
echo "sudo php $HERE/porfiry-selfcheck.php $SITE http://127.0.0.1"
echo "Откат, если понадобится:"
echo "sudo bash $HERE/rollback.sh $SITE $BAK"
