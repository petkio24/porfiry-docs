<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\Cache\Lock;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;
use Psr\Http\Message\StreamInterface;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Throwable;

class ChatController extends Controller
{
    // Предел длины одного сообщения истории (ответы с кодом бывают длинными).
    private const MAX_HISTORY_MESSAGE_CHARS = 20000;

    // Сколько сообщений браузер может прислать; лишнее сервер всё равно обрежет.
    private const MAX_REQUEST_MESSAGES = 100;

    public function index()
    {
        // В браузер уходят название, лимит и адрес; роли (system) — на сервере.
        $chats = [];
        foreach (config('llm.chats') as $key => $chat) {
            $chats[$key] = [
                'title' => $chat['title'],
                'maxInput' => $chat['max_input'],
                'url' => route('chat.send', $key),
            ];
        }

        return view('chat', [
            'chats' => $chats,
            'historyLimit' => config('llm.history.max_messages'),
        ]);
    }

    public function send(
        Request $request,
        string $type
    ): JsonResponse|StreamedResponse {
        $chats = config('llm.chats');
        abort_unless(isset($chats[$type]), 404);
        $chat = $chats[$type];

        $messages = $this->validatedMessages($request, $chat['max_input']);
        $messages = $this->trimHistory($messages);

        $userLock = Cache::lock(
            'llm:session:' . $request->session()->getId(),
            config('llm.queue.lock_seconds')
        );
        if (! $userLock->get()) {
            return $this->fail('Дождитесь ответа на предыдущий вопрос.', 429);
        }

        $slotLock = $this->acquireSlot();
        if ($slotLock === null) {
            $userLock->release();

            return $this->fail('Сервер занят, попробуйте через минуту.', 503);
        }

        $release = function () use ($userLock, $slotLock) {
            $slotLock->release();
            $userLock->release();
        };

        set_time_limit(config('llm.response_timeout') + 30);

        try {
            $body = $this->openOllamaStream($chat, $messages);
        } catch (Throwable $e) {
            $release();
            $this->trace("{$type}: Ollama недоступна: " . $e->getMessage());

            return $this->fail(
                'Модель сейчас недоступна. '
                . 'Попробуйте позже или сообщите администратору.',
                503
            );
        }

        return response()->stream(
            fn () => $this->relay($body, $release, $type),
            200,
            [
                'Content-Type' => 'application/x-ndjson; charset=UTF-8',
                'Cache-Control' => 'no-cache',
                'X-Accel-Buffering' => 'no',
            ]
        );
    }

    /** @return array<int, array{role: string, content: string}> */
    private function validatedMessages(Request $request, int $maxInput): array
    {
        $max = self::MAX_REQUEST_MESSAGES;
        $data = $request->validate([
            'messages' => ['required', 'array', 'min:1', 'max:' . $max],
            'messages.*.role' => ['required', 'string', 'in:user,assistant'],
            'messages.*.content' => [
                'required', 'string', 'max:' . self::MAX_HISTORY_MESSAGE_CHARS,
            ],
        ]);

        $messages = array_map(
            fn (array $m) => ['role' => $m['role'], 'content' => $m['content']],
            array_values($data['messages'])
        );

        $last = end($messages);
        if ($last['role'] !== 'user') {
            throw ValidationException::withMessages([
                'messages' => 'Последнее сообщение должно быть '
                    . 'вопросом пользователя.',
            ]);
        }
        if (mb_strlen($last['content']) > $maxInput) {
            throw ValidationException::withMessages([
                'messages' => "Вопрос длиннее {$maxInput} символов.",
            ]);
        }

        return $messages;
    }

    /** Оставляет последние сообщения в пределах лимитов; вопрос остаётся всегда. */
    private function trimHistory(array $messages): array
    {
        $kept = array_slice($messages, -config('llm.history.max_messages'));
        $maxChars = config('llm.history.max_chars');

        while (count($kept) > 1 && $this->totalChars($kept) > $maxChars) {
            $kept = array_slice($kept, 1);
        }

        return $kept;
    }

    private function totalChars(array $messages): int
    {
        return array_sum(array_map(fn ($m) => mb_strlen($m['content']), $messages));
    }

    private function acquireSlot(): ?Lock
    {
        $seconds = config('llm.queue.lock_seconds');

        for ($i = 0; $i < config('llm.queue.slots'); $i++) {
            $lock = Cache::lock("llm:slot:{$i}", $seconds);
            if ($lock->get()) {
                return $lock;
            }
        }

        return null;
    }

    private function openOllamaStream(array $chat, array $messages): StreamInterface
    {
        $url = rtrim(config('llm.ollama_url'), '/') . '/api/chat';
        $system = ['role' => 'system', 'content' => $chat['system']];

        $response = Http::connectTimeout(config('llm.connect_timeout'))
            ->timeout(config('llm.response_timeout'))
            ->withOptions(['stream' => true])
            ->post($url, [
                'model' => $chat['model'],
                'stream' => true,
                'messages' => [$system, ...$messages],
                'options' => [
                    'temperature' => $chat['temperature'],
                    'num_ctx' => $chat['num_ctx'],
                    'num_predict' => $chat['num_predict'],
                ],
            ]);

        if ($response->failed()) {
            $text = mb_substr($response->body(), 0, 500);
            throw new \RuntimeException("HTTP {$response->status()}: {$text}");
        }

        return $response->toPsrResponse()->getBody();
    }

    /**
     * Пересылает NDJSON Ollama в браузер строками {"t": "..."},
     * в конце — {"done": true} или {"error": "..."}.
     */
    private function relay(
        StreamInterface $body,
        callable $release,
        string $type
    ): void {
        // Вкладку закрыли — дорабатываем сами, чтобы снять блокировки.
        ignore_user_abort(true);
        $buffer = '';
        $pieces = 0;
        $lostAt = 0;
        $started = microtime(true);
        $reason = 'поток Ollama кончился без признака done';

        try {
            while (! $body->eof()) {
                // По одному байту: на read(8192) http-обёртка PHP ждёт полные
                // 8 КБ, и текст шёл бы в браузер рывками, а не по словам.
                $buffer .= $body->read(1);

                while (($pos = strpos($buffer, "\n")) !== false) {
                    $line = trim(substr($buffer, 0, $pos));
                    $buffer = substr($buffer, $pos + 1);
                    if ($line === '') {
                        continue;
                    }

                    $chunk = json_decode($line, true);
                    if (isset($chunk['error'])) {
                        $reason = 'ошибка Ollama: ' . $chunk['error'];
                        $this->emit([
                            'error' => 'Модель вернула ошибку. Попробуйте ещё раз.',
                        ]);

                        return;
                    }
                    if (($chunk['message']['content'] ?? '') !== '') {
                        $this->emit(['t' => $chunk['message']['content']]);
                        $pieces++;
                        // Обрыв связи с браузером только отмечаем, ответ не
                        // прерываем: так в журнале видно, доходят ли куски.
                        // Брошенный ответ доработает до LLM_NUM_PREDICT токенов.
                        if ($lostAt === 0 && connection_aborted()) {
                            $lostAt = $pieces;
                        }
                    }
                    if (! empty($chunk['done'])) {
                        $reason = 'done (' . ($chunk['done_reason'] ?? '?') . ')'
                            . $this->speed($chunk);
                        $this->emit(['done' => true]);

                        return;
                    }
                }
            }
        } catch (Throwable $e) {
            $reason = 'исключение: ' . $e->getMessage();
            $this->emit(['error' => 'Ответ прервался. Попробуйте ещё раз.']);
        } finally {
            // Закрытие соединения с Ollama останавливает генерацию.
            $body->close();
            $release();
            $link = 'связь цела';
            if ($lostAt > 0) {
                $link = "PHP видит обрыв связи после куска {$lostAt}";
            }
            $sec = microtime(true) - $started;
            $this->trace(sprintf(
                '%s: %s; кусков %d; %s; %.1f с',
                $type, $reason, $pieces, $link, $sec
            ));
        }
    }

    /** Скорость Ollama из последней строки потока, токенов в секунду. */
    private function speed(array $chunk): string
    {
        $rate = function (string $count, string $time) use ($chunk): string {
            $n = $chunk[$count] ?? 0;
            $ns = $chunk[$time] ?? 0;

            $perSec = $ns > 0 ? $n * 1e9 / $ns : 0;

            return sprintf('%d ток. (%.1f ток/с)', $n, $perSec);
        };

        return '; вопрос ' . $rate('prompt_eval_count', 'prompt_eval_duration')
            . '; ответ ' . $rate('eval_count', 'eval_duration');
    }

    /** Чем кончился ответ — в storage/logs/porfiry.log. Текст вопросов не пишем. */
    private function trace(string $text): void
    {
        $text = preg_replace('/\s+/u', ' ', $text);
        $line = date('Y-m-d H:i:s') . ' ' . $text . "\n";
        $file = storage_path('logs/porfiry.log');
        if (@file_put_contents($file, $line, FILE_APPEND | LOCK_EX) === false) {
            error_log('PORFIRY ' . $line);
        }
    }

    private function emit(array $payload): void
    {
        echo json_encode($payload, JSON_UNESCAPED_UNICODE) . "\n";
        if (ob_get_level() > 0) {
            ob_flush();
        }
        flush();
    }

    private function fail(string $message, int $status): JsonResponse
    {
        return response()->json(['message' => $message], $status);
    }
}
