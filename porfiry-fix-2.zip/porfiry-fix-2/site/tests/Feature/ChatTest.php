<?php

namespace Tests\Feature;

use GuzzleHttp\Psr7\FnStream;
use GuzzleHttp\Psr7\Utils;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Request as HttpRequest;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class ChatTest extends TestCase
{
    private const OLLAMA = 'http://127.0.0.1:11434/api/chat';

    // Сессия с известным id, чтобы проверять блокировку «один ответ на сессию».
    private const SESSION_ID = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';

    protected function setUp(): void
    {
        parent::setUp();
        config(['cache.default' => 'file']);
        // Заглушка Ollama ждёт этот адрес, а в .env рабочего ПК может стоять localhost.
        config(['llm.ollama_url' => 'http://127.0.0.1:11434']);
        Cache::flush();
    }

    private function ollamaLines(array $chunks): string
    {
        return implode("\n", array_map(fn ($c) => json_encode($c, JSON_UNESCAPED_UNICODE), $chunks)) . "\n";
    }

    private function fakeOllamaAnswer(string ...$pieces): void
    {
        $chunks = array_map(fn ($p) => ['message' => ['role' => 'assistant', 'content' => $p], 'done' => false], $pieces);
        $chunks[] = ['message' => ['role' => 'assistant', 'content' => ''], 'done' => true];
        Http::fake([self::OLLAMA => Http::response($this->ollamaLines($chunks), 200)]);
    }

    private function ask(string $type, array $messages)
    {
        // withCredentials: без него postJson не передаёт cookie (браузерный fetch на свой сайт — передаёт).
        return $this->withCredentials()
            ->withCookie(config('session.cookie'), self::SESSION_ID)
            ->postJson("/chat/{$type}", ['messages' => $messages]);
    }

    private function question(string $text = 'Привет'): array
    {
        return [['role' => 'user', 'content' => $text]];
    }

    public function test_page_shows_tabs_without_system_prompts(): void
    {
        $response = $this->get('/chat');

        $response->assertOk();
        $response->assertSee('Порфирий');
        $response->assertSee('Научный');
        $response->assertSee('Программирование');
        $response->assertDontSee('Ты — консультант по физике');
    }

    public function test_unknown_chat_type_returns_404(): void
    {
        $this->ask('nope', $this->question())->assertNotFound();
        $this->ask('general.model', $this->question())->assertNotFound();
    }

    public function test_rejects_invalid_messages(): void
    {
        $this->ask('general', [])->assertStatus(422);
        $this->ask('general', [['role' => 'system', 'content' => 'взлом']])->assertStatus(422);
        $this->ask('general', [['role' => 'assistant', 'content' => 'я ответ']])->assertStatus(422);
        $this->ask('general', $this->question(str_repeat('я', 4001)))->assertStatus(422);
    }

    public function test_code_chat_accepts_longer_question(): void
    {
        $this->fakeOllamaAnswer('ok');

        $this->ask('code', $this->question(str_repeat('x', 12000)))->assertOk();
    }

    public function test_streams_answer_as_ndjson(): void
    {
        $this->fakeOllamaAnswer('При', 'вет!');

        $response = $this->ask('general', $this->question());

        $response->assertOk();
        $response->assertHeader('Content-Type', 'application/x-ndjson; charset=UTF-8');
        $this->assertSame("{\"t\":\"При\"}\n{\"t\":\"вет!\"}\n{\"done\":true}\n", $response->streamedContent());
    }

    public function test_writes_how_answer_ended_to_porfiry_log(): void
    {
        // По этой строке на сервере видно, где обрывается ответ: в Ollama, в PHP или в связи.
        $log = storage_path('logs/porfiry.log');
        @unlink($log);
        Http::fake([self::OLLAMA => Http::response($this->ollamaLines([
            ['message' => ['content' => 'При'], 'done' => false],
            ['message' => ['content' => 'вет'], 'done' => false],
            ['message' => ['content' => ''], 'done' => true, 'done_reason' => 'stop',
                'eval_count' => 20, 'eval_duration' => 4_000_000_000],
        ]), 200)]);

        $this->ask('general', $this->question())->streamedContent();

        $text = file_get_contents($log);
        @unlink($log);
        $this->assertStringContainsString('general: done (stop)', $text);
        $this->assertStringContainsString('ответ 20 ток. (5.0 ток/с); кусков 2; связь цела', $text);
        $this->assertStringNotContainsString('Привет', $text);
    }

    public function test_sends_each_piece_before_ollama_sends_the_next(): void
    {
        // Поток Ollama как http-обёртка PHP: read(n) ждёт, пока придут все n байт или конец ответа.
        $arriving = [
            $this->ollamaLines([['message' => ['role' => 'assistant', 'content' => 'При'], 'done' => false]]),
            $this->ollamaLines([['message' => ['role' => 'assistant', 'content' => 'вет'], 'done' => false]]),
            $this->ollamaLines([['done' => true]]),
        ];
        $received = '';
        $sent = '';
        $sentBeforeEachArrival = [];
        $socket = FnStream::decorate(Utils::streamFor(''), [
            'read' => function (int $length) use (&$arriving, &$received, &$sent, &$sentBeforeEachArrival) {
                while (strlen($received) < $length && $arriving !== []) {
                    $sentBeforeEachArrival[] = $sent;
                    $received .= array_shift($arriving);
                }
                $out = substr($received, 0, $length);
                $received = substr($received, strlen($out));

                return $out;
            },
            'eof' => fn () => $arriving === [] && $received === '',
        ]);
        Http::fake([self::OLLAMA => Http::response($socket)]);

        $response = $this->ask('general', $this->question());
        ob_start(function (string $chunk) use (&$sent) {
            $sent .= $chunk;

            return '';
        });
        $response->baseResponse->sendContent();
        ob_end_clean();

        // Каждый кусок уходит в браузер до того, как Ollama пришлёт следующий, — без накопления.
        $this->assertSame(['', "{\"t\":\"При\"}\n", "{\"t\":\"При\"}\n{\"t\":\"вет\"}\n"], $sentBeforeEachArrival);
    }

    public function test_sends_system_prompt_and_options_of_chat(): void
    {
        $this->fakeOllamaAnswer('ok');

        $this->ask('science', $this->question('Что такое нейтрон?'))->streamedContent();

        Http::assertSent(function (HttpRequest $request) {
            $data = $request->data();

            return $data['model'] === config('llm.chats.science.model')
                && $data['stream'] === true
                && $data['messages'][0]['role'] === 'system'
                && str_contains($data['messages'][0]['content'], 'ядерную физику')
                && $data['messages'][1] === ['role' => 'user', 'content' => 'Что такое нейтрон?']
                && $data['options']['temperature'] === 0.3;
        });
    }

    public function test_sends_context_and_answer_limits_from_config(): void
    {
        config(['llm.chats.general.num_ctx' => 4096, 'llm.chats.general.num_predict' => 1000]);
        $this->fakeOllamaAnswer('ok');

        $this->ask('general', $this->question())->streamedContent();

        Http::assertSent(fn (HttpRequest $r) => $r->data()['options']['num_ctx'] === 4096
            && $r->data()['options']['num_predict'] === 1000);
    }

    public function test_queue_lock_outlives_response_timeout(): void
    {
        // Иначе место в очереди освободится посреди ещё идущего ответа.
        $this->assertGreaterThan(config('llm.response_timeout'), config('llm.queue.lock_seconds'));
    }

    public function test_empty_env_values_fall_back_to_defaults(): void
    {
        // Пустая строка в .env (LLM_NUM_PREDICT=) давала 0 — Ollama отвечала одним токеном, «одной буквой».
        $keys = ['LLM_RESPONSE_TIMEOUT', 'LLM_HISTORY_MAX_CHARS', 'LLM_QUEUE_SLOTS', 'LLM_NUM_CTX', 'LLM_NUM_PREDICT'];
        $saved = array_intersect_key($_SERVER, array_flip($keys));
        try {
            foreach ($keys as $key) {
                $_SERVER[$key] = '';
            }
            $llm = require config_path('llm.php');
        } finally {
            $_SERVER = array_diff_key($_SERVER, array_flip($keys)) + $saved;
        }

        $this->assertSame(600, $llm['response_timeout']);
        $this->assertSame(610, $llm['queue']['lock_seconds']);
        $this->assertSame(12000, $llm['history']['max_chars']);
        $this->assertSame(20, $llm['queue']['slots']);
        $this->assertSame([8192, 8192, 16384], array_column($llm['chats'], 'num_ctx'));
        $this->assertSame([2048, 3072, 4096], array_column($llm['chats'], 'num_predict'));
    }

    public function test_trims_history_keeping_last_question(): void
    {
        $this->fakeOllamaAnswer('ok');
        $messages = [];
        for ($i = 0; $i < 30; $i++) {
            $messages[] = ['role' => $i % 2 ? 'assistant' : 'user', 'content' => "сообщение {$i}"];
        }
        $messages[] = ['role' => 'user', 'content' => 'последний вопрос'];

        $this->ask('general', $messages)->streamedContent();

        Http::assertSent(function (HttpRequest $request) {
            $sent = $request->data()['messages'];

            return count($sent) === 1 + config('llm.history.max_messages')
                && end($sent)['content'] === 'последний вопрос';
        });
    }

    public function test_trims_history_by_total_length(): void
    {
        // Лимит задан явно: в .env сервера бывает другой (LLM_HISTORY_MAX_CHARS=6000).
        config(['llm.history.max_chars' => 12000]);
        $this->fakeOllamaAnswer('ok');
        $long = str_repeat('a', 5000);
        $messages = [
            ['role' => 'user', 'content' => $long],
            ['role' => 'assistant', 'content' => $long],
            ['role' => 'user', 'content' => $long],
            ['role' => 'assistant', 'content' => $long],
            ['role' => 'user', 'content' => 'вопрос'],
        ];

        $this->ask('general', $messages)->streamedContent();

        Http::assertSent(fn (HttpRequest $r) => count($r->data()['messages']) === 1 + 3);
    }

    public function test_reports_unavailable_ollama_and_releases_locks(): void
    {
        $isDown = true;
        Http::fake([self::OLLAMA => function () use (&$isDown) {
            if ($isDown) {
                throw new ConnectionException('Connection refused');
            }

            return Http::response($this->ollamaLines([['message' => ['content' => 'ok'], 'done' => true]]), 200);
        }]);

        $this->ask('general', $this->question())
            ->assertStatus(503)
            ->assertJson(['message' => 'Модель сейчас недоступна. Попробуйте позже или сообщите администратору.']);

        $isDown = false;
        $this->ask('general', $this->question())->assertOk();
    }

    public function test_reports_missing_model(): void
    {
        Http::fake([self::OLLAMA => Http::response(['error' => "model 'qwen-main' not found"], 404)]);

        $this->ask('general', $this->question())->assertStatus(503);
    }

    public function test_passes_ollama_stream_error_to_browser(): void
    {
        Http::fake([self::OLLAMA => Http::response($this->ollamaLines([
            ['message' => ['role' => 'assistant', 'content' => 'Нача'], 'done' => false],
            ['error' => 'out of memory'],
        ]), 200)]);

        $content = $this->ask('general', $this->question())->streamedContent();

        $this->assertStringContainsString('{"t":"Нача"}', $content);
        $this->assertStringContainsString('{"error":"Модель вернула ошибку. Попробуйте ещё раз."}', $content);
        $this->assertStringNotContainsString('out of memory', $content);
    }

    public function test_one_answer_at_a_time_per_session(): void
    {
        Cache::lock('llm:session:' . self::SESSION_ID, 60)->get();

        $this->ask('general', $this->question())
            ->assertStatus(429)
            ->assertJson(['message' => 'Дождитесь ответа на предыдущий вопрос.']);
    }

    public function test_busy_when_all_slots_taken(): void
    {
        config(['llm.queue.slots' => 1]);
        Cache::lock('llm:slot:0', 60)->get();

        $this->ask('general', $this->question())
            ->assertStatus(503)
            ->assertJson(['message' => 'Сервер занят, попробуйте через минуту.']);

        // Место сессии освобождено — после освобождения слота вопрос проходит.
        Cache::lock('llm:slot:0')->forceRelease();
        $this->fakeOllamaAnswer('ok');
        $this->ask('general', $this->question())->assertOk();
    }

    public function test_releases_locks_after_answer(): void
    {
        config(['llm.queue.slots' => 1]);
        $this->fakeOllamaAnswer('ok');

        $this->ask('general', $this->question())->streamedContent();

        $this->assertTrue(Cache::lock('llm:session:' . self::SESSION_ID, 1)->get());
        $this->assertTrue(Cache::lock('llm:slot:0', 1)->get());
    }
}
