#!/bin/bash
# Возвращает файлы, которые apply.sh сохранил в папку backup-….
# Запуск: sudo bash rollback.sh /путь/к/сайту /путь/к/backup-…
SITE=$(cd "$1" 2>/dev/null && pwd)
BAK=$(cd "$2" 2>/dev/null && pwd)

if [ "$(id -u)" != 0 ]; then
  echo "ОШИБКА: запустите через sudo"; exit 1
fi
if [ ! -f "$SITE/artisan" ] || [ ! -f "$BAK/ChatController.php" ]; then
  echo "ОШИБКА: укажите путь к сайту и папку backup-…"; exit 1
fi

cp "$BAK/ChatController.php" "$SITE/app/Http/Controllers/ChatController.php"
if [ -f "$BAK/ChatTest.php" ]; then
  cp "$BAK/ChatTest.php" "$SITE/tests/Feature/ChatTest.php"
fi
cd "$SITE" || exit 1
echo "OK  старые файлы возвращены из $BAK"
if ! OUT=$(sudo -u www-data php artisan config:cache 2>&1); then
  echo "ОШИБКА: php artisan config:cache"; echo "$OUT" | tail -3
fi
systemctl restart apache2 || echo "ОШИБКА: не перезапустилась служба apache2"
if systemctl cat php8.1-fpm > /dev/null 2>&1; then
  systemctl restart php8.1-fpm || echo "ОШИБКА: не перезапустилась служба php8.1-fpm"
fi
