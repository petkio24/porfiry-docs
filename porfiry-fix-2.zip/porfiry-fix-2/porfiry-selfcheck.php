<?php
// porfiry-selfcheck: Ollama напрямую, чат через Apache и журнал сайта.
// Запуск: sudo php ~/porfiry-selfcheck.php "$SITE" http://127.0.0.1
$site = rtrim($argv[1] ?? '', '/');
$base = rtrim($argv[2] ?? 'http://127.0.0.1', '/');
$question = 'Ответь одним коротким предложением: что такое атом?';
$sum = [];

function say($level, $label, $text)
{
    global $sum;
    echo "{$level}  {$label}: {$text}\n";
    if ($level === 'ПРОБЛЕМА' || $level === 'ВНИМАНИЕ') {
        $sum[] = $label;
    }
}

// POST и чтение потока NDJSON: на каждую строку зовёт $onLine.
function post($url, $body, $headers, $onLine)
{
    $ctx = stream_context_create(['http' => [
        'method' => 'POST',
        'header' => implode("\r\n", $headers),
        'content' => $body,
        'timeout' => 900,
        'ignore_errors' => true,
    ]]);
    $start = microtime(true);
    $fp = @fopen($url, 'r', false, $ctx);
    if ($fp === false) {
        return [0, error_get_last()['message'] ?? 'нет связи', 0];
    }
    preg_match('/ (\d{3})/', $http_response_header[0] ?? '', $m);
    $code = (int) ($m[1] ?? 0);
    if ($code !== 200) {
        $text = stream_get_contents($fp);
        fclose($fp);
        return [$code, $text, 0];
    }
    while (($line = fgets($fp)) !== false) {
        $data = json_decode(trim($line), true);
        if (is_array($data)) {
            $onLine($data, microtime(true) - $start);
        }
    }
    $late = stream_get_meta_data($fp)['timed_out'] ? 'ожидание вышло' : '';
    fclose($fp);
    return [200, $late, microtime(true) - $start];
}

function rate($d, $count, $time)
{
    $ns = $d[$time] ?? 0;
    return $ns > 0 ? ($d[$count] ?? 0) * 1e9 / $ns : 0;
}

function short($text)
{
    $text = json_decode($text, true)['message'] ?? $text;
    $text = preg_replace('/\s+/u', ' ', strip_tags($text));
    return preg_replace('/^(.{0,160}).*$/us', '$1', trim($text));
}

if ($site === '' || ! is_file("{$site}/artisan")) {
    say('ПРОБЛЕМА', 'ПУТЬ', "в «{$site}» нет artisan — укажите путь к сайту");
    exit(1);
}
$ctl = "{$site}/app/Http/Controllers/ChatController.php";
$ctl = (string) @file_get_contents($ctl);
if (strpos($ctl, 'porfiry.log') === false) {
    say('ПРОБЛЕМА', 'КОНТРОЛЛЕР', 'старая версия — сначала замените файл');
} else {
    say('OK', 'КОНТРОЛЛЕР', 'новая версия на месте');
}

$env = [];
foreach (@file("{$site}/.env") ?: [] as $line) {
    if (preg_match('/^\s*(LLM_[A-Z_]+)\s*=\s*"?([^"\s]*)/', $line, $m)) {
        $env[$m[1]] = $m[2];
    }
}
$ollama = rtrim($env['LLM_OLLAMA_URL'] ?? '', '/') ?: 'http://127.0.0.1:11434';
$model = ($env['LLM_MODEL_GENERAL'] ?? '') ?: 'qwen-main';
$numCtx = (int) ($env['LLM_NUM_CTX'] ?? 0) ?: 8192;
$predict = (int) ($env['LLM_NUM_PREDICT'] ?? 0) ?: 2048;
say('ИНФО', 'НАСТРОЙКИ', "{$model}, num_ctx {$numCtx}, num_predict {$predict}");

echo "...жду ответ Ollama напрямую, до 15 минут\n";
$pieces = 0;
$first = 0;
$last = [];
$body = json_encode([
    'model' => $model,
    'stream' => true,
    'messages' => [['role' => 'user', 'content' => $question]],
    'options' => ['num_ctx' => $numCtx, 'num_predict' => 60],
], JSON_UNESCAPED_UNICODE);
$onLine = function ($d, $t) use (&$pieces, &$first, &$last) {
    if (($d['message']['content'] ?? '') !== '') {
        $pieces++;
        $first = $first ?: $t;
    }
    $last = $d;
};
[$code, $err] = post("{$ollama}/api/chat", $body, [
    'Content-Type: application/json',
], $onLine);
if ($code !== 200) {
    say('ПРОБЛЕМА', 'OLLAMA', "не отвечает ({$code}): " . short($err));
} elseif (empty($last['done'])) {
    say('ПРОБЛЕМА', 'OLLAMA', "поток оборвался, кусков {$pieces} {$err}");
} else {
    $gen = rate($last, 'eval_count', 'eval_duration');
    $read = rate($last, 'prompt_eval_count', 'prompt_eval_duration');
    $min = $predict / max($gen, 0.1) / 60;
    $text = sprintf('кусков %d, первый через %.0f с', $pieces, $first);
    say('OK', 'OLLAMA', $text);
    $level = $gen < 2 ? 'ПРОБЛЕМА' : ($gen < 5 ? 'ВНИМАНИЕ' : 'OK');
    say($level, 'СКОРОСТЬ', sprintf(
        'пишет %.1f ток/с, читает %.1f ток/с; ответ в %d ток. ≈ %.0f мин',
        $gen, $read, $predict, $min
    ));
}

$ctx = ['http' => ['timeout' => 60, 'ignore_errors' => true]];
$ctx = stream_context_create($ctx);
$page = @file_get_contents("{$base}/chat", false, $ctx);
$cookies = [];
foreach ($http_response_header ?? [] as $h) {
    if (preg_match('/^Set-Cookie:\s*([^=;]+=[^;]*)/i', $h, $m)) {
        $cookies[] = $m[1];
    }
}
preg_match('/name="csrf-token" content="([^"]+)"/', (string) $page, $m);
$token = $m[1] ?? '';
$sPieces = 0;
$sFirst = 0;
$done = false;
$sErr = '';
$started = time();
if ($token === '') {
    say('ПРОБЛЕМА', 'САЙТ', "{$base}/chat не открылась или нет CSRF-токена");
} else {
    echo "...жду ответ чата через Apache, до 15 минут\n";
    $body = json_encode([
        'messages' => [['role' => 'user', 'content' => $question]],
    ], JSON_UNESCAPED_UNICODE);
    $onLine = function ($d, $t) use (&$sPieces, &$sFirst, &$done, &$sErr) {
        if (isset($d['t'])) {
            $sPieces++;
            $sFirst = $sFirst ?: $t;
        }
        $done = $done || ! empty($d['done']);
        $sErr = $d['error'] ?? $sErr;
    };
    [$code, $err, $total] = post("{$base}/chat/general", $body, [
        'Content-Type: application/json',
        'Accept: application/json',
        'X-CSRF-TOKEN: ' . $token,
        'Cookie: ' . implode('; ', $cookies),
    ], $onLine);
    if ($code !== 200) {
        say('ПРОБЛЕМА', 'ЧАТ', "сайт ответил {$code}: " . short($err));
    } elseif ($done && $sPieces > 1) {
        say('OK', 'ЧАТ', sprintf(
            'ответ дошёл целиком: кусков %d, первый через %.0f с, всего %.0f с',
            $sPieces, $sFirst, $total
        ));
    } else {
        $why = ", без конца ответа {$err}";
        if ($sErr !== '') {
            $why = ", ошибка «{$sErr}»";
        }
        say('ПРОБЛЕМА', 'ЧАТ', "ответ оборвался: кусков {$sPieces}{$why}");
    }
}

$log = "{$site}/storage/logs/porfiry.log";
$trace = '';
foreach (@file($log) ?: [] as $line) {
    $trace = trim($line);
}
clearstatcache();
$fresh = $trace !== '' && filemtime($log) >= $started - 2;
foreach (['/var/log/apache2/error.log', '/var/log/php8.1-fpm.log'] as $f) {
    foreach ($fresh ? [] : (@file($f) ?: []) as $line) {
        if (($at = strpos($line, 'PORFIRY ')) !== false) {
            $trace = trim(substr($line, $at + 8)) . ' (журнал веб-сервера)';
        }
    }
}
say('ИНФО', 'ЖУРНАЛ', $trace ?: 'нет записей');

if ($token !== '' && ! ($done && $sPieces > 1)) {
    $sent = preg_match('/кусков (\d+)/u', $trace, $m) ? (int) $m[1] : 0;
    if (! $fresh) {
        $cause = 'PHP не дописал журнал: смотрите error.log Apache и PHP-FPM';
    } elseif (strpos($trace, 'обрыв связи') !== false || $sent > $sPieces) {
        $cause = "PHP отправил кусков {$sent}, дошло {$sPieces}: рвёт Apache";
    } elseif (strpos($trace, 'done (length)') !== false) {
        $cause = 'модель упёрлась в лимит длины: LLM_NUM_PREDICT или num_ctx';
    } elseif (strpos($trace, 'без признака done') !== false) {
        $cause = 'PHP перестал получать поток от Ollama';
    } else {
        $cause = 'смотрите строку ЖУРНАЛ выше';
    }
    say('ПРОБЛЕМА', 'ПРИЧИНА', $cause);
}
echo 'ИТОГ: ' . ($sum ? implode(' ', $sum) : 'чат работает') . "\n";
