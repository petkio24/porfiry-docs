Исправление 2 для чата «Порфирий». Подробно — porfiry-fix-2.pdf.

Из этой папки:

  SITE=/путь/к/сайту
  sudo bash apply.sh "$SITE"
  sudo php porfiry-selfcheck.php "$SITE" http://127.0.0.1

Файлы:
  apply.sh               ставит исправление (копия старых файлов, кэши, перезапуск)
  rollback.sh            откат: команду печатает apply.sh
  porfiry-selfcheck.php  проверка чата: печатает ИТОГ и ПРИЧИНУ
  porfiry-check.sh       проверка ресурсов сервера (как в диагностике 2)
  site/                  новые файлы сайта: контроллер и тест
