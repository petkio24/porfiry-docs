<?php

namespace App\Http\Controllers;

use App\Porfiry\Chat\Cancellation;
use App\Porfiry\Chat\CurlStream;
use App\Porfiry\Chat\IpLimit;
use App\Porfiry\Chat\Ndjson;
use App\Porfiry\Chat\OllamaRelay;
use App\Porfiry\Chat\SlotQueue;
use App\Porfiry\Chat\Store;
use App\Porfiry\Chat\Trace;
use App\Porfiry\Documents\FillPrompt;
use App\Porfiry\Kb\Index;
use Illuminate\Cache\Repository;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Closure;
use Throwable;

class ChatController extends Controller
{
    // Ошибки, которые видит пользователь: код → текст.
    private const ERRORS = [
        'replaced' => 'Ответ прерван: задан новый вопрос.',
        'cancelled' => 'Ответ остановлен.',
        'gone' => 'Ответ остановлен: страница закрыта.',
        'queue' => 'Очередь переполнена или ожидание слишком долгое. Попробуйте через несколько минут.',
        'timeout' => 'Модель не ответила вовремя. Попробуйте ещё раз.',
        'backend' => 'Сервер модели недоступен. Попробуйте позже или сообщите администратору.',
        'model' => 'Модель вернула ошибку. Попробуйте ещё раз.',
        'cut' => 'Ответ прервался. Попробуйте ещё раз.',
        'ip' => 'Слишком много одновременных вопросов с вашего компьютера. Дождитесь ответа или нажмите «Стоп».',
        'storage' => 'Чат временно недоступен: на сервере нет места или нет прав на запись. Сообщите администратору.',
    ];

    public function index()
    {
        // В браузер — только то, что нужно странице. Адреса моделей и системные роли
        // остаются на сервере.
        $chats = [];
        foreach (config('llm.chats') as $key => $chat) {
            $chats[$key] = [
                'title' => $chat['title'],
                'maxInput' => $chat['max_input'],
                'url' => route('chat.send', $key, false),
                'greeting' => $chat['greeting'],
                'examples' => $chat['examples'],
                'accent' => $chat['accent'],
            ];
        }

        $docs = [
            'templatesUrl' => route('chat.templates', [], false),
            'renderUrl' => route('chat.document', [], false),
        ];

        // Настройки страницы — одной переменной: @json режет выражение по запятым.
        return view('chat', [
            'chats' => $chats,
            'docs' => $docs,
            'pageConfig' => [
                'chats' => $chats,
                'historyLimit' => config('llm.history.max_messages'),
                'cancelUrl' => route('chat.cancel', [], false),
                'docs' => $docs,
            ],
        ]);
    }

    public function send(Request $request, string $type): JsonResponse|StreamedResponse
    {
        $chat = config("llm.chats.{$type}");
        abort_unless(is_array($chat), 404);

        $data = $request->validate([
            'rid' => ['required', 'string', 'regex:/\A[0-9a-f]{32}\z/'],
            'messages' => ['required', 'array', 'min:1', 'max:' . (config('llm.history.max_messages') + 1)],
            'messages.*.role' => ['required', 'string', 'in:user,assistant'],
            // Предел на сообщение: длинные ответы ассистента ниже обрезаются, а не отклоняются.
            'messages.*.content' => ['present', 'nullable', 'string', 'max:100000'],
            // Заполнить поля шаблона документа (только офисный чат).
            'template' => ['sometimes', 'nullable', 'string', 'max:255'],
        ]);
        $messages = $this->trimHistory($this->cleanMessages($data['messages'], $chat['max_input']));

        $template = null;
        if (($data['template'] ?? null) !== null) {
            $template = $type === 'office' ? DocumentController::repo()->find($data['template']) : null;
            if ($template === null) {
                return response()->json(['message' => 'Шаблон не найден — обновите страницу.'], 422);
            }
        }

        try {
            $store = Store::get();
            $ipLimit = new IpLimit($store, $type, (string) $request->ip());
            // Лимит адреса — до вытеснения: отказанный вопрос не должен обрывать живой ответ.
            if (! $ipLimit->enter($data['rid'])) {
                return response()->json(['message' => self::ERRORS['ip']], 429);
            }
            $cancellation = new Cancellation($store, $request->session()->getId(), $type, $data['rid']);
            $cancellation->begin();
        } catch (Throwable $e) {
            // Кэш чата не пишется (нет места, нет прав) — сразу понятный отказ, а не 500.
            Trace::write("chat={$type} rid=" . substr($data['rid'], 0, 8) . ' end=storage detail=' . get_class($e));

            return response()->json(['message' => self::ERRORS['storage']], 503);
        }

        return response()->stream(
            fn () => $this->answer($type, $chat, $messages, $template, $data['rid'], $cancellation, $ipLimit, $store),
            200,
            [
                'Content-Type' => 'application/x-ndjson; charset=UTF-8',
                'Cache-Control' => 'no-cache',
                'X-Accel-Buffering' => 'no',
            ]
        );
    }

    /** «Стоп» ({rid}) и пульс открытой страницы ({rid, alive: 1}). */
    public function cancel(Request $request): Response
    {
        $data = $request->validate(['rid' => ['required', 'string', 'regex:/\A[0-9a-f]{32}\z/']]);
        $sid = $request->session()->getId();

        if ($request->boolean('alive')) {
            Cancellation::ping(Store::get(), $sid, $data['rid']);
        } else {
            Cancellation::cancel(Store::get(), $sid, $data['rid']);
        }

        return response()->noContent();
    }

    private function answer(string $type, array $chat, array $messages, ?array $template, string $rid, Cancellation $cancellation, IpLimit $ipLimit, Repository $store): void
    {
        // Вкладку закрыли — дорабатываем сами, чтобы снять места в очереди.
        // connection_aborted() не используем: на Astra он срабатывал ложно.
        ignore_user_abort(true);
        set_time_limit(config('llm.queue.max_wait') + config('llm.answer_timeout') + 60);

        $t = ['start' => microtime(true), 'slot' => null, 'first' => null];
        $queue = new SlotQueue($store, $type, $chat['slots']);
        $relay = new OllamaRelay(fn (array $event) => Ndjson::emit($event));
        $end = 'error';
        $detail = '';
        // Сердцебиение места в очереди и счётчика адреса — из тика и из прихода данных
        // (если браузер читает медленно, тики cURL редеют, а место не должно истечь).
        $beatAt = 0.0;
        $beat = function () use ($queue, $ipLimit, $rid, &$beatAt): void {
            $now = microtime(true);
            if ($now - $beatAt >= config('llm.queue.heartbeat')) {
                $queue->heartbeat($rid);
                $ipLimit->beat($rid);
                $beatAt = $now;
            }
        };

        try {
            // Документ — поля по схеме; обычный вопрос офиса — с найденными пунктами ГОСТов.
            $body = match (true) {
                $template !== null => FillPrompt::body($chat, $messages, $template),
                $type === 'office' => OllamaRelay::body($chat, $this->withDocuments($messages)),
                default => OllamaRelay::body($chat, $messages),
            };
            $end = $this->waitForSlot($queue, $rid, $cancellation, $beat) ?? $cancellation->check() ?? 'go';
            if ($end !== 'go') {
                $this->fail($end);

                return;
            }
            $t['slot'] = microtime(true);
            Ndjson::emit(['s' => 'model']);

            $result = $this->stream($chat['url'], $body, $cancellation, $relay, $beat, $t);
            [$end, $detail] = $this->outcome($result, $relay);
            if ($end === 'done') {
                // Модель упёрлась в num_predict — ответ обрезан, браузер это пометит.
                Ndjson::emit($relay->doneReason === 'length' ? ['done' => true, 'cut' => 'length'] : ['done' => true]);
            } else {
                $this->fail($end);
            }
        } catch (Throwable $e) {
            $end = 'exception';
            $detail = get_class($e) . ': ' . mb_substr($e->getMessage(), 0, 300);
            $this->fail('backend');
        } finally {
            // Каждый шаг уборки отдельно: сбой одного не должен оставить остальные.
            foreach ([
                fn () => $queue->release($rid),
                fn () => $queue->leave($rid),
                fn () => $ipLimit->leave($rid),
                fn () => $cancellation->finish(),
            ] as $cleanup) {
                try {
                    $cleanup();
                } catch (Throwable $e) {
                    $detail .= ' cleanup=' . get_class($e);
                }
            }
            $this->trace($type, $rid, $end, $detail, $t, $relay);
        }
    }

    /** null — место получено; иначе причина отказа (queue, cancelled, replaced, gone). */
    private function waitForSlot(SlotQueue $queue, string $rid, Cancellation $cancellation, Closure $beat): ?string
    {
        $shown = [];
        $shownAt = 0.0;
        $reason = $queue->acquire($rid, function (int $position) use (&$shown, &$shownAt, $queue, $cancellation, $beat): ?string {
            $beat();
            // Место и сколько впереди (идущие ответы + ждущие раньше) — при смене
            // и не реже раза в 10 с (поток не молчит).
            $state = ['q' => $position, 'ahead' => $queue->busy() + $position - 1];
            if ($state !== $shown || microtime(true) - $shownAt >= 10) {
                Ndjson::emit($state);
                $shown = $state;
                $shownAt = microtime(true);
            }

            return $cancellation->check();
        });

        return $reason === 'timeout' ? 'queue' : $reason;
    }

    private function stream(string $url, array $body, Cancellation $cancellation, OllamaRelay $relay, Closure $beat, array &$t): array
    {
        $lineAt = microtime(true);

        $result = app(CurlStream::class)->post(
            rtrim($url, '/') . '/api/chat',
            $body,
            function (string $data) use ($relay, $beat, &$lineAt, &$t): void {
                $t['first'] ??= microtime(true);
                $lineAt = microtime(true);
                $relay->feed($data);
                $beat();
            },
            function () use ($cancellation, $beat, &$lineAt): ?string {
                $now = microtime(true);
                $beat();
                // Пока модель читает вопрос, поток молчит: строка-«пульс», чтобы его не
                // оборвали Apache или браузер (Firefox ждёт ответа не дольше 300 с).
                if ($now - $lineAt >= config('llm.queue.keepalive')) {
                    Ndjson::emit(['w' => 1]);
                    $lineAt = $now;
                }

                return $cancellation->check();
            },
            (int) config('llm.answer_timeout')
        );
        $relay->finish();

        return $result;
    }

    /**
     * Найденные пункты ГОСТов — в последний вопрос (в историю браузера они не попадают),
     * их список — браузеру событием {"kb": [...]}. Нет индекса или совпадений — вопрос как есть.
     */
    private function withDocuments(array $messages): array
    {
        $last = count($messages) - 1;
        $question = $messages[$last]['content'];
        try {
            $hits = (new Index((string) config('llm.kb.index_path')))->search($this->kbQuery($messages), (int) config('llm.kb.top'));
        } catch (Throwable $e) {
            Trace::write('chat=office kb=error detail=' . get_class($e) . ': ' . mb_substr($e->getMessage(), 0, 200));

            return $messages;
        }

        $block = '';
        $sources = [];
        $budget = (int) config('llm.kb.max_context_chars');
        foreach ($hits as $i => $hit) {
            $text = mb_substr($hit['text'], 0, $budget);
            if ($text === '') {
                break;
            }
            $budget -= mb_strlen($text);
            $sources[] = ['n' => $i + 1, 'doc' => $hit['doc'], 'clause' => $hit['clause']];
            $block .= '[' . ($i + 1) . "] {$hit['doc']}" . ($hit['clause'] !== '' ? ", п. {$hit['clause']}" : '') . "\n{$text}\n\n";
        }
        if ($sources === []) {
            return $messages;
        }

        Ndjson::emit(['kb' => $sources]);
        $messages[$last]['content'] = "ДОКУМЕНТЫ:\n{$block}КОНЕЦ ДОКУМЕНТОВ\n\nВОПРОС: {$question}";

        return $messages;
    }

    /** Короткий уточняющий вопрос («а для приказа?») ищется вместе с предыдущим. */
    private function kbQuery(array $messages): string
    {
        $users = array_values(array_filter($messages, fn (array $m) => $m['role'] === 'user'));
        $query = end($users)['content'];
        if (mb_strlen($query) < 80 && count($users) > 1) {
            $query .= "\n" . $users[count($users) - 2]['content'];
        }

        return $query;
    }

    /** @return array{0: string, 1: string} итог (done или код ошибки) и подробность для журнала */
    private function outcome(array $result, OllamaRelay $relay): array
    {
        if ($relay->error !== null) {
            return ['model', mb_substr($relay->error, 0, 300)];
        }
        if ($result['ok']) {
            return $relay->sawDone ? ['done', ''] : ['cut', ''];
        }

        $reason = $result['reason'];
        $detail = trim("errno={$result['errno']} http={$result['http']} " . mb_substr((string) $result['error'], 0, 300));

        return match ($reason) {
            'cancelled', 'replaced', 'gone' => [$reason, ''],
            'ttft', 'stall', 'timeout' => ['timeout', $reason],
            default => ['backend', $reason . ' ' . $detail],
        };
    }

    private function fail(string $code): void
    {
        Ndjson::emit(['error' => self::ERRORS[$code] ?? self::ERRORS['backend'], 'code' => array_key_exists($code, self::ERRORS) ? $code : 'backend']);
    }

    private function trace(string $type, string $rid, string $end, string $detail, array $t, OllamaRelay $relay): void
    {
        $now = microtime(true);
        $line = sprintf(
            'chat=%s rid=%s end=%s wait=%.1f ttft=%s dur=%.1f pieces=%d %s bad=%d',
            $type,
            substr($rid, 0, 8),
            $end,
            ($t['slot'] ?? $now) - $t['start'],
            $t['first'] && $t['slot'] ? sprintf('%.1f', $t['first'] - $t['slot']) : '-',
            $now - $t['start'],
            $relay->pieces,
            Trace::speed($relay->final),
            $relay->bad
        );
        Trace::write($detail === '' ? $line : $line . ' detail=' . $detail);
    }

    /**
     * Ответы ассистента не отклоняются: длинные обрезаются, пустые выбрасываются
     * (иначе один такой ответ навсегда ломал бы чат кодом 422).
     */
    private function cleanMessages(array $raw, int $maxInput): array
    {
        $limit = (int) config('llm.history.max_message_chars');
        $messages = [];
        foreach (array_values($raw) as $m) {
            $content = mb_substr((string) ($m['content'] ?? ''), 0, $limit);
            if (trim($content) !== '') {
                $messages[] = ['role' => $m['role'], 'content' => $content];
            }
        }

        $last = end($raw);
        if ($last['role'] !== 'user' || trim((string) ($last['content'] ?? '')) === '') {
            throw ValidationException::withMessages(['messages' => 'Последнее сообщение должно быть вопросом пользователя.']);
        }
        if (mb_strlen((string) $last['content']) > $maxInput) {
            throw ValidationException::withMessages(['messages' => "Вопрос длиннее {$maxInput} символов."]);
        }

        return $messages;
    }

    /** Последние сообщения в пределах лимитов; вопрос остаётся всегда. */
    private function trimHistory(array $messages): array
    {
        $kept = array_slice($messages, -config('llm.history.max_messages'));
        $maxChars = config('llm.history.max_chars');

        while (count($kept) > 1 && array_sum(array_map(fn ($m) => mb_strlen($m['content']), $kept)) > $maxChars) {
            $kept = array_slice($kept, 1);
        }

        return $kept;
    }
}
