<?php

namespace Tests\Feature;

use App\Porfiry\Chat\Cancellation;
use App\Porfiry\Chat\CurlStream;
use App\Porfiry\Chat\Store;
use Illuminate\Support\Sleep;
use Tests\Porfiry\FakeCurlStream;
use Tests\Porfiry\UsesTempStore;
use Tests\TestCase;

class ChatTest extends TestCase
{
    use UsesTempStore;

    private const OFFICE = 'http://office.test:11434';

    private const SCIENCE = 'http://science.test:11434';

    // Сессия с известным id: вытеснение и отмена работают в пределах сессии.
    private const SID = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';

    private const OTHER_SID = 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb';

    private ?FakeCurlStream $curl = null;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTempStore();
        config([
            'llm.chats.office.url' => self::OFFICE,
            'llm.chats.science.url' => self::SCIENCE,
            'llm.queue.max_wait' => 3,
        ]);
        Sleep::fake(true, true);
        $this->answer(['При', 'вет!']);
    }

    protected function tearDown(): void
    {
        Sleep::fake(false);
        $this->tearDownTempStore();
        parent::tearDown();
    }

    /** Ответ поддельной Ollama: куски текста и строка done. */
    private function answer(array $pieces, string $url = self::OFFICE, bool $done = true, array $more = []): void
    {
        $lines = array_map(fn ($p) => ['message' => ['role' => 'assistant', 'content' => $p], 'done' => false], $pieces);
        if ($done) {
            $lines[] = ['message' => ['content' => ''], 'done' => true, 'done_reason' => 'stop', 'eval_count' => count($pieces), 'eval_duration' => 1_000_000_000];
        }
        $plans = $this->curl ? (fn () => $this->plans)->call($this->curl) : [];
        $plans[$url] = ['lines' => $lines];
        $this->bindCurl($plans + $more);
    }

    private function bindCurl(array $plans): void
    {
        $this->curl = new FakeCurlStream($plans);
        $this->app->instance(CurlStream::class, $this->curl);
    }

    private function rid(string $c = 'a'): string
    {
        return str_repeat($c, 32);
    }

    private function ask(string $type, array $messages, ?string $rid = null, string $sid = self::SID)
    {
        return $this->withCredentials()
            ->withCookie(config('session.cookie'), $sid)
            ->postJson("/chat/{$type}", ['rid' => $rid ?? $this->rid(), 'messages' => $messages]);
    }

    private function question(string $text = 'Привет'): array
    {
        return [['role' => 'user', 'content' => $text]];
    }

    private function cancel(string $rid, string $sid = self::SID, array $extra = [])
    {
        return $this->withCredentials()
            ->withCookie(config('session.cookie'), $sid)
            ->postJson('/chat/cancel', ['rid' => $rid] + $extra);
    }

    /** @return array<int, array> строки NDJSON ответа */
    private function events($response): array
    {
        $lines = array_filter(explode("\n", $response->streamedContent()));

        return array_values(array_map(fn ($l) => json_decode($l, true), $lines));
    }

    private function errorCode(array $events): ?string
    {
        foreach ($events as $e) {
            if (isset($e['error'])) {
                return $e['code'] ?? '';
            }
        }

        return null;
    }

    public function test_page_shows_two_tabs_relative_urls_and_cancel_url(): void
    {
        $response = $this->get('/chat');

        $response->assertOk();
        $response->assertSee('Офисный');
        $response->assertSee('Научный');
        $response->assertSee('"url":"\/chat\/office"', false);
        $response->assertSee('"cancelUrl":"\/chat\/cancel"', false);
    }

    public function test_page_config_has_no_backend_urls_or_prompts(): void
    {
        $html = $this->get('/chat')->getContent();

        $this->assertStringNotContainsString('office.test', $html);
        $this->assertStringNotContainsString('научный консультант', $html);
        $this->assertStringNotContainsString('11434', $html);
    }

    public function test_unknown_chat_type_returns_404(): void
    {
        // «code» — прежнее имя научного чата, general — чат v1: обоих больше нет.
        $this->ask('code', $this->question())->assertNotFound();
        $this->ask('general', $this->question())->assertNotFound();
    }

    public function test_invalid_rid_returns_422(): void
    {
        $this->ask('office', $this->question(), 'not-a-rid')->assertStatus(422);
        $this->ask('office', $this->question(), str_repeat('A', 32))->assertStatus(422);
    }

    public function test_rejects_invalid_messages(): void
    {
        $this->ask('office', [])->assertStatus(422);
        $this->ask('office', [['role' => 'system', 'content' => 'взлом']])->assertStatus(422);
        $this->ask('office', [['role' => 'assistant', 'content' => 'я ответ']])->assertStatus(422);
        $this->ask('office', [['role' => 'user', 'content' => '   ']])->assertStatus(422);
    }

    public function test_last_question_over_max_input_rejected(): void
    {
        $this->ask('office', $this->question(str_repeat('я', 4001)))->assertStatus(422);
        $this->ask('science', $this->question(str_repeat('x', 12000)))->assertOk();
    }

    public function test_long_assistant_message_is_trimmed_not_rejected(): void
    {
        // Предел явно: в .env сервера бывает другой (LLM_HISTORY_MAX_CHARS).
        config(['llm.history.max_chars' => 24000]);
        $messages = [
            ['role' => 'user', 'content' => 'Код?'],
            ['role' => 'assistant', 'content' => str_repeat('ы', 25000)],
            ['role' => 'user', 'content' => 'Ещё'],
        ];

        $this->ask('office', $messages)->assertOk()->streamedContent();

        $sent = $this->curl->calls[0]['body']['messages'];
        $this->assertSame(20000, mb_strlen($sent[2]['content']));
    }

    public function test_blank_assistant_message_is_dropped(): void
    {
        $messages = [
            ['role' => 'user', 'content' => 'Вопрос'],
            ['role' => 'assistant', 'content' => '  '],
            ['role' => 'user', 'content' => 'Ещё'],
        ];

        $this->ask('office', $messages)->assertOk()->streamedContent();

        $roles = array_column($this->curl->calls[0]['body']['messages'], 'role');
        $this->assertSame(['system', 'user', 'user'], $roles);
    }

    public function test_streams_status_text_and_done(): void
    {
        $response = $this->ask('office', $this->question());

        $response->assertOk();
        $response->assertHeader('Content-Type', 'application/x-ndjson; charset=UTF-8');
        $this->assertSame([['s' => 'model'], ['t' => 'При'], ['t' => 'вет!'], ['done' => true]], $this->events($response));
    }

    public function test_each_chat_goes_to_its_own_server_with_its_options(): void
    {
        $this->answer(['print(1)'], self::SCIENCE);

        $this->ask('office', $this->question())->streamedContent();
        $this->ask('science', $this->question('Код'))->streamedContent();

        $this->assertStringStartsWith(self::OFFICE . '/api/chat', $this->curl->calls[0]['url']);
        $this->assertFalse($this->curl->calls[0]['body']['think']);
        $this->assertStringStartsWith(self::SCIENCE . '/api/chat', $this->curl->calls[1]['url']);
        $this->assertTrue($this->curl->calls[1]['body']['think']);
        $this->assertSame(20, $this->curl->calls[1]['body']['options']['top_k']);
        $this->assertSame('system', $this->curl->calls[1]['body']['messages'][0]['role']);
    }

    public function test_second_question_displaces_first_instead_of_429(): void
    {
        $first = $this->ask('office', $this->question('Первый'), $this->rid('a'));
        $second = $this->ask('office', $this->question('Второй'), $this->rid('b'));

        $this->assertSame('replaced', $this->errorCode($this->events($first)));
        $this->assertContains(['done' => true], $this->events($second));
        $this->assertCount(1, $this->curl->calls);
    }

    public function test_other_chat_is_not_displaced(): void
    {
        $this->answer(['ok'], self::SCIENCE);
        $office = $this->ask('office', $this->question(), $this->rid('a'));
        $this->ask('science', $this->question(), $this->rid('b'));

        $this->assertContains(['done' => true], $this->events($office));
    }

    public function test_cancel_own_rid_ends_stream_and_frees_slot(): void
    {
        config(['llm.chats.office.slots' => 1]);
        $response = $this->ask('office', $this->question(), $this->rid('a'));

        $this->cancel($this->rid('a'))->assertNoContent();

        $this->assertSame('cancelled', $this->errorCode($this->events($response)));
        $this->assertNull(Store::get()->get('llm:slot:office:0'));
        $this->assertCount(0, $this->curl->calls);
    }

    public function test_cancel_from_other_session_does_nothing(): void
    {
        $response = $this->ask('office', $this->question(), $this->rid('a'));

        $this->cancel($this->rid('a'), self::OTHER_SID)->assertNoContent();

        $this->assertContains(['done' => true], $this->events($response));
    }

    public function test_cancel_before_send_never_calls_ollama(): void
    {
        $this->cancel($this->rid('a'))->assertNoContent();

        $events = $this->events($this->ask('office', $this->question(), $this->rid('a')));

        $this->assertSame('cancelled', $this->errorCode($events));
        $this->assertCount(0, $this->curl->calls);
    }

    public function test_cancel_validates_rid(): void
    {
        $this->cancel('../../etc')->assertStatus(422);
    }

    public function test_ping_keeps_answer_alive(): void
    {
        config(['llm.queue.alive_timeout' => 150]);
        $response = $this->ask('office', $this->question(), $this->rid('a'));
        $this->travel(100)->seconds();

        $this->cancel($this->rid('a'), self::SID, ['alive' => 1])->assertNoContent();
        $this->travel(100)->seconds();

        $this->assertContains(['done' => true], $this->events($response));
    }

    public function test_answer_without_ping_is_dropped(): void
    {
        config(['llm.queue.alive_timeout' => 150]);
        $response = $this->ask('office', $this->question(), $this->rid('a'));
        $this->travel(200)->seconds();

        $this->assertSame('gone', $this->errorCode($this->events($response)));
        $this->assertCount(0, $this->curl->calls);
    }

    public function test_cancel_needs_csrf_and_accepts_form_token_for_beacon(): void
    {
        $this->app->bind(\App\Http\Middleware\VerifyCsrfToken::class, fn ($app) => new class($app, $app['encrypter']) extends \App\Http\Middleware\VerifyCsrfToken {
            protected function runningUnitTests()
            {
                return false;
            }
        });

        $this->withSession(['_token' => 'tok'])->post('/chat/cancel', ['rid' => $this->rid()])->assertStatus(419);
        $this->withSession(['_token' => 'tok'])->post('/chat/cancel', ['_token' => 'wrong', 'rid' => $this->rid()])->assertStatus(419);
        $this->withSession(['_token' => 'tok'])->post('/chat/cancel', ['_token' => 'tok', 'rid' => $this->rid()])->assertNoContent();
    }

    public function test_queue_position_when_slots_busy(): void
    {
        config(['llm.chats.office.slots' => 1]);
        Store::get()->put('llm:slot:office:0', $this->rid('z'), 60);

        $events = $this->events($this->ask('office', $this->question(), $this->rid('a')));

        // Первый в очереди, впереди один запрос — тот, на который сейчас отвечают.
        $this->assertSame(['q' => 1, 'ahead' => 1], $events[0]);
        $this->assertSame('queue', $this->errorCode($events));
        $this->assertCount(0, $this->curl->calls);
    }

    public function test_queue_full_is_reported(): void
    {
        config(['llm.chats.office.slots' => 1, 'llm.queue.max_waiting' => 0]);
        Store::get()->put('llm:slot:office:0', $this->rid('z'), 60);

        $events = $this->events($this->ask('office', $this->question(), $this->rid('a')));

        $this->assertSame('queue', $this->errorCode($events));
        $this->assertStringContainsString('Очередь', $events[0]['error']);
    }

    public function test_unreachable_backend_emits_error_line_and_frees_slot(): void
    {
        config(['llm.chats.office.slots' => 1]);
        $this->bindCurl([self::OFFICE => ['result' => ['reason' => 'connect', 'errno' => 7]]]);

        $events = $this->events($this->ask('office', $this->question()));

        $this->assertSame('backend', $this->errorCode($events));
        $this->assertNull(Store::get()->get('llm:slot:office:0'));
    }

    public function test_dead_office_backend_does_not_affect_code(): void
    {
        $this->bindCurl([self::OFFICE => ['result' => ['reason' => 'connect']]]);
        $this->answer(['ok'], self::SCIENCE);

        $this->assertSame('backend', $this->errorCode($this->events($this->ask('office', $this->question(), $this->rid('a')))));
        $this->assertContains(['done' => true], $this->events($this->ask('science', $this->question(), $this->rid('b'))));
    }

    public function test_model_timeout_is_reported(): void
    {
        $this->bindCurl([self::OFFICE => ['result' => ['reason' => 'ttft']]]);

        $this->assertSame('timeout', $this->errorCode($this->events($this->ask('office', $this->question()))));
    }

    public function test_ollama_error_line_gives_model_error(): void
    {
        $this->bindCurl([self::OFFICE => ['lines' => [['message' => ['content' => 'Нача'], 'done' => false], ['error' => 'out of memory']]]]);

        $events = $this->events($this->ask('office', $this->question()));

        $this->assertSame(['t' => 'Нача'], $events[1]);
        $this->assertSame('model', $this->errorCode($events));
        $this->assertStringNotContainsString('out of memory', json_encode($events, JSON_UNESCAPED_UNICODE));
    }

    public function test_stream_without_done_gives_cut_error(): void
    {
        $this->answer(['Обры'], self::OFFICE, false);

        $events = $this->events($this->ask('office', $this->question()));

        $this->assertSame('cut', $this->errorCode($events));
        $this->assertNotContains(['done' => true], $events);
    }

    public function test_trims_history_keeping_last_question(): void
    {
        $messages = [];
        for ($i = 0; $i < 30; $i++) {
            $messages[] = ['role' => $i % 2 ? 'assistant' : 'user', 'content' => "сообщение {$i}"];
        }
        $messages[] = ['role' => 'user', 'content' => 'последний вопрос'];

        $this->ask('office', array_slice($messages, -21))->assertOk()->streamedContent();

        $sent = $this->curl->calls[0]['body']['messages'];
        $this->assertCount(1 + config('llm.history.max_messages'), $sent);
        $this->assertSame('последний вопрос', end($sent)['content']);
    }

    public function test_trace_line_has_outcome_but_no_question_text(): void
    {
        $this->ask('office', $this->question('Секретный вопрос'), $this->rid('c'))->streamedContent();

        $trace = $this->traceText();
        $this->assertStringContainsString('chat=office', $trace);
        $this->assertStringContainsString('rid=cccccccc', $trace);
        $this->assertStringContainsString('end=done', $trace);
        $this->assertStringContainsString('eval=2@2.0t/s', $trace);
        $this->assertStringNotContainsString('Секретный', $trace);
        $this->assertStringNotContainsString('вет!', $trace);
    }

    public function test_tests_do_not_touch_site_cache_or_log(): void
    {
        $this->ask('office', $this->question())->streamedContent();

        $this->assertNotSame(storage_path('logs/porfiry.log'), config('llm.trace_log'));
        $this->assertNotSame(storage_path('framework/porfiry-cache'), config('llm.cache_path'));
        $this->assertStringContainsString('end=done', $this->traceText());
    }

    public function test_send_is_rate_limited(): void
    {
        for ($i = 0; $i < 30; $i++) {
            $this->ask('office', [])->assertStatus(422);
        }

        $this->ask('office', [])->assertStatus(429);
    }

    public function test_too_many_answers_from_one_ip_rejected_without_displacing(): void
    {
        config(['llm.queue.max_per_ip' => 1]);
        $live = $this->ask('office', $this->question('Первый'), $this->rid('a'));

        $this->ask('office', $this->question('Второй'), $this->rid('b'))
            ->assertStatus(429)
            ->assertJsonFragment(['message' => 'Слишком много одновременных вопросов с вашего компьютера. Дождитесь ответа или нажмите «Стоп».']);

        $this->assertContains(['done' => true], $this->events($live));
    }

    public function test_ip_place_is_freed_after_answer(): void
    {
        config(['llm.queue.max_per_ip' => 1]);

        $this->assertContains(['done' => true], $this->events($this->ask('office', $this->question(), $this->rid('a'))));
        $this->assertContains(['done' => true], $this->events($this->ask('office', $this->question(), $this->rid('b'))));
    }

    public function test_error_text_with_newlines_stays_one_trace_line(): void
    {
        $this->bindCurl([self::OFFICE => ['lines' => [['error' => "сбой\nchat=office end=done поддельная строка"]]]]);

        $this->ask('office', $this->question())->streamedContent();

        $this->assertCount(1, array_filter(explode("\n", $this->traceText())));
    }

    public function test_store_write_failure_fails_fast(): void
    {
        $file = $this->porfiryTmp . DIRECTORY_SEPARATOR . 'not-a-dir';
        file_put_contents($file, 'x');
        config(['llm.cache_path' => $file . DIRECTORY_SEPARATOR . 'cache']);

        $this->ask('office', $this->question())
            ->assertStatus(503)
            ->assertJsonFragment(['message' => 'Чат временно недоступен: на сервере нет места или нет прав на запись. Сообщите администратору.']);
        $this->assertCount(0, $this->curl->calls);
    }

    public function test_cancel_mid_answer_stops_stream(): void
    {
        $rid = $this->rid('a');
        $this->bindCurl([self::OFFICE => ['lines' => [
            ['message' => ['content' => 'Раз'], 'done' => false],
            function () use ($rid) {
                Cancellation::cancel(Store::get(), self::SID, $rid);
                usleep(600_000); // проверка отмены кэшируется на 0,5 с
            },
            ['message' => ['content' => 'Два'], 'done' => false],
            ['message' => ['content' => ''], 'done' => true],
        ]]]);

        $events = $this->events($this->ask('office', $this->question(), $rid));

        $this->assertSame([['s' => 'model'], ['t' => 'Раз']], array_slice($events, 0, 2));
        $this->assertSame('cancelled', $this->errorCode($events));
        $this->assertNotContains(['t' => 'Два'], $events);
        $this->assertStringContainsString('end=cancelled', $this->traceText());
    }

    public function test_new_question_mid_answer_replaces_it(): void
    {
        $this->bindCurl([self::OFFICE => ['lines' => [
            ['message' => ['content' => 'Раз'], 'done' => false],
            function () {
                (new Cancellation(Store::get(), self::SID, 'office', str_repeat('b', 32)))->begin();
                usleep(600_000);
            },
            ['message' => ['content' => 'Два'], 'done' => false],
        ]]]);

        $events = $this->events($this->ask('office', $this->question(), $this->rid('a')));

        $this->assertSame('replaced', $this->errorCode($events));
        $this->assertStringContainsString('end=replaced', $this->traceText());
    }

    public function test_heartbeat_keeps_slot_during_long_answer(): void
    {
        config(['llm.chats.office.slots' => 1, 'llm.queue.heartbeat' => 0]);
        $held = [];
        $this->bindCurl([self::OFFICE => ['lines' => [
            ['message' => ['content' => 'Раз'], 'done' => false],
            fn () => $this->travel(15)->seconds(),
            ['message' => ['content' => 'Два'], 'done' => false],
            fn () => $this->travel(15)->seconds(),
            ['message' => ['content' => 'Три'], 'done' => false],
            function () use (&$held) {
                $held[] = Store::get()->get('llm:slot:office:0');
            },
            ['message' => ['content' => ''], 'done' => true],
        ]]]);

        $this->ask('office', $this->question(), $this->rid('a'))->streamedContent();

        // 30 секунд ответа при slot_ttl 20: место живо только благодаря сердцебиению.
        $this->assertSame([$this->rid('a')], $held);
    }

    public function test_keepalive_while_model_only_thinks(): void
    {
        // Рассуждение браузеру не показывается: Ollama шлёт данные, а в браузер ничего не идёт.
        // Пульс должен идти по времени последней строки В БРАУЗЕР, иначе браузер через минуту
        // тишины обрывает ответ («Сервер перестал отвечать»).
        config(['llm.queue.keepalive' => 1]);
        $think = ['message' => ['role' => 'assistant', 'content' => '', 'thinking' => 'думаю'], 'done' => false];
        $pause = fn () => usleep(600_000);
        $this->bindCurl([self::OFFICE => ['lines' => [
            $think, $pause, $think, $pause, $think, $pause, $think,
            ['message' => ['content' => 'Ответ'], 'done' => false],
            ['message' => ['content' => ''], 'done' => true, 'done_reason' => 'stop'],
        ]]]);

        $events = $this->events($this->ask('office', $this->question()));

        $this->assertContains(['s' => 'think'], $events);
        $this->assertContains(['w' => 1], $events);
        $this->assertContains(['t' => 'Ответ'], $events);
    }

    public function test_keepalive_line_while_model_is_silent(): void
    {
        config(['llm.queue.keepalive' => 0]);

        $events = $this->events($this->ask('office', $this->question()));

        $this->assertContains(['w' => 1], $events);
    }

    public function test_answer_cut_by_length_is_marked(): void
    {
        $this->bindCurl([self::OFFICE => ['lines' => [
            ['message' => ['content' => 'Длинный код'], 'done' => false],
            ['message' => ['content' => ''], 'done' => true, 'done_reason' => 'length'],
        ]]]);

        $events = $this->events($this->ask('office', $this->question()));

        $this->assertContains(['done' => true, 'cut' => 'length'], $events);
    }

    public function test_pings_do_not_use_up_send_limit(): void
    {
        for ($i = 0; $i < 31; $i++) {
            $this->cancel($this->rid('p'), self::SID, ['alive' => 1]);
        }

        $this->ask('office', $this->question())->assertOk();
    }
}
