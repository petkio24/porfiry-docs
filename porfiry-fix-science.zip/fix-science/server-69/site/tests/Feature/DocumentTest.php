<?php

namespace Tests\Feature;

use App\Porfiry\Chat\CurlStream;
use App\Porfiry\Kb\Index;
use Illuminate\Support\Sleep;
use Tests\Porfiry\FakeCurlStream;
use Tests\Porfiry\OfficeFiles;
use Tests\Porfiry\UsesTempStore;
use Tests\TestCase;

/** Документы по шаблонам и ГОСТы в офисном чате. */
class DocumentTest extends TestCase
{
    use UsesTempStore;

    private const OFFICE = 'http://office.test:11434';

    private const SID = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';

    private FakeCurlStream $curl;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTempStore();
        config(['llm.chats.office.url' => self::OFFICE, 'llm.chats.science.url' => 'http://science.test:11434']);
        Sleep::fake(true, true);

        $dir = config('llm.docs.templates_path');
        mkdir($dir);
        OfficeFiles::docx("{$dir}/ДКП авто.docx", OfficeFiles::p('Продавец: ${Продавец}') . OfficeFiles::p('Дата: ${Дата договора}'));
        file_put_contents("{$dir}/ДКП авто.json", json_encode([
            'title' => 'Договор купли-продажи автомобиля',
            'keywords' => ['автомобил'],
            'fields' => ['Продавец' => ['label' => 'Продавец', 'hint' => 'ФИО полностью']],
        ], JSON_UNESCAPED_UNICODE));

        $this->curl = new FakeCurlStream([self::OFFICE => ['lines' => [
            ['message' => ['content' => '{"Продавец":"Иванов"}'], 'done' => false],
            ['message' => ['content' => ''], 'done' => true, 'done_reason' => 'stop'],
        ]]]);
        $this->app->instance(CurlStream::class, $this->curl);
    }

    protected function tearDown(): void
    {
        Sleep::fake(false);
        $this->tearDownTempStore();
        parent::tearDown();
    }

    private function ask(string $type, string $text, array $extra = [])
    {
        return $this->withCookie(config('session.cookie'), self::SID)->postJson("/chat/{$type}", [
            'rid' => str_repeat('a', 32),
            'messages' => [['role' => 'user', 'content' => $text]],
        ] + $extra);
    }

    private function events($response): array
    {
        return array_map(fn ($l) => json_decode($l, true), array_filter(explode("\n", $response->streamedContent())));
    }

    public function test_templates_list_with_fields_and_formats(): void
    {
        $response = $this->getJson('/chat/office/templates');

        $response->assertOk()
            ->assertJsonPath('templates.0.id', 'ДКП авто.docx')
            ->assertJsonPath('templates.0.title', 'Договор купли-продажи автомобиля')
            ->assertJsonPath('templates.0.fields.0.name', 'Продавец')
            ->assertJsonPath('templates.0.formats', ['docx']);
        $this->assertArrayNotHasKey('path', $response->json('templates.0'));
    }

    public function test_page_has_document_urls(): void
    {
        $config = $this->get('/chat')->assertOk()->viewData('docs');

        $this->assertSame('/chat/office/templates', $config['templatesUrl']);
        $this->assertSame('/chat/office/document', $config['renderUrl']);
    }

    public function test_render_returns_filled_docx_with_cyrillic_name(): void
    {
        $response = $this->postJson('/chat/office/document', [
            'template' => 'ДКП авто.docx', 'format' => 'docx', 'fields' => ['Продавец' => 'Иванов Иван'],
        ]);

        $response->assertOk();
        $this->assertStringContainsString("filename*=utf-8''", $response->headers->get('Content-Disposition'));
        $this->assertStringContainsString(rawurlencode('Договор купли-продажи автомобиля'), $response->headers->get('Content-Disposition'));
        $this->assertSame('nosniff', $response->headers->get('X-Content-Type-Options'));
        $file = config('llm.cache_path') . '-out.docx';
        file_put_contents($file, $response->getContent());
        $this->assertStringContainsString('Продавец: Иванов Иван', OfficeFiles::part($file, 'word/document.xml'));
    }

    public function test_render_unknown_template_or_path_is_404(): void
    {
        $this->postJson('/chat/office/document', ['template' => 'Нет.docx', 'format' => 'docx', 'fields' => []])->assertNotFound();
        $this->postJson('/chat/office/document', ['template' => '../ДКП авто.docx', 'format' => 'docx', 'fields' => []])->assertNotFound();
    }

    public function test_pdf_without_libreoffice_is_rejected_in_russian(): void
    {
        $response = $this->postJson('/chat/office/document', ['template' => 'ДКП авто.docx', 'format' => 'pdf', 'fields' => []]);

        $response->assertStatus(422);
        $this->assertMatchesRegularExpression('/[а-я]/u', $response->json('message'));
    }

    public function test_render_validates_input(): void
    {
        $this->postJson('/chat/office/document', ['template' => 'ДКП авто.docx', 'format' => 'exe', 'fields' => []])->assertStatus(422);
        $this->postJson('/chat/office/document', ['template' => 'ДКП авто.docx', 'format' => 'docx', 'fields' => ['Продавец' => ['массив']]])->assertStatus(422);
    }

    public function test_fill_asks_model_for_json_with_template_fields(): void
    {
        $events = $this->events($this->ask('office', 'Продаёт Иванов Иван, машина Лада', ['template' => 'ДКП авто.docx']));

        $this->assertContains(['done' => true], $events);
        $body = $this->curl->calls[0]['body'];
        $this->assertSame(['Продавец', 'Дата договора'], $body['format']['required']);
        $this->assertSame('string', $body['format']['properties']['Продавец']['type']);
        $last = end($body['messages'])['content'];
        $this->assertStringContainsString('Продаёт Иванов Иван', $last);
        $this->assertStringContainsString('ФИО полностью', $last);
        $this->assertStringContainsString('JSON', $body['messages'][0]['content']);
    }

    public function test_fill_with_unknown_template_or_in_code_chat_is_rejected(): void
    {
        $this->ask('office', 'Текст', ['template' => 'Нет.docx'])->assertStatus(422);
        $this->ask('science', 'Текст', ['template' => 'ДКП авто.docx'])->assertStatus(422);
        $this->assertSame([], $this->curl->calls);
    }

    private function gostIndex(): void
    {
        $text = "ГОСТ Р 7.0.5—2008\n4.1 Библиографическая ссылка является частью справочного аппарата документа.\n";
        (new Index(config('llm.kb.index_path')))->build([
            ['file' => 'ссылки.docx', 'code' => Index::docCode($text), 'chunks' => Index::chunks($text)],
        ]);
    }

    public function test_office_question_gets_documents_and_sources(): void
    {
        $this->gostIndex();

        $events = $this->events($this->ask('office', 'Что такое библиографическая ссылка?'));

        $kb = collect($events)->firstWhere('kb');
        $this->assertSame([['n' => 1, 'doc' => 'ГОСТ Р 7.0.5-2008', 'clause' => '4.1']], $kb['kb']);
        $last = end($this->curl->calls[0]['body']['messages'])['content'];
        $this->assertStringStartsWith('ДОКУМЕНТЫ:', $last);
        $this->assertStringContainsString('[1] ГОСТ Р 7.0.5-2008, п. 4.1', $last);
        $this->assertStringEndsWith('ВОПРОС: Что такое библиографическая ссылка?', $last);
    }

    public function test_without_index_or_match_question_is_unchanged(): void
    {
        $events = $this->events($this->ask('office', 'Что такое библиографическая ссылка?'));
        $this->gostIndex();
        $this->events($this->ask('office', 'Как дела?'));

        $this->assertNull(collect($events)->firstWhere('kb'));
        $this->assertSame('Что такое библиографическая ссылка?', end($this->curl->calls[0]['body']['messages'])['content']);
        $this->assertSame('Как дела?', end($this->curl->calls[1]['body']['messages'])['content']);
    }

    public function test_code_chat_does_not_use_documents(): void
    {
        $this->gostIndex();
        $this->curl = new FakeCurlStream(['http://science.test' => ['lines' => [['message' => ['content' => ''], 'done' => true]]]]);
        $this->app->instance(CurlStream::class, $this->curl);

        $this->events($this->ask('science', 'Что такое библиографическая ссылка?'));

        $this->assertSame('Что такое библиографическая ссылка?', end($this->curl->calls[0]['body']['messages'])['content']);
    }

    public function test_index_command_reports_each_file(): void
    {
        $dir = config('llm.kb.docs_path');
        mkdir($dir);
        file_put_contents("{$dir}/ГОСТ Р 7.0.5-2008.txt", "ГОСТ Р 7.0.5—2008\n" . str_repeat("4.1 Библиографическая ссылка содержит сведения о документе.\n", 5));
        file_put_contents("{$dir}/битый.docx", 'не архив');

        $this->artisan('porfiry:kb-index')
            ->expectsOutputToContain('OK  ГОСТ Р 7.0.5-2008.txt')
            ->expectsOutputToContain('ПРОБЛЕМА  битый.docx')
            ->expectsOutputToContain('ИТОГ')
            ->assertExitCode(0);

        $this->assertTrue((new Index(config('llm.kb.index_path')))->exists());
    }

    public function test_templates_command_lists_fields_and_problems(): void
    {
        file_put_contents(config('llm.docs.templates_path') . '/битый.docx', 'не архив');

        $this->artisan('porfiry:templates')
            ->expectsOutputToContain('ДКП авто.docx')
            ->expectsOutputToContain('Продавец')
            ->expectsOutputToContain('ПРОБЛЕМА  битый.docx')
            ->assertExitCode(1);
    }
}
