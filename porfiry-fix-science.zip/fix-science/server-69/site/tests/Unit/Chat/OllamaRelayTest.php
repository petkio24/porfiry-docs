<?php

namespace Tests\Unit\Chat;

use App\Porfiry\Chat\OllamaRelay;
use Tests\TestCase;

class OllamaRelayTest extends TestCase
{
    private array $events = [];

    private function relay(): OllamaRelay
    {
        $this->events = [];

        return new OllamaRelay(function (array $event) {
            $this->events[] = $event;
        });
    }

    private function line(array $chunk): string
    {
        return json_encode($chunk, JSON_UNESCAPED_UNICODE) . "\n";
    }

    public function test_body_has_think_false_options_and_system_first(): void
    {
        $chat = config('llm.chats.office');
        $messages = [['role' => 'user', 'content' => 'Привет']];

        $body = OllamaRelay::body($chat, $messages);

        $this->assertSame($chat['model'], $body['model']);
        $this->assertTrue($body['stream']);
        $this->assertFalse($body['think']);
        $this->assertSame(['role' => 'system', 'content' => $chat['system']], $body['messages'][0]);
        $this->assertSame(['role' => 'user', 'content' => 'Привет'], $body['messages'][1]);
        $this->assertSame($chat['num_ctx'], $body['options']['num_ctx']);
        $this->assertSame($chat['num_predict'], $body['options']['num_predict']);
        $this->assertSame(0.3, $body['options']['temperature']);
    }

    public function test_think_omitted_when_chat_think_is_null(): void
    {
        $body = OllamaRelay::body(['think' => null] + config('llm.chats.science'), [['role' => 'user', 'content' => 'x']]);

        $this->assertArrayNotHasKey('think', $body);
    }

    public function test_code_chat_sends_top_p_top_k(): void
    {
        $options = OllamaRelay::body(config('llm.chats.science'), [['role' => 'user', 'content' => 'x']])['options'];

        $this->assertSame(0.6, $options['temperature']);
        $this->assertSame(0.95, $options['top_p']);
        $this->assertSame(20, $options['top_k']);
        $this->assertSame(32768, $options['num_ctx']);
    }

    public function test_emits_text_pieces_even_when_line_is_split(): void
    {
        $relay = $this->relay();
        $data = $this->line(['message' => ['content' => 'При'], 'done' => false])
            . $this->line(['message' => ['content' => 'вет'], 'done' => false]);

        $relay->feed(substr($data, 0, 20));
        $relay->feed(substr($data, 20));

        $this->assertSame([['t' => 'При'], ['t' => 'вет']], $this->events);
        $this->assertSame(2, $relay->pieces);
        $this->assertSame('Привет', $relay->text);
    }

    public function test_emoji_removed_strict_style(): void
    {
        $relay = $this->relay();

        $relay->feed($this->line(['message' => ['content' => 'Готово ✅ 🚀'], 'done' => false])
            . $this->line(['message' => ['content' => '😀'], 'done' => false])
            . $this->line(['message' => ['content' => ' Итог: x² ≥ 0, ±1 → 2.'], 'done' => false]));

        $this->assertSame([['t' => 'Готово  '], ['t' => ' Итог: x² ≥ 0, ±1 → 2.']], $this->events);
        $this->assertSame('Готово   Итог: x² ≥ 0, ±1 → 2.', $relay->text);
    }

    public function test_done_records_reason_and_final_stats(): void
    {
        $relay = $this->relay();

        $relay->feed($this->line(['message' => ['content' => ''], 'done' => true, 'done_reason' => 'stop', 'eval_count' => 7]));

        $this->assertTrue($relay->sawDone);
        $this->assertSame('stop', $relay->doneReason);
        $this->assertSame(7, $relay->final['eval_count']);
        $this->assertSame([], $this->events);
    }

    public function test_error_line_recorded_not_emitted_raw(): void
    {
        $relay = $this->relay();

        $relay->feed($this->line(['error' => 'out of memory']));

        $this->assertSame('out of memory', $relay->error);
        $this->assertSame([], $this->events);
    }

    public function test_thinking_emits_single_status_not_text(): void
    {
        $relay = $this->relay();

        $relay->feed($this->line(['message' => ['thinking' => 'Хм'], 'done' => false]));
        $relay->feed($this->line(['message' => ['thinking' => 'ещё'], 'done' => false]));

        $this->assertSame([['s' => 'think']], $this->events);
        $this->assertSame(0, $relay->pieces);
    }

    public function test_non_json_line_counted_and_skipped(): void
    {
        $relay = $this->relay();

        $relay->feed("не json\n" . $this->line(['message' => ['content' => 'ок']]));

        $this->assertSame(1, $relay->bad);
        $this->assertSame([['t' => 'ок']], $this->events);
    }

    public function test_non_string_content_ignored(): void
    {
        $relay = $this->relay();

        $relay->feed($this->line(['message' => ['content' => ['x' => 1]]]));

        $this->assertSame([], $this->events);
    }

    public function test_collects_tool_calls(): void
    {
        $relay = $this->relay();
        $call = ['function' => ['name' => 'run_python', 'arguments' => ['code' => 'print(2+2)']]];

        $relay->feed($this->line(['message' => ['content' => '', 'tool_calls' => [$call]], 'done' => false]));

        $this->assertSame([$call], $relay->toolCalls);
    }

    public function test_finish_handles_last_line_without_newline(): void
    {
        $relay = $this->relay();

        $relay->feed(rtrim($this->line(['message' => ['content' => 'хвост'], 'done' => true])));
        $this->assertSame([], $this->events);
        $relay->finish();

        $this->assertSame([['t' => 'хвост']], $this->events);
        $this->assertTrue($relay->sawDone);
    }
}
