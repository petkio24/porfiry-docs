<?php

namespace Tests\Unit\Chat;

use App\Porfiry\Chat\IpLimit;
use App\Porfiry\Chat\Store;
use Tests\Porfiry\UsesTempStore;
use Tests\TestCase;

class IpLimitTest extends TestCase
{
    use UsesTempStore;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTempStore();
        config(['llm.queue.max_per_ip' => 2]);
    }

    protected function tearDown(): void
    {
        $this->tearDownTempStore();
        parent::tearDown();
    }

    private function limit(string $ip = '10.0.0.1', string $chat = 'office'): IpLimit
    {
        return new IpLimit(Store::get(), $chat, $ip);
    }

    public function test_allows_up_to_max_answers_from_one_ip(): void
    {
        $this->assertTrue($this->limit()->enter('a'));
        $this->assertTrue($this->limit()->enter('b'));
        $this->assertFalse($this->limit()->enter('c'));
    }

    public function test_same_rid_counts_once(): void
    {
        $this->limit()->enter('a');

        $this->assertTrue($this->limit()->enter('a'));
        $this->assertTrue($this->limit()->enter('b'));
    }

    public function test_leave_frees_place(): void
    {
        $this->limit()->enter('a');
        $this->limit()->enter('b');

        $this->limit()->leave('a');

        $this->assertTrue($this->limit()->enter('c'));
    }

    public function test_other_ip_and_other_chat_are_separate(): void
    {
        $this->limit()->enter('a');
        $this->limit()->enter('b');

        $this->assertTrue($this->limit('10.0.0.2')->enter('c'));
        $this->assertTrue($this->limit('10.0.0.1', 'science')->enter('d'));
    }

    public function test_answer_without_beat_drops_out(): void
    {
        $this->limit()->enter('a');
        $this->limit()->enter('b');

        $this->travel(31)->seconds();

        $this->assertTrue($this->limit()->enter('c'));
    }

    public function test_beat_keeps_answer_counted(): void
    {
        $this->limit()->enter('a');
        $this->limit()->enter('b');

        $this->travel(20)->seconds();
        $this->limit()->beat('a');
        $this->limit()->beat('b');
        $this->travel(20)->seconds();

        $this->assertFalse($this->limit()->enter('c'));
    }
}
