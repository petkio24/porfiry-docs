<?php

namespace Tests\Unit\Chat;

use App\Porfiry\Chat\Cancellation;
use App\Porfiry\Chat\Store;
use Tests\Porfiry\UsesTempStore;
use Tests\TestCase;

class CancellationTest extends TestCase
{
    use UsesTempStore;

    private float $now = 1000.0;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTempStore();
    }

    protected function tearDown(): void
    {
        $this->tearDownTempStore();
        parent::tearDown();
    }

    private function make(string $sid, string $chat, string $rid): Cancellation
    {
        return new Cancellation(Store::get(), $sid, $chat, $rid, fn () => $this->now);
    }

    private function later(Cancellation $c): ?string
    {
        // Проверка кэшируется на 0,5 с — сдвигаем свои часы.
        $this->now += 1.0;

        return $c->check();
    }

    public function test_new_rid_is_not_cancelled(): void
    {
        $c = $this->make('s1', 'office', str_repeat('a', 32));
        $c->begin();

        $this->assertNull($c->check());
    }

    public function test_cancel_own_rid(): void
    {
        $c = $this->make('s1', 'office', str_repeat('a', 32));
        $c->begin();

        Cancellation::cancel(Store::get(), 's1', str_repeat('a', 32));

        $this->assertSame('cancelled', $this->later($c));
    }

    public function test_new_question_in_same_chat_displaces_previous(): void
    {
        $first = $this->make('s1', 'office', str_repeat('a', 32));
        $first->begin();
        $second = $this->make('s1', 'office', str_repeat('b', 32));
        $second->begin();

        $this->assertSame('replaced', $this->later($first));
        $this->assertNull($second->check());
    }

    public function test_other_chat_is_not_displaced(): void
    {
        $office = $this->make('s1', 'office', str_repeat('a', 32));
        $office->begin();
        $this->make('s1', 'science', str_repeat('b', 32))->begin();

        $this->assertNull($this->later($office));
    }

    public function test_cancel_from_other_session_has_no_effect(): void
    {
        $c = $this->make('s1', 'office', str_repeat('a', 32));
        $c->begin();

        Cancellation::cancel(Store::get(), 's2', str_repeat('a', 32));

        $this->assertNull($this->later($c));
    }

    public function test_cancel_before_begin_still_cancels(): void
    {
        // «Стоп» дошёл раньше, чем сервер начал ответ.
        Cancellation::cancel(Store::get(), 's1', str_repeat('a', 32));
        $c = $this->make('s1', 'office', str_repeat('a', 32));
        $c->begin();

        $this->assertSame('cancelled', $c->check());
    }

    public function test_check_is_cached_for_half_second(): void
    {
        $c = $this->make('s1', 'office', str_repeat('a', 32));
        $c->begin();
        $this->assertNull($c->check());

        Cancellation::cancel(Store::get(), 's1', str_repeat('a', 32));
        $this->now += 0.2;
        $this->assertNull($c->check());

        $this->now += 0.4;
        $this->assertSame('cancelled', $c->check());
    }

    public function test_cleanup_of_finished_stream_does_not_cancel_new_rid(): void
    {
        $first = $this->make('s1', 'office', str_repeat('a', 32));
        $first->begin();
        $second = $this->make('s1', 'office', str_repeat('b', 32));
        $second->begin();

        $first->finish();

        $this->assertNull($this->later($second));
    }

    public function test_missing_alive_ping_cancels_after_timeout(): void
    {
        config(['llm.queue.alive_timeout' => 150]);
        $c = $this->make('s1', 'office', str_repeat('a', 32));
        $c->begin();

        $this->travel(100)->seconds();
        Cancellation::ping(Store::get(), 's1', str_repeat('a', 32));
        $this->travel(100)->seconds();
        $this->assertNull($this->later($c));

        $this->travel(51)->seconds();
        $this->assertSame('gone', $this->later($c));
    }

    public function test_cancelled_rid_does_not_displace_live_answer(): void
    {
        // «Стоп» второго вопроса обогнал сам вопрос — первый ответ продолжается.
        $live = $this->make('s1', 'office', str_repeat('a', 32));
        $live->begin();
        Cancellation::cancel(Store::get(), 's1', str_repeat('b', 32));
        $this->make('s1', 'office', str_repeat('b', 32))->begin();

        $this->assertNull($this->later($live));
    }

    public function test_reason_sticks_once_found(): void
    {
        $c = $this->make('s1', 'office', str_repeat('a', 32));
        $c->begin();
        Cancellation::cancel(Store::get(), 's1', str_repeat('a', 32));
        $this->assertSame('cancelled', $this->later($c));

        Store::get()->flush();

        $this->assertSame('cancelled', $this->later($c));
    }
}
