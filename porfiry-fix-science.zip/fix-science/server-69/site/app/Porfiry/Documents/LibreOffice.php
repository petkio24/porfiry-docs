<?php

namespace App\Porfiry\Documents;

use Illuminate\Process\Exceptions\ProcessTimedOutException;
use Illuminate\Support\Facades\Process;
use RuntimeException;

/** Перевод документа в другой формат через LibreOffice без окон, со своим профилем на вызов. */
final class LibreOffice
{
    public function __construct(private string $binary, private int $timeout = 120)
    {
    }

    /** @return string путь к результату в $outdir */
    public function convert(string $file, string $target, string $outdir): string
    {
        $ext = explode(':', $target)[0];
        try {
            // Свой профиль: параллельные вызовы не мешают друг другу, у www-data нет домашней папки.
            // Без экрана: на Astra LibreOffice собран с Qt и иначе ищет X-сервер («plugin xcb»).
            $result = Process::timeout($this->timeout)->env([
                'HOME' => $outdir,
                'SAL_USE_VCLPLUGIN' => 'svp',
                'QT_QPA_PLATFORM' => 'offscreen',
            ])->run([
                $this->binary, '--headless', '--norestore', '--nologo', '--nolockcheck',
                '-env:UserInstallation=file://' . str_replace('\\', '/', $outdir) . '/lo-profile',
                '--convert-to', $target, '--outdir', $outdir, $file,
            ]);
        } catch (ProcessTimedOutException) {
            throw new RuntimeException("LibreOffice не успел за {$this->timeout} с");
        }

        $out = $outdir . '/' . pathinfo($file, PATHINFO_FILENAME) . '.' . $ext;
        if (! $result->successful() || ! is_file($out) || filesize($out) === 0) {
            $why = mb_substr(trim($result->errorOutput() . ' ' . $result->output()), 0, 200);

            throw new RuntimeException('LibreOffice не смог сделать ' . strtoupper($ext) . ($why !== '' ? ": {$why}" : ''));
        }

        return $out;
    }
}
