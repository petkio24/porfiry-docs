<?php

namespace App\Porfiry\Chat;

use Closure;
use Illuminate\Cache\Repository;
use Illuminate\Contracts\Cache\LockTimeoutException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Sleep;

/**
 * Очередь к серверу модели одного чата: slots мест, остальные ждут строго по порядку.
 *
 * Место — ключ llm:slot:{chat}:{i} с rid; живёт slot_ttl секунд и продлевается
 * сердцебиением, поэтому место упавшего процесса PHP освобождается само.
 * Ожидающие — список llm:q:{chat} (порядок входа, время последнего сердцебиения),
 * меняется только под коротким замком.
 */
final class SlotQueue
{
    public const QUEUE_FULL = -1;

    // Замок очереди занят дольше 2 с — шаг пропущен, на следующем повторим.
    public const MUTEX_BUSY = -2;

    private Closure $sleep;

    private ?int $slot = null;

    public function __construct(
        private Repository $store,
        private string $chat,
        private int $slots,
        ?Closure $sleep = null
    ) {
        $this->sleep = $sleep ?? static function (): void {
            // Sleep подменяется в тестах (Sleep::fake); его нет в Laravel до 10.13.
            class_exists(Sleep::class) ? Sleep::for(1)->second() : usleep(1_000_000);
        };
    }

    /**
     * Ждёт места. $tick(int $position) вызывается раз в секунду, пока ждём;
     * вернёт строку — ожидание прекращается с этой причиной.
     * Итог: null — место получено; иначе причина: queue, timeout или ответ $tick.
     */
    public function acquire(string $rid, Closure $tick): ?string
    {
        $deadline = Carbon::now()->getTimestamp() + (int) config('llm.queue.max_wait');
        $position = 1;

        while (true) {
            $entered = $this->enter($rid);
            if ($entered === 0) {
                return null;
            }
            if ($entered === self::QUEUE_FULL) {
                return 'queue';
            }
            if ($entered !== self::MUTEX_BUSY) {
                $position = $entered;
            }
            $reason = $tick($position);
            if ($reason !== null) {
                $this->leave($rid);

                return $reason;
            }
            if (Carbon::now()->getTimestamp() >= $deadline) {
                $this->leave($rid);

                return 'timeout';
            }
            ($this->sleep)();
        }
    }

    /**
     * Один шаг: занять место, если подошла очередь, иначе встать в очередь или
     * обновить сердцебиение. Итог: 0 — место получено; N — место в очереди;
     * QUEUE_FULL — очередь переполнена.
     */
    public function enter(string $rid): int
    {
        return $this->mutex(function () use ($rid): int {
            $now = Carbon::now()->getTimestamp();
            $queue = $this->waiters($now);
            $ahead = array_search($rid, array_keys($queue), true);
            $ahead = $ahead === false ? count($queue) : $ahead;

            if ($ahead === 0 && ($slot = $this->takeSlot($rid)) !== null) {
                $this->slot = $slot;
                unset($queue[$rid]);
                $this->saveWaiters($queue);

                return 0;
            }
            if (! isset($queue[$rid]) && count($queue) >= (int) config('llm.queue.max_waiting')) {
                return self::QUEUE_FULL;
            }
            $queue[$rid] = $now;
            $this->saveWaiters($queue);

            return $ahead + 1;
        });
    }

    public function leave(string $rid): void
    {
        $this->mutex(function () use ($rid): int {
            $queue = $this->waiters(Carbon::now()->getTimestamp());
            unset($queue[$rid]);
            $this->saveWaiters($queue);

            return 0;
        });
    }

    /** Сколько ответов идёт сейчас (занятых мест). */
    public function busy(): int
    {
        $busy = 0;
        for ($i = 0; $i < $this->slots; $i++) {
            $busy += $this->store->has($this->slotKey($i)) ? 1 : 0;
        }

        return $busy;
    }

    /** Подтвердить своё место (раз в heartbeat секунд). */
    public function heartbeat(string $rid): void
    {
        if ($this->slot !== null && $this->store->get($this->slotKey($this->slot)) === $rid) {
            $this->store->put($this->slotKey($this->slot), $rid, (int) config('llm.queue.slot_ttl'));
        }
    }

    public function release(string $rid): void
    {
        if ($this->slot === null) {
            return;
        }
        $free = function () use ($rid): int {
            if ($this->store->get($this->slotKey($this->slot)) === $rid) {
                $this->store->forget($this->slotKey($this->slot));
            }

            return 0;
        };
        // Замок занят — освобождаем без него: иначе место простоит до slot_ttl.
        if ($this->mutex($free) === self::MUTEX_BUSY) {
            $free();
        }
        $this->slot = null;
    }

    private function takeSlot(string $rid): ?int
    {
        for ($i = 0; $i < $this->slots; $i++) {
            if ($this->store->add($this->slotKey($i), $rid, (int) config('llm.queue.slot_ttl'))) {
                return $i;
            }
        }

        return null;
    }

    /** Ожидающие по порядку входа, без тех, кто давно не подтверждал себя. */
    private function waiters(int $now): array
    {
        $ttl = (int) config('llm.queue.waiter_ttl');
        $queue = $this->store->get($this->queueKey(), []);

        return array_filter(is_array($queue) ? $queue : [], fn ($beat) => $now - (int) $beat <= $ttl);
    }

    private function saveWaiters(array $queue): void
    {
        $this->store->put($this->queueKey(), $queue, 3600);
    }

    private function mutex(Closure $callback): int
    {
        try {
            return $this->store->lock($this->queueKey() . ':mx', 5)->block(2, $callback);
        } catch (LockTimeoutException) {
            return self::MUTEX_BUSY;
        }
    }

    private function slotKey(int $i): string
    {
        return "llm:slot:{$this->chat}:{$i}";
    }

    private function queueKey(): string
    {
        return "llm:q:{$this->chat}";
    }
}
