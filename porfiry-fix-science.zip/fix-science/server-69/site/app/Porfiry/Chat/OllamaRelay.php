<?php

namespace App\Porfiry\Chat;

use Closure;

/**
 * Запрос к Ollama /api/chat и разбор её потока NDJSON в события для браузера.
 * Кусок текста → {"t": "..."}; первые «рассуждения» → один статус {"s": "think"}.
 * Конец, ошибку и вызовы инструментов relay только запоминает — что с ними
 * делать, решает вызывающий.
 */
final class OllamaRelay
{
    // Пиктограммы и эмодзи (U+1F000–1FAFF), значки и dingbats (U+2600–27BF, 2B00–2BFF), селектор эмодзи.
    private const EMOJI = '/[\x{1F000}-\x{1FAFF}\x{2600}-\x{27BF}\x{2B00}-\x{2BFF}\x{FE0F}]/u';

    public int $pieces = 0;

    public int $bad = 0;

    public bool $sawDone = false;

    public ?string $doneReason = null;

    public ?string $error = null;

    public array $final = [];

    public array $toolCalls = [];

    public string $text = '';

    private string $buffer = '';

    private bool $thinkingSent = false;

    public function __construct(private Closure $emit)
    {
    }

    public static function body(array $chat, array $messages): array
    {
        $body = [
            'model' => $chat['model'],
            'stream' => true,
            'messages' => [['role' => 'system', 'content' => $chat['system']], ...$messages],
            'options' => ['num_ctx' => $chat['num_ctx'], 'num_predict' => $chat['num_predict']] + $chat['options'],
        ];
        // null — у модели нет режима рассуждений, поле не передаём.
        if ($chat['think'] !== null) {
            $body['think'] = (bool) $chat['think'];
        }

        return $body;
    }

    public function feed(string $data): void
    {
        $this->buffer .= $data;
        while (($pos = strpos($this->buffer, "\n")) !== false) {
            $line = trim(substr($this->buffer, 0, $pos));
            $this->buffer = substr($this->buffer, $pos + 1);
            $this->line($line);
        }
    }

    /** Последняя строка могла прийти без перевода строки. */
    public function finish(): void
    {
        $line = trim($this->buffer);
        $this->buffer = '';
        $this->line($line);
    }

    private function line(string $line): void
    {
        if ($line === '') {
            return;
        }
        $chunk = json_decode($line, true);
        if (! is_array($chunk)) {
            $this->bad++;

            return;
        }
        if (isset($chunk['error'])) {
            $this->error = is_string($chunk['error']) ? $chunk['error'] : json_encode($chunk['error']);

            return;
        }

        $message = is_array($chunk['message'] ?? null) ? $chunk['message'] : [];
        $content = $message['content'] ?? '';
        // Строгий стиль: эмодзи и пиктограммы вырезаются, даже если модель их поставит.
        $content = is_string($content) ? preg_replace(self::EMOJI, '', $content) : '';
        if ($content !== '') {
            ($this->emit)(['t' => $content]);
            $this->pieces++;
            $this->text .= $content;
        }
        $thinking = $message['thinking'] ?? '';
        if (is_string($thinking) && $thinking !== '' && ! $this->thinkingSent) {
            ($this->emit)(['s' => 'think']);
            $this->thinkingSent = true;
        }
        foreach (is_array($message['tool_calls'] ?? null) ? $message['tool_calls'] : [] as $call) {
            if (is_array($call)) {
                $this->toolCalls[] = $call;
            }
        }
        if (! empty($chunk['done'])) {
            $this->sawDone = true;
            $this->doneReason = is_string($chunk['done_reason'] ?? null) ? $chunk['done_reason'] : null;
            $this->final = $chunk;
        }
    }
}
