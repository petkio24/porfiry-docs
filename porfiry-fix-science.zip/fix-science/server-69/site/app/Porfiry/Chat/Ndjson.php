<?php

namespace App\Porfiry\Chat;

/** Одна строка JSON в поток ответа и сразу в сеть (без накопления в буферах PHP). */
final class Ndjson
{
    private static float $lastAt = 0.0;

    public static function emit(array $event): void
    {
        self::$lastAt = microtime(true);
        echo json_encode($event, JSON_UNESCAPED_UNICODE) . "\n";
        if (ob_get_level() > 0) {
            ob_flush();
        }
        flush();
    }

    /** Когда в браузер ушла последняя строка: по нему считается пульс. */
    public static function lastAt(): float
    {
        return self::$lastAt;
    }
}
