<?php

// Фрагмент: добавить в routes/web.php проекта (вместо маршрутов чата v1).

use App\Http\Controllers\ChatController;
use App\Http\Controllers\DocumentController;
use Illuminate\Support\Facades\Route;

Route::get('/chat', [ChatController::class, 'index'])->name('chat');
Route::get('/chat/office/templates', [DocumentController::class, 'templates'])->name('chat.templates');
Route::post('/chat/office/document', [DocumentController::class, 'render'])
    ->middleware('throttle:30,1,porfiry-docs')
    ->name('chat.document');
// Раньше /chat/{type}: иначе «cancel» попал бы в {type}.
Route::post('/chat/cancel', [ChatController::class, 'cancel'])
    ->middleware('throttle:120,1,porfiry-cancel')
    ->name('chat.cancel');
Route::post('/chat/{type}', [ChatController::class, 'send'])
    ->whereIn('type', ['office', 'science'])
    ->middleware('throttle:30,1,porfiry-send')
    ->name('chat.send');
