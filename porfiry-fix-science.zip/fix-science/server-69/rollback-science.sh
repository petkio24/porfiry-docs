#!/bin/bash
# Откат update-web.sh: файлы чата и строки LLM_ из .env — как до обновления.
#
#   sudo bash rollback-science.sh /путь/к/сайту
SITE=$(cd "${1:-}" 2>/dev/null && pwd)
BAK=/opt/porfiry/backup-science

die() { echo "ПРОБЛЕМА  $*"; echo "ИТОГ: ПРОБЛЕМА — откат не выполнен"; exit 1; }

[ "$(id -u)" = 0 ] || die "запустите через sudo"
[ -f "$SITE/artisan" ] || die "в «${1:-}» нет artisan — укажите папку сайта"
[ -f "$BAK/env-llm.txt" ] || die "нет копии $BAK — обновление не ставилось или копия удалена"
cd "$SITE" || exit 1

(cd "$BAK" && find . -type f ! -name env-llm.txt | sed 's#^\./##') | while read -r f; do
    cp -p "$BAK/$f" "$SITE/$f"
done
sed -i '/^LLM_/d' .env
cat "$BAK/env-llm.txt" >> .env
echo "OK  файлы и строки LLM_ возвращены из $BAK"

HAD_CONFIG=no; [ -f bootstrap/cache/config.php ] && HAD_CONFIG=yes
for c in config:clear route:clear view:clear; do sudo -u www-data php artisan "$c" >/dev/null; done
[ "$HAD_CONFIG" = yes ] && sudo -u www-data php artisan config:cache >/dev/null
PHPV=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
systemctl is-active --quiet "php$PHPV-fpm" && systemctl restart "php$PHPV-fpm"
systemctl restart apache2

rm -rf "$BAK"
echo "OK  копия $BAK удалена (повторное обновление сделает новую)"
echo "ИТОГ: OK — сайт возвращён к состоянию до обновления"
