#!/bin/bash
# Веб-сервер 172.19.101.69: научный чат (/chat/science), карточка очереди, строгий стиль.
# Повторный запуск безопасен.
#
#   sudo bash update-web.sh /путь/к/сайту
#
# Перед заменой сохраняет копию файлов и строк LLM_ из .env в /opt/porfiry/backup-science
# (откат: sudo bash rollback-science.sh /путь/к/сайту).
HERE=$(cd "$(dirname "$0")" && pwd)
SITE=$(cd "${1:-}" 2>/dev/null && pwd)
BAK=/opt/porfiry/backup-science

ok()   { echo "OK  $*"; }
warn() { echo "ВНИМАНИЕ  $*"; }
die()  { echo "ПРОБЛЕМА  $*"; echo "ИТОГ: ПРОБЛЕМА — сайт не менялся"; exit 1; }

[ "$(id -u)" = 0 ] || die "запустите через sudo: sudo bash $0 /путь/к/сайту"
[ -f "$SITE/artisan" ] || die "в «${1:-}» нет artisan — укажите папку сайта"
[ -f "$SITE/routes/porfiry.php" ] || die "в сайте нет чата v2 (routes/porfiry.php) — сначала установка v2"
[ -d "$HERE/site" ] || die "рядом нет папки site — распакуйте пакет заново"
cd "$SITE" || exit 1

for f in $(find "$HERE/site" -name '*.php'); do
    php -l "$f" >/dev/null || die "файл $f повреждён — распакуйте пакет заново"
done
ok "файлы обновления целы"

# --- Копия для отката (первая копия хранит состояние до обновления) ------------
if [ -f "$BAK/env-llm.txt" ]; then
    ok "копия для отката уже есть: $BAK"
else
    mkdir -p "$BAK"
    (cd "$HERE/site" && find . -type f | sed 's#^\./##') | while read -r f; do
        [ -f "$f" ] && cp --parents -p "$f" "$BAK/"
    done
    grep '^LLM_' .env > "$BAK/env-llm.txt"
    ok "копия файлов и строк LLM_ из .env: $BAK"
fi

# --- Новые файлы ----------------------------------------------------------------
cp -r "$HERE/site/." "$SITE/"
ok "файлы чата заменены ($(find "$HERE/site" -type f | wc -l) шт.)"

# --- .env: LLM_CODE_ → LLM_SCIENCE_, очередь по одному ответу на чат -----------
sed -i 's/\r$//; s/^LLM_CODE_/LLM_SCIENCE_/' .env
for kv in LLM_OFFICE_SLOTS=1 LLM_SCIENCE_SLOTS=1 LLM_ANSWER_TIMEOUT=2700 LLM_QUEUE_MAX_WAIT=1800; do
    sed -i "/^${kv%%=*}=/d" .env
    echo "$kv" >> .env
done
grep -q '^LLM_CODE_' .env && die "в .env остались строки LLM_CODE_"
ok ".env: $(grep -c '^LLM_' .env) строк LLM_, научный чат: $(grep '^LLM_SCIENCE_URL=' .env | cut -d= -f2- || true)"
grep -q '^LLM_SCIENCE_URL=' .env || ok "адрес научного чата — по умолчанию http://172.19.101.170:11434"

# --- Кэши, затем перезапуск (иначе OPcache исполняет старый код) --------------
HAD_CONFIG=no; [ -f bootstrap/cache/config.php ] && HAD_CONFIG=yes
HAD_ROUTES=no; ls bootstrap/cache/routes-*.php >/dev/null 2>&1 && HAD_ROUTES=yes
for c in config:clear route:clear view:clear; do
    sudo -u www-data php artisan "$c" >/dev/null || die "php artisan $c не прошёл"
done
[ "$HAD_CONFIG" = yes ] && { sudo -u www-data php artisan config:cache >/dev/null || die "config:cache не прошёл"; }
[ "$HAD_ROUTES" = yes ] && { sudo -u www-data php artisan route:cache >/dev/null || die "route:cache не прошёл"; }
ok "кэши пересобраны"

PHPV=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
systemctl is-active --quiet "php$PHPV-fpm" && systemctl restart "php$PHPV-fpm"
systemctl restart apache2 || die "apache2 не перезапустился (sudo apache2ctl configtest)"
ok "службы перезапущены"

# --- Проверка ------------------------------------------------------------------
code_new=$(curl -s --noproxy '*' -o /dev/null -w '%{http_code}' -X POST http://127.0.0.1/chat/science)
code_old=$(curl -s --noproxy '*' -o /dev/null -w '%{http_code}' -X POST http://127.0.0.1/chat/code)
if [ "$code_new" = 419 ] && [ "$code_old" = 404 ]; then
    ok "адрес /chat/science работает, /chat/code убран"
else
    warn "ответы /chat/science=$code_new, /chat/code=$code_old (ожидалось 419 и 404) — проверьте в браузере"
fi
curl -s --noproxy '*' http://127.0.0.1/chat | grep -q 'Научный' \
    && ok "на странице вкладка «Научный»" || warn "на странице /chat не найдена вкладка «Научный»"

echo
echo "Полная проверка:  sudo -u www-data python3 $HERE/check-web.py --site $SITE"
echo "Откат:            sudo bash $HERE/rollback-science.sh $SITE"
echo "ИТОГ: OK — сайт обновлён"
