#!/bin/bash
# Сервер 172.19.101.170: научный чат — модель Qwen3.6 35B-A3B под именем science
# вместо Qwen3-Coder-Next. Повторный запуск безопасен.
#
#   sudo bash science-170.sh
#
# Модель берётся из /opt/porfiry/models-office (папка с сервера .171). Если папки нет,
# но в /opt/porfiry лежит server-171-office.tar, папка распаковывается из архива.
set -uo pipefail

HERE=$(cd "$(dirname "$0")" && pwd)
BASE=/opt/porfiry
SRC=$BASE/models-office
MODELS=/usr/share/ollama/.ollama/models
TAG=qwen3.6:35b-a3b-q4_K_M
UNIT=/etc/systemd/system/ollama.service
WARM=/etc/systemd/system/porfiry-warmup.service
API=http://127.0.0.1:11434

ok()   { echo "OK  $*"; }
die()  { echo "ПРОБЛЕМА  $*"; echo "ИТОГ: ПРОБЛЕМА — установка остановлена"; exit 1; }
step() { echo; echo "=== $*"; }

[ "$(id -u)" = 0 ] || die "запустите через sudo: sudo bash $0"
command -v ollama >/dev/null 2>&1 || die "Ollama не установлена (сначала установка v2: install-ollama.sh)"
[ -f "$HERE/ollama-science.service" ] || die "рядом нет ollama-science.service — распакуйте пакет заново"

step "1/6 Модель с сервера .171"
if [ ! -d "$SRC/blobs" ] && [ -f "$BASE/server-171-office.tar" ]; then
    echo "  распаковываю models-office из server-171-office.tar (несколько минут)..."
    tar -xf "$BASE/server-171-office.tar" -C "$BASE" ./models-office || die "архив server-171-office.tar не распаковался"
fi
[ -f "$SRC/manifests/registry.ollama.ai/library/qwen3.6/35b-a3b-q4_K_M" ] \
    || die "нет модели: положите папку models-office (или server-171-office.tar) в $BASE"
ok "папка модели: $SRC"

step "2/6 Проверка файлов модели (23 ГБ — несколько минут)"
(cd "$SRC/blobs" && for f in sha256-*; do echo "${f#sha256-}  $f"; done | sha256sum -c --quiet) \
    || die "файлы модели повреждены при переносе — скопируйте models-office заново"
ok "модель цела"

step "3/6 Подключение модели к Ollama"
mkdir -p "$MODELS"
# Жёсткие ссылки — без второй копии; на другом разделе диска — обычное копирование.
cp -rl --remove-destination "$SRC/." "$MODELS/" 2>/dev/null \
    || cp -r --remove-destination "$SRC/." "$MODELS/" \
    || die "не удалось положить модель в $MODELS (место на диске?)"
chown -R ollama:ollama /usr/share/ollama
ok "файлы модели в $MODELS"

step "4/6 Службы"
install -m 644 "$HERE/ollama-science.service" "$UNIT"
if [ -f "$WARM" ]; then
    sed -i 's/ code$/ science/; s/model code /model science /' "$WARM"
fi
systemctl daemon-reload
systemctl restart ollama
for i in $(seq 60); do
    curl -s --noproxy '*' -m 2 "$API/api/version" >/dev/null && break
    sleep 1
done
curl -s --noproxy '*' -m 2 "$API/api/version" >/dev/null \
    || die "Ollama не отвечает после перезапуска — журнал: sudo journalctl -u ollama -n 30 --no-pager"
ok "Ollama отвечает; служба: $(systemctl show -p Description --value ollama)"

step "5/6 Имя модели science, старые — удалить"
ollama cp "$TAG" science >/dev/null || die "ollama cp $TAG science не прошёл"
for old in code office qwen3-coder-next:q4_K_M; do
    ollama rm "$old" >/dev/null 2>&1 && echo "  удалено: $old"
done
ollama list
ollama list | grep -q '^science:latest' || die "модели science нет в списке"
ok "модель science на месте"

step "6/6 Загрузка в память и пробный ответ (с HDD — до 15 минут)"
answer=$(curl -s --noproxy '*' -m 1800 "$API/api/chat" -d '{"model": "science", "stream": false,
 "think": false, "options": {"num_predict": 30},
 "messages": [{"role": "user", "content": "Сколько будет 2+2? Ответь одним числом."}]}')
text=$(printf '%s' "$answer" | python3 -c 'import json,sys; print(json.load(sys.stdin)["message"]["content"].strip()[:80])' 2>/dev/null)
[ -n "$text" ] || die "модель не ответила: ${answer:0:300}"
ok "ответ модели: $text"
if [ -f "$WARM" ]; then
    systemctl enable porfiry-warmup >/dev/null 2>&1
    ok "после перезагрузки сервера модель science загрузится сама (porfiry-warmup)"
fi

echo
echo "Когда научный чат проверен, освободите место старой модели (51 ГБ):"
echo "    sudo rm -rf $BASE/models-code"
echo "ИТОГ: OK — научный чат на сервере .170 готов"
