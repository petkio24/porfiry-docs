/*
 * Документы офисного чата: выбор шаблона, форма полей, скачивание файла.
 * Поля заполняет модель (chat.js отправляет вопрос с template), здесь — только интерфейс.
 * Значения полей живут в истории вкладки (sessionStorage), на сервере не хранятся.
 */
(function () {
    'use strict';

    var config = window.CHAT_CONFIG.docs || {};
    var csrf = document.querySelector('meta[name="csrf-token"]').content;
    var templates = null;
    var loading = null;

    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) node.className = className;
        if (text !== undefined) node.textContent = text;
        return node;
    }

    function load() {
        if (templates) return Promise.resolve(templates);
        if (!loading) {
            loading = fetch(config.templatesUrl, { headers: { 'Accept': 'application/json' } })
                .then(function (r) { return r.ok ? r.json() : { templates: [] }; })
                .then(function (data) { templates = data.templates || []; return templates; })
                .catch(function () { loading = null; return []; });
        }
        return loading;
    }

    // Шаблоны, ключевые слова которых есть в вопросе («договор купли» → ДКП).
    function match(text) {
        var lower = (text || '').toLowerCase().replace(/ё/g, 'е');
        return (templates || []).filter(function (t) {
            return (t.keywords || []).some(function (k) { return k && lower.indexOf(k.toLowerCase().replace(/ё/g, 'е')) !== -1; });
        });
    }

    function pick(anchor, onPick) {
        var old = document.querySelector('.doc-pick');
        if (old) { old.remove(); return; }
        var panel = el('div', 'doc-pick');
        panel.setAttribute('role', 'menu');
        load().then(function (list) {
            if (!list.length) panel.appendChild(el('p', 'doc-pick-empty', 'Шаблонов пока нет: их кладёт администратор на сервер.'));
            list.forEach(function (t) {
                var item = el('button', 'doc-pick-item');
                item.type = 'button';
                item.setAttribute('role', 'menuitem');
                item.appendChild(el('strong', '', t.title));
                if (t.description) item.appendChild(el('span', '', t.description));
                item.addEventListener('click', function () { panel.remove(); onPick(t); });
                panel.appendChild(item);
            });
        });
        anchor.parentElement.appendChild(panel);
        setTimeout(function () {
            document.addEventListener('click', function close(e) {
                if (!panel.contains(e.target)) { panel.remove(); document.removeEventListener('click', close); }
            });
        });
    }

    // Ответ модели — JSON с полями; бывает с лишним текстом вокруг.
    function parseFields(text, template) {
        var data = null;
        try { data = JSON.parse(text); } catch (e) {
            var m = /\{[\s\S]*\}/.exec(text || '');
            try { data = m ? JSON.parse(m[0]) : null; } catch (e2) { data = null; }
        }
        var values = {};
        template.fields.forEach(function (f) {
            var v = data && data[f.name];
            values[f.name] = v === undefined || v === null ? '' : String(v);
        });
        return { values: values, ok: data !== null };
    }

    function summary(doc) {
        var lines = doc.fields.map(function (f) { return f.label + ': ' + (doc.values[f.name] || '—'); });
        return 'Документ «' + doc.title + '». Поля:\n' + lines.join('\n');
    }

    function fileName(response, fallback) {
        var header = response.headers.get('Content-Disposition') || '';
        var m = /filename\*=utf-8''([^;]+)/i.exec(header);
        return m ? decodeURIComponent(m[1]) : fallback;
    }

    function download(doc, format, note) {
        note.textContent = 'Собираю ' + format.toUpperCase() + '…';
        return fetch(config.renderUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': csrf },
            body: JSON.stringify({ template: doc.id, format: format, fields: doc.values })
        }).then(function (response) {
            if (!response.ok) {
                return response.json().catch(function () { return {}; }).then(function (data) {
                    var text = data.message || '';
                    throw new Error(/[а-яё]/i.test(text) ? text : 'Документ не собран (ошибка ' + response.status + ').');
                });
            }
            return response.blob().then(function (blob) {
                var link = el('a');
                link.href = URL.createObjectURL(blob);
                link.download = fileName(response, 'document.' + format);
                document.body.appendChild(link);
                link.click();
                link.remove();
                setTimeout(function () { URL.revokeObjectURL(link.href); }, 10000);
                note.textContent = 'Файл скачан: ' + link.download;
            });
        }).catch(function (e) {
            note.textContent = e instanceof TypeError ? 'Нет связи с сервером.' : e.message;
        });
    }

    // Карточка документа в ленте: поля можно править, правки сохраняются в истории.
    function card(doc, onChange) {
        var box = el('div', 'doc-card');
        box.appendChild(el('h3', '', doc.title));
        if (doc.note) box.appendChild(el('p', 'doc-note', doc.note));
        doc.fields.forEach(function (f) {
            var label = el('label', 'doc-field');
            label.appendChild(el('span', '', f.label));
            var input = f.type === 'longtext' ? el('textarea') : el('input');
            if (f.type !== 'longtext') input.type = 'text';
            if (f.type === 'date') input.placeholder = 'ДД.ММ.ГГГГ';
            else if (f.hint) input.placeholder = f.hint;
            input.value = doc.values[f.name] || '';
            input.classList.toggle('is-empty', !input.value);
            input.addEventListener('input', function () {
                doc.values[f.name] = input.value;
                input.classList.toggle('is-empty', !input.value);
                onChange();
            });
            label.appendChild(input);
            box.appendChild(label);
        });
        var actions = el('div', 'doc-actions');
        var note = el('p', 'doc-status');
        note.setAttribute('aria-live', 'polite');
        doc.formats.forEach(function (format) {
            var btn = el('button', 'btn btn-ghost', 'Скачать ' + format.toUpperCase());
            btn.type = 'button';
            btn.addEventListener('click', function () {
                btn.disabled = true;
                download(doc, format, note).then(function () { btn.disabled = false; });
            });
            actions.appendChild(btn);
        });
        box.append(actions, note);
        return box;
    }

    window.PorfiryDocs = { load: load, match: match, pick: pick, parseFields: parseFields, summary: summary, card: card };
})();
