<?php

namespace App\Console\Commands;

use App\Porfiry\Bin;
use App\Porfiry\Kb\Extractor;
use App\Porfiry\Kb\Index;
use Illuminate\Console\Command;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use Throwable;

class PorfiryKbIndex extends Command
{
    protected $signature = 'porfiry:kb-index';

    protected $description = 'Порфирий: собрать поиск по ГОСТам из папки LLM_KB_PATH';

    private const SKIP = ['thumbs.db', 'desktop.ini'];

    public function handle(): int
    {
        if (function_exists('posix_geteuid') && posix_geteuid() === 0) {
            $this->line('ПРОБЛЕМА  запуск от root: сайт не сможет читать индекс. Запустите так:');
            $this->line('          sudo -u www-data php artisan porfiry:kb-index');

            return 1;
        }
        $dir = (string) config('llm.kb.docs_path');
        if (! is_dir($dir)) {
            $this->line("ПРОБЛЕМА  нет папки {$dir}");

            return 1;
        }

        $started = microtime(true);
        $extractor = new Extractor(Bin::find(config('llm.kb.pdftotext')), Bin::find(config('llm.docs.soffice')));
        $docs = [];
        $bad = 0;
        foreach ($this->files($dir) as $path) {
            $file = ltrim(str_replace('\\', '/', substr($path, strlen($dir))), '/');
            try {
                $text = $extractor->text($path);
                $name = pathinfo($path, PATHINFO_FILENAME);
                $code = Index::docCode($name) ?? Index::docCode($text) ?? $name;
                $chunks = Index::chunks($text);
                $docs[] = ['file' => $file, 'code' => $code, 'chunks' => $chunks];
                $this->line("OK  {$file}: {$code}, фрагментов " . count($chunks));
            } catch (Throwable $e) {
                $bad++;
                $this->line("ПРОБЛЕМА  {$file}: {$e->getMessage()}");
            }
        }

        $count = (new Index((string) config('llm.kb.index_path')))->build($docs);
        $summary = sprintf('документов %d, фрагментов %d, за %.0f с', count($docs), $count, microtime(true) - $started);
        $this->line('');
        $this->line($bad ? "ИТОГ: ВНИМАНИЕ — {$summary}; не прочитано файлов: {$bad} (см. ПРОБЛЕМА выше)" : "ИТОГ: OK — {$summary}");

        return 0;
    }

    private function files(string $dir): array
    {
        $files = [];
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS)) as $file) {
            $name = $file->getFilename();
            if ($file->isFile() && ! str_starts_with($name, '.') && ! str_starts_with($name, '~$')
                && ! in_array(strtolower($name), self::SKIP, true)) {
                $files[] = $file->getPathname();
            }
        }
        sort($files);

        return $files;
    }
}
