<?php

namespace App\Console\Commands;

use App\Http\Controllers\DocumentController;
use Illuminate\Console\Command;

class PorfiryTemplates extends Command
{
    protected $signature = 'porfiry:templates';

    protected $description = 'Порфирий: проверить шаблоны документов в папке LLM_TEMPLATES_PATH';

    public function handle(): int
    {
        $dir = (string) config('llm.docs.templates_path');
        if (! is_dir($dir)) {
            $this->line("ПРОБЛЕМА  нет папки {$dir}");

            return 1;
        }

        [$list, $problems] = DocumentController::repo()->scan();
        $renderer = DocumentController::renderer();
        foreach ($list as $t) {
            $this->line("OK  {$t['id']} — «{$t['title']}», скачать: " . implode(', ', $renderer->formats($t)));
            foreach ($t['fields'] as $f) {
                $this->line('      ${' . $f['name'] . '}  ' . $f['type'] . ($f['label'] !== $f['name'] ? " — {$f['label']}" : ''));
            }
        }
        foreach ($problems as $file => $messages) {
            foreach ($messages as $message) {
                $this->line("ПРОБЛЕМА  {$file}: {$message}");
            }
        }
        if ($list && count($renderer->formats($list[0])) === 1) {
            $this->line('ВНИМАНИЕ  LibreOffice не найден: PDF и перевод DOCX↔ODT недоступны '
                . '(sudo apt install libreoffice-writer libreoffice-calc)');
        }

        $this->line('');
        $this->line(($problems ? 'ИТОГ: ПРОБЛЕМА' : 'ИТОГ: OK') . ' — шаблонов ' . count($list));

        return $problems ? 1 : 0;
    }
}
