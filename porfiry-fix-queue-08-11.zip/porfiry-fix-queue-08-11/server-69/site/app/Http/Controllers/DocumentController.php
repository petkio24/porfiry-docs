<?php

namespace App\Http\Controllers;

use App\Porfiry\Bin;
use App\Porfiry\Chat\Trace;
use App\Porfiry\Documents\Renderer;
use App\Porfiry\Documents\Templates;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use RuntimeException;
use Symfony\Component\HttpFoundation\HeaderUtils;

/** Документы офисного чата: список шаблонов и готовый файл. Поля заполняет ChatController (template). */
class DocumentController extends Controller
{
    private const MIME = [
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'odt' => 'application/vnd.oasis.opendocument.text',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'pdf' => 'application/pdf',
    ];

    public function templates(): JsonResponse
    {
        $renderer = self::renderer();
        $list = array_map(fn (array $t) => [
            'id' => $t['id'],
            'title' => $t['title'],
            'description' => $t['description'],
            'keywords' => $t['keywords'],
            'fields' => $t['fields'],
            'formats' => $renderer->formats($t),
        ], self::repo()->all());

        return response()->json(['templates' => $list]);
    }

    public function render(Request $request): Response|JsonResponse
    {
        $data = $request->validate([
            'template' => ['required', 'string', 'max:255'],
            'format' => ['required', 'string', 'in:docx,odt,xlsx,pdf'],
            'fields' => ['present', 'array', 'max:200'],
            'fields.*' => ['nullable', 'string', 'max:20000'],
        ]);

        $template = self::repo()->find($data['template']);
        if ($template === null) {
            return response()->json(['message' => 'Шаблон не найден — обновите страницу.'], 404);
        }
        $renderer = self::renderer();
        if (! in_array($data['format'], $renderer->formats($template), true)) {
            return response()->json(['message' => 'Этот формат недоступен: на сервере нет LibreOffice. Скачайте документ в формате '
                . strtoupper($template['format']) . '.'], 422);
        }

        try {
            $bytes = $renderer->render($template, $data['fields'], $data['format']);
        } catch (RuntimeException $e) {
            Trace::write('docs end=error detail=' . $e->getMessage());

            return response()->json(['message' => 'Документ не собран: ' . $e->getMessage()], 503);
        }

        $name = str_replace(['/', '\\'], '-', $template['title']) . ' ' . now(config('llm.timezone'))->format('d.m.Y') . '.' . $data['format'];

        return response($bytes, 200, [
            'Content-Type' => self::MIME[$data['format']],
            'Content-Disposition' => HeaderUtils::makeDisposition('attachment', $name, 'document.' . $data['format']),
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => 'no-store',
        ]);
    }

    public static function repo(): Templates
    {
        return new Templates((string) config('llm.docs.templates_path'));
    }

    public static function renderer(): Renderer
    {
        return new Renderer(Bin::find(config('llm.docs.soffice')), (int) config('llm.docs.convert_timeout'));
    }
}
