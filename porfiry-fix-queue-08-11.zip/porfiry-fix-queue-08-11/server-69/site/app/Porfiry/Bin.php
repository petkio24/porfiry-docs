<?php

namespace App\Porfiry;

/** Поиск программы (soffice, pdftotext) так же, как это делает shell, — по PATH. */
final class Bin
{
    public static function find(?string $name): ?string
    {
        if ($name === null || $name === '') {
            return null;
        }
        if (str_contains($name, '/') || str_contains($name, '\\')) {
            return is_file($name) && is_executable($name) ? $name : null;
        }
        // У Apache бывает пустой PATH — тогда обычные каталоги.
        $path = (string) getenv('PATH') ?: '/usr/local/bin:/usr/bin:/bin';
        foreach (explode(PATH_SEPARATOR, $path) as $dir) {
            foreach (['', '.exe'] as $ext) {
                $file = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . $name . $ext;
                if ($dir !== '' && is_file($file) && is_executable($file)) {
                    return $file;
                }
            }
        }

        return null;
    }
}
