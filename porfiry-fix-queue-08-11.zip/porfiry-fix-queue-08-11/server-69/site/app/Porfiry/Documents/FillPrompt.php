<?php

namespace App\Porfiry\Documents;

use App\Porfiry\Chat\OllamaRelay;

/** Запрос к модели: заполнить поля шаблона по словам пользователя, ответ — JSON по схеме. */
final class FillPrompt
{
    private const SYSTEM = 'Ты заполняешь поля документа по данным пользователя. Ответь только JSON-объектом '
        . 'с перечисленными полями. Бери сведения только из сообщения пользователя и предыдущей переписки, '
        . 'ничего не выдумывай: если данных для поля нет — пустая строка. Даты пиши как ДД.ММ.ГГГГ. '
        . 'Суммы — цифрами, как у пользователя; если поле просит сумму прописью — напиши её прописью по-русски.';

    public static function body(array $chat, array $messages, array $template): array
    {
        $lines = array_map(fn (array $f) => '- ' . $f['name']
            . ($f['label'] !== $f['name'] ? " ({$f['label']})" : '')
            . ($f['hint'] !== '' ? ": {$f['hint']}" : '')
            . ($f['type'] === 'date' ? ' [дата ДД.ММ.ГГГГ]' : ''), $template['fields']);

        $last = count($messages) - 1;
        $messages[$last]['content'] = "Документ: {$template['title']}\n"
            . 'Сегодня: ' . now(config('llm.timezone'))->format('d.m.Y') . "\n"
            . "Поля:\n" . implode("\n", $lines) . "\n\nДанные пользователя:\n" . $messages[$last]['content'];

        $names = array_column($template['fields'], 'name');
        $body = OllamaRelay::body(['system' => self::SYSTEM, 'options' => ['temperature' => 0]] + $chat, $messages);
        $body['format'] = [
            'type' => 'object',
            'properties' => array_fill_keys($names, ['type' => 'string']),
            'required' => $names,
        ];

        return $body;
    }
}
