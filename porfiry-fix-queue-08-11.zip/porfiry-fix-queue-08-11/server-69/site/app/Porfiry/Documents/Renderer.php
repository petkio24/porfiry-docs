<?php

namespace App\Porfiry\Documents;

use Illuminate\Filesystem\Filesystem;
use RuntimeException;

/** Подставляет значения в поля шаблона; другой формат (PDF, ODT↔DOCX) — через LibreOffice. */
final class Renderer
{
    // Пустое поле — линия, чтобы дописать от руки.
    private const BLANK = '____________';

    private const CONVERT = ['docx' => ['docx', 'odt', 'pdf'], 'odt' => ['odt', 'docx', 'pdf'], 'xlsx' => ['xlsx', 'pdf']];

    private const BREAK = ['docx' => '</w:t><w:br/><w:t xml:space="preserve">', 'odt' => '<text:line-break/>', 'xlsx' => '&#10;'];

    public function __construct(private ?string $soffice, private int $timeout = 120)
    {
    }

    public function formats(array $template): array
    {
        return $this->soffice === null ? [$template['format']] : self::CONVERT[$template['format']];
    }

    /** @return string байты готового файла */
    public function render(array $template, array $values, string $format): string
    {
        if (! in_array($format, $this->formats($template), true)) {
            throw new RuntimeException("формат {$format} недоступен");
        }
        $tmp = sys_get_temp_dir() . '/porfiry-doc-' . bin2hex(random_bytes(8));
        mkdir($tmp, 0700, true);
        try {
            $file = "{$tmp}/document.{$template['format']}";
            if (! copy($template['path'], $file)) {
                throw new RuntimeException('не удалось прочитать шаблон');
            }
            $this->fill($file, $template['format'], $values);
            if ($format !== $template['format']) {
                $file = (new LibreOffice((string) $this->soffice, $this->timeout))->convert($file, $format, $tmp);
            }

            return (string) file_get_contents($file);
        } finally {
            (new Filesystem())->deleteDirectory($tmp);
        }
    }

    private function fill(string $file, string $format, array $values): void
    {
        $zip = Templates::zip($file);
        foreach (Templates::parts($zip, $format) as $part) {
            $xml = Templates::fixMacros((string) $zip->getFromName($part));
            // Один проход: значение с «${…}» внутри повторно не подставляется.
            $xml = preg_replace_callback(Templates::PLACEHOLDER, fn (array $m) => $this->value($values[$m[1]] ?? '', $format), $xml);
            $zip->addFromString($part, $xml);
        }
        if (! $zip->close()) {
            throw new RuntimeException('не удалось записать документ');
        }
    }

    private function value(mixed $raw, string $format): string
    {
        $text = str_replace(["\r\n", "\r"], "\n", is_scalar($raw) ? (string) $raw : '');
        // Символы, запрещённые в XML, и «${» — чтобы значение не стало полем.
        $text = trim(str_replace('${', '{', preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $text)));
        if ($text === '') {
            return self::BLANK;
        }

        return str_replace("\n", self::BREAK[$format], htmlspecialchars($text, ENT_XML1 | ENT_QUOTES, 'UTF-8'));
    }
}
