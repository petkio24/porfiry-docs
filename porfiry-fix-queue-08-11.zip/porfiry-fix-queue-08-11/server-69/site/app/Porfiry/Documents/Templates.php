<?php

namespace App\Porfiry\Documents;

use RuntimeException;
use ZipArchive;

/**
 * Шаблоны документов из папки владельца: DOCX, ODT, XLSX с полями ${Имя}.
 * Рядом может лежать «имя.json» — название, описание, ключевые слова, подписи полей.
 * Шаблон выбирается только из списка папки: путь от пользователя не склеивается.
 */
final class Templates
{
    public const FORMATS = ['docx', 'odt', 'xlsx'];

    public const PLACEHOLDER = '/\$\{([\p{L}\p{N} _.\-]{1,60})\}/u';

    private const PARTS = [
        'docx' => '#^word/(document|header\d*|footer\d*)\.xml$#',
        'odt' => '#^(content|styles)\.xml$#',
        'xlsx' => '#^xl/(sharedStrings|worksheets/sheet\d+)\.xml$#',
    ];

    public function __construct(private string $dir)
    {
    }

    public function all(): array
    {
        return $this->scan()[0];
    }

    public function find(string $id): ?array
    {
        foreach ($this->all() as $template) {
            if ($template['id'] === $id) {
                return $template;
            }
        }

        return null;
    }

    /** @return array{0: list<array>, 1: array<string, list<string>>} шаблоны и замечания по файлам */
    public function scan(): array
    {
        if (! is_dir($this->dir)) {
            return [[], []];
        }
        $files = scandir($this->dir) ?: [];
        sort($files);
        $list = [];
        $problems = [];
        foreach ($files as $file) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            // ~$ — временные файлы открытого Word.
            if (! in_array($ext, self::FORMATS, true) || str_starts_with($file, '.') || str_starts_with($file, '~$')) {
                continue;
            }
            try {
                [$template, $warnings] = $this->load($file, $ext);
                $list[] = $template;
                if ($warnings) {
                    $problems[$file] = $warnings;
                }
            } catch (RuntimeException $e) {
                $problems[$file] = [$e->getMessage()];
            }
        }

        return [$list, $problems];
    }

    public static function zip(string $path, int $flags = 0): ZipArchive
    {
        if (! class_exists(ZipArchive::class)) {
            throw new RuntimeException('в PHP нет модуля zip — установите пакет php8.1-zip');
        }
        $zip = new ZipArchive();
        if ($zip->open($path, $flags) !== true) {
            throw new RuntimeException('файл повреждён или это не DOCX/ODT/XLSX');
        }

        return $zip;
    }

    /** Части архива, где могут стоять поля. */
    public static function parts(ZipArchive $zip, string $format): array
    {
        $parts = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = (string) $zip->getNameIndex($i);
            if (preg_match(self::PARTS[$format], $name)) {
                $parts[] = $name;
            }
        }

        return $parts;
    }

    /** Word и LibreOffice режут «${Имя}» на куски с разметкой — склеиваем (как PhpWord). */
    public static function fixMacros(string $xml): string
    {
        return preg_replace_callback('/\$(?:\{|[^{$]*>\{)[^}$]*\}/U', fn (array $m) => strip_tags($m[0]), $xml);
    }

    private function load(string $file, string $ext): array
    {
        $path = $this->dir . DIRECTORY_SEPARATOR . $file;
        $names = self::placeholders($path, $ext);
        if ($names === []) {
            throw new RuntimeException('в файле нет полей вида ${Имя} — это не шаблон');
        }

        $base = pathinfo($file, PATHINFO_FILENAME);
        $manifest = [];
        $warnings = [];
        $json = $this->dir . DIRECTORY_SEPARATOR . $base . '.json';
        if (is_file($json)) {
            $manifest = json_decode((string) file_get_contents($json), true);
            if (! is_array($manifest)) {
                $warnings[] = "{$base}.json: ошибка в JSON — описание не использовано";
                $manifest = [];
            }
        }
        $described = is_array($manifest['fields'] ?? null) ? $manifest['fields'] : [];
        foreach (array_diff(array_keys($described), $names) as $extra) {
            $warnings[] = "поле «{$extra}» описано в {$base}.json, но в документе его нет";
        }

        $fields = [];
        foreach ($names as $name) {
            $about = is_array($described[$name] ?? null) ? $described[$name] : [];
            $type = $about['type'] ?? null;
            $fields[] = [
                'name' => $name,
                'label' => (string) ($about['label'] ?? $name),
                'hint' => (string) ($about['hint'] ?? ''),
                'type' => in_array($type, ['text', 'longtext', 'date'], true) ? $type : self::guessType($name),
            ];
        }

        return [[
            'id' => $file,
            'path' => $path,
            'format' => $ext,
            'title' => (string) ($manifest['title'] ?? $base),
            'description' => (string) ($manifest['description'] ?? ''),
            'keywords' => array_values(array_filter(array_map('strval', (array) ($manifest['keywords'] ?? [])))),
            'fields' => $fields,
        ], $warnings];
    }

    /** Имена полей в порядке появления в документе. */
    private static function placeholders(string $path, string $ext): array
    {
        $zip = self::zip($path);
        $names = [];
        foreach (self::parts($zip, $ext) as $part) {
            preg_match_all(self::PLACEHOLDER, self::fixMacros((string) $zip->getFromName($part)), $m);
            array_push($names, ...$m[1]);
        }
        $zip->close();

        return array_values(array_unique($names));
    }

    private static function guessType(string $name): string
    {
        $lower = mb_strtolower($name);
        if (str_contains($lower, 'дата')) {
            return 'date';
        }
        foreach (['текст', 'содержание', 'описание', 'условия', 'примечан'] as $long) {
            if (str_contains($lower, $long)) {
                return 'longtext';
            }
        }

        return 'text';
    }
}
