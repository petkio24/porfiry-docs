<?php

namespace App\Porfiry\Kb;

use RuntimeException;

/**
 * Поиск по ГОСТам без внешних служб: документ режется по пунктам, слова приводятся
 * к основам, фрагменты ранжируются по BM25.
 * Индекс — файлы в папке: index.json (словарь основ) и text-{поколение}-{документ}.json
 * (тексты фрагментов, читаются только для найденного).
 * ponytail: словарь читается целиком на каждый вопрос — хватает на сотни ГОСТов;
 * больше или поиск по смыслу — SQLite FTS5 или эмбеддинги (план v2, волна 4).
 */
final class Index
{
    private const CHUNK = 1500;

    private const K1 = 1.2;

    private const B = 0.75;

    private const STOP = [
        'и', 'в', 'во', 'не', 'что', 'он', 'на', 'я', 'с', 'со', 'как', 'а', 'то', 'все', 'она', 'так', 'его',
        'но', 'да', 'ты', 'к', 'у', 'же', 'вы', 'за', 'бы', 'по', 'только', 'ее', 'мне', 'было', 'вот', 'от',
        'меня', 'еще', 'нет', 'о', 'из', 'ему', 'когда', 'даже', 'ну', 'ли', 'если', 'уже', 'или', 'ни',
        'быть', 'был', 'него', 'до', 'вас', 'там', 'потом', 'себя', 'ей', 'может', 'они', 'тут', 'где',
        'есть', 'надо', 'ней', 'для', 'мы', 'тебя', 'их', 'чем', 'была', 'сам', 'чтоб', 'без', 'чего',
        'раз', 'тоже', 'себе', 'под', 'будет', 'ж', 'тогда', 'кто', 'этот', 'того', 'потому', 'этого',
        'какой', 'какая', 'какие', 'каким', 'какое', 'ним', 'здесь', 'этом', 'один', 'мой', 'тем', 'чтобы',
        'нее', 'сейчас', 'были', 'куда', 'зачем', 'всех', 'можно', 'при', 'об', 'другой', 'хоть', 'после',
        'над', 'больше', 'тот', 'через', 'эти', 'нас', 'про', 'всего', 'них', 'много', 'эту', 'моя', 'свою',
        'этой', 'перед', 'том', 'нельзя', 'такой', 'такое', 'такая', 'им', 'более', 'всю', 'между', 'это',
        'мне', 'расскажи', 'скажи', 'пожалуйста', 'нужно', 'нужен', 'нужна',
    ];

    // Окончания: сначала длинные. Основа после отрезания — не короче 3 букв.
    private const ENDINGS = [
        'иями', 'ться',
        'ями', 'ами', 'иях', 'ием', 'ией', 'иям', 'ого', 'его', 'ому', 'ему', 'ыми', 'ими', 'ешь', 'ете', 'ите', 'ают', 'яют', 'уют', 'тся',
        'ой', 'ей', 'ий', 'ый', 'ая', 'яя', 'ое', 'ее', 'ые', 'ие', 'ов', 'ев', 'ам', 'ям', 'ах', 'ях', 'ом', 'ем', 'ую', 'юю',
        'ия', 'ья', 'ию', 'ью', 'ии', 'ть', 'ет', 'ит', 'ут', 'ют', 'ат', 'ят', 'ла', 'ло', 'ли', 'ми',
        'а', 'я', 'о', 'е', 'ы', 'и', 'у', 'ю', 'ь', 'й',
    ];

    private ?array $loaded = null;

    private array $texts = [];

    public function __construct(private string $dir)
    {
    }

    public static function stem(string $word): string
    {
        $word = str_replace('ё', 'е', mb_strtolower($word));
        if (preg_match('/\d/', $word) || mb_strlen($word) <= 3) {
            return $word;
        }
        foreach (self::ENDINGS as $end) {
            $cut = mb_strlen($word) - mb_strlen($end);
            if ($cut >= 3 && mb_substr($word, $cut) === $end) {
                return mb_substr($word, 0, $cut);
            }
        }

        return $word;
    }

    /** Основы слов текста; числа с точками («7.0.5», «4.2») — целиком. */
    public static function terms(string $text): array
    {
        preg_match_all('/\d+(?:\.\d+)*|\p{L}+/u', str_replace('ё', 'е', mb_strtolower($text)), $m);
        $terms = [];
        foreach ($m[0] as $word) {
            if (in_array($word, self::STOP, true) || (mb_strlen($word) < 2 && ! ctype_digit($word))) {
                continue;
            }
            $terms[] = self::stem($word);
        }

        return $terms;
    }

    /** Обозначение документа: «ГОСТ Р 7.0.5—2008» → «ГОСТ Р 7.0.5-2008». */
    public static function docCode(string $text): ?string
    {
        if (! preg_match('/ГОСТ(?:\s+Р)?(?:\s+ИСО(?:\/МЭК)?)?\s+\d+(?:\.\d+)*\s*[-—–]\s*\d{2,4}/u', mb_substr($text, 0, 4000), $m)) {
            return null;
        }

        return preg_replace(['/\s*[-—–]\s*/u', '/\s+/u'], ['-', ' '], $m[0]);
    }

    /**
     * Фрагменты по пунктам: короткие соседи одного родителя склеиваются, длинные режутся.
     *
     * @return list<array{clause: string, text: string}>
     */
    public static function chunks(string $text): array
    {
        $sections = [];
        $current = ['', ''];
        foreach (explode("\n", str_replace(["\r\n", "\r", "\u{00A0}", "\f"], ["\n", "\n", ' ', "\n"], $text)) as $line) {
            // «4.2 Текст» — пункт; «10 мм от края» — нет (после номера строчная буква).
            if (preg_match('/^\s*(\d{1,2}(?:\.\d{1,3}){0,4})\.?\s+[«("A-ZА-ЯЁ]/u', $line, $m)
                || preg_match('/^\s*(Приложение\s+[А-ЯA-Z])\b/u', $line, $m)) {
                if (trim($current[1]) !== '') {
                    $sections[] = $current;
                }
                $current = [$m[1], ''];
            }
            $current[1] .= $line . "\n";
        }
        if (trim($current[1]) !== '') {
            $sections[] = $current;
        }

        $chunks = [];
        $chunk = null;
        foreach ($sections as [$clause, $body]) {
            $body = trim(preg_replace("/\n{3,}/", "\n\n", $body));
            $parent = self::parent($clause);
            $fits = $chunk !== null && mb_strlen($chunk['text']) + mb_strlen($body) <= self::CHUNK;
            // Вступление (до первого пункта) приклеивается к первому пункту.
            if ($fits && ($chunk['clause'] === '' || $chunk['parent'] === $parent)) {
                $chunk['text'] .= "\n" . $body;
                if ($chunk['clause'] === '') {
                    $chunk['clause'] = $clause;
                    $chunk['parent'] = $parent;
                }
                $chunk['last'] = $clause;

                continue;
            }
            if ($chunk !== null) {
                array_push($chunks, ...self::split($chunk));
            }
            $chunk = ['clause' => $clause, 'parent' => $parent, 'last' => $clause, 'text' => $body];
        }
        if ($chunk !== null) {
            array_push($chunks, ...self::split($chunk));
        }

        return $chunks;
    }

    public function exists(): bool
    {
        return is_file($this->dir . '/index.json');
    }

    /** @param list<array{file: string, code: ?string, chunks: list<array{clause: string, text: string}>}> $docs */
    public function build(array $docs): int
    {
        if (! is_dir($this->dir) && ! @mkdir($this->dir, 0775, true) && ! is_dir($this->dir)) {
            throw new RuntimeException("не удалось создать папку индекса {$this->dir}");
        }
        $gen = (string) (int) (microtime(true) * 1000);
        $meta = [];
        $chunks = [];
        $postings = [];
        $total = 0;
        foreach (array_values($docs) as $d => $doc) {
            $meta[] = ['file' => $doc['file'], 'code' => (string) ($doc['code'] ?? '')];
            $texts = [];
            foreach ($doc['chunks'] as $local => $chunk) {
                $terms = self::terms(($doc['code'] ?? '') . "\n" . $chunk['text']);
                $id = count($chunks);
                $chunks[] = [$d, $chunk['clause'], count($terms), $local];
                foreach (array_count_values($terms) as $term => $tf) {
                    $postings[$term][] = $id . ':' . $tf;
                }
                $total += count($terms);
                $texts[] = $chunk['text'];
            }
            self::write("{$this->dir}/text-{$gen}-{$d}.json", $texts);
        }
        self::write("{$this->dir}/index.json", [
            'gen' => $gen,
            'docs' => $meta,
            'chunks' => $chunks,
            'avgdl' => $chunks ? $total / count($chunks) : 0,
            'terms' => (object) array_map(fn (array $list) => implode(',', $list), $postings),
        ]);
        foreach (glob($this->dir . '/text-*.json') ?: [] as $old) {
            if (! str_starts_with(basename($old), "text-{$gen}-")) {
                @unlink($old);
            }
        }

        return count($chunks);
    }

    /** @return list<array{doc: string, file: string, clause: string, text: string, score: float}> */
    public function search(string $query, int $top = 5): array
    {
        $index = $this->load();
        $terms = array_values(array_unique(self::terms($query)));
        if ($index === null || $terms === [] || $index['chunks'] === []) {
            return [];
        }

        $n = count($index['chunks']);
        $scores = [];
        $matched = [];
        foreach ($terms as $term) {
            $list = $index['terms'][$term] ?? null;
            if ($list === null) {
                continue;
            }
            $postings = explode(',', $list);
            $idf = log(1 + ($n - count($postings) + 0.5) / (count($postings) + 0.5));
            foreach ($postings as $posting) {
                [$id, $tf] = explode(':', $posting);
                $norm = 1 - self::B + self::B * $index['chunks'][$id][2] / max(1, $index['avgdl']);
                $scores[$id] = ($scores[$id] ?? 0) + $idf * $tf * (self::K1 + 1) / ($tf + self::K1 * $norm);
                $matched[$id] = ($matched[$id] ?? 0) + 1;
            }
        }

        // Совпасть должна хотя бы половина слов вопроса; номер пункта в вопросе — вперёд.
        $need = max(1, (int) ceil(count($terms) / 2));
        preg_match_all('/\b\d{1,2}(?:\.\d{1,3})+\b/u', $query, $m);
        foreach ($scores as $id => $score) {
            if ($matched[$id] < $need) {
                unset($scores[$id]);

                continue;
            }
            foreach (explode('–', $index['chunks'][$id][1]) as $clause) {
                foreach ($m[0] as $asked) {
                    if ($clause === $asked || str_starts_with($clause, $asked . '.')) {
                        $scores[$id] *= 2;
                    }
                }
            }
        }
        arsort($scores);

        $hits = [];
        $best = $scores ? reset($scores) : 0;
        foreach (array_slice($scores, 0, $top, true) as $id => $score) {
            if ($score < $best * 0.35) {
                break;
            }
            [$d, $clause, , $local] = $index['chunks'][$id];
            $doc = $index['docs'][$d];
            $hits[] = [
                'doc' => $doc['code'] !== '' ? $doc['code'] : $doc['file'],
                'file' => $doc['file'],
                'clause' => (string) $clause,
                'text' => $this->text($index['gen'], $d, $local),
                'score' => round($score, 3),
            ];
        }

        return $hits;
    }

    private function load(): ?array
    {
        if ($this->loaded === null && $this->exists()) {
            $data = json_decode((string) file_get_contents($this->dir . '/index.json'), true);
            $this->loaded = is_array($data) ? $data : null;
        }

        return $this->loaded;
    }

    private function text(string $gen, int $doc, int $local): string
    {
        $this->texts[$doc] ??= json_decode((string) @file_get_contents("{$this->dir}/text-{$gen}-{$doc}.json"), true) ?: [];

        return (string) ($this->texts[$doc][$local] ?? '');
    }

    private static function parent(string $clause): string
    {
        $dot = strrpos($clause, '.');

        return $dot === false ? '' : substr($clause, 0, $dot);
    }

    /** Длинный фрагмент — на куски по абзацам, длинный абзац — по предложениям. */
    private static function split(array $chunk): array
    {
        // Склеенные пункты подписываются диапазоном: «4.1.1–4.1.3».
        if ($chunk['last'] !== $chunk['clause'] && $chunk['clause'] !== '') {
            $chunk['clause'] .= '–' . $chunk['last'];
        }
        if (mb_strlen($chunk['text']) <= self::CHUNK * 1.4) {
            return [['clause' => $chunk['clause'], 'text' => $chunk['text']]];
        }
        $units = [];
        foreach (explode("\n", $chunk['text']) as $paragraph) {
            if (mb_strlen($paragraph) <= self::CHUNK) {
                $units[] = $paragraph;

                continue;
            }
            foreach (preg_split('/(?<=[.!?;])\s+/u', $paragraph) as $sentence) {
                array_push($units, ...mb_str_split($sentence, self::CHUNK));
            }
        }
        $pieces = [];
        $piece = '';
        foreach ($units as $unit) {
            if ($piece !== '' && mb_strlen($piece) + mb_strlen($unit) + 1 > self::CHUNK) {
                $pieces[] = ['clause' => $chunk['clause'], 'text' => trim($piece)];
                $piece = '';
            }
            $piece .= $unit . "\n";
        }
        if (trim($piece) !== '') {
            $pieces[] = ['clause' => $chunk['clause'], 'text' => trim($piece)];
        }

        return $pieces;
    }

    private static function write(string $path, mixed $data): void
    {
        $tmp = $path . '.tmp' . getmypid();
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR);
        if (file_put_contents($tmp, $json) === false || ! rename($tmp, $path)) {
            @unlink($tmp);

            throw new RuntimeException("не удалось записать {$path}");
        }
    }
}
