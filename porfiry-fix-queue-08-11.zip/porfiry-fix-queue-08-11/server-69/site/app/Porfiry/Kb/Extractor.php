<?php

namespace App\Porfiry\Kb;

use App\Porfiry\Documents\LibreOffice;
use App\Porfiry\Documents\Templates;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Process\Exceptions\ProcessTimedOutException;
use Illuminate\Support\Facades\Process;
use RuntimeException;

/** Текст документа для поиска: txt, docx, odt — сами; pdf — pdftotext; doc, rtf — LibreOffice. */
final class Extractor
{
    private const MIN_TEXT = 200;

    private const DOCX = [
        '#</w:p>\s*</w:tc>#' => ' | ', '#</w:tr>#' => "\n", '#</w:p>#' => "\n",
        '#<w:tab[^>]*/>#' => "\t", '#<w:(?:br|cr)[^>]*/>#' => "\n",
    ];

    private const ODT = [
        '#</text:p>\s*</table:table-cell>#' => ' | ', '#</table:table-row>#' => "\n", '#</text:(?:p|h)>#' => "\n",
        '#<text:tab[^>]*/>#' => "\t", '#<text:line-break[^>]*/>#' => "\n", '#<text:s[^>]*/>#' => ' ',
    ];

    public function __construct(private ?string $pdftotext = null, private ?string $soffice = null, private int $timeout = 300)
    {
    }

    public function text(string $path): string
    {
        $text = match (strtolower(pathinfo($path, PATHINFO_EXTENSION))) {
            'txt' => self::utf8((string) file_get_contents($path)),
            'docx' => self::xmlText(self::part($path, 'word/document.xml'), self::DOCX),
            'odt' => self::xmlText(self::part($path, 'content.xml'), self::ODT),
            'pdf' => $this->pdf($path),
            'doc', 'rtf' => $this->viaLibreOffice($path),
            default => throw new RuntimeException('формат не поддерживается (подходят pdf, docx, odt, doc, rtf, txt)'),
        };
        if (mb_strlen(preg_replace('/\s+/u', '', $text)) < self::MIN_TEXT) {
            throw new RuntimeException('текста почти нет — похоже на скан (распознавание сканов не поддерживается)');
        }

        return $text;
    }

    private function pdf(string $path): string
    {
        if ($this->pdftotext === null) {
            throw new RuntimeException('нет программы pdftotext — установите пакет poppler-utils');
        }
        try {
            $result = Process::timeout($this->timeout)->run([$this->pdftotext, '-layout', '-enc', 'UTF-8', $path, '-']);
        } catch (ProcessTimedOutException) {
            throw new RuntimeException("pdftotext не успел за {$this->timeout} с");
        }
        if (! $result->successful()) {
            throw new RuntimeException('pdftotext: ' . mb_substr(trim($result->errorOutput()), 0, 200));
        }

        return self::utf8($result->output());
    }

    private function viaLibreOffice(string $path): string
    {
        if ($this->soffice === null) {
            throw new RuntimeException('для doc и rtf нужен LibreOffice (или сохраните файл как docx/pdf)');
        }
        $tmp = sys_get_temp_dir() . '/porfiry-kb-' . bin2hex(random_bytes(8));
        mkdir($tmp, 0700, true);
        try {
            $copy = $tmp . '/source.' . pathinfo($path, PATHINFO_EXTENSION);
            copy($path, $copy);
            $out = (new LibreOffice($this->soffice, $this->timeout))->convert($copy, 'txt:Text (encoded):UTF8', $tmp);

            return self::utf8((string) file_get_contents($out));
        } finally {
            (new Filesystem())->deleteDirectory($tmp);
        }
    }

    private static function part(string $path, string $name): string
    {
        $zip = Templates::zip($path);
        $xml = $zip->getFromName($name);
        $zip->close();
        if ($xml === false) {
            throw new RuntimeException("в файле нет {$name} — он повреждён или это другой формат");
        }

        return $xml;
    }

    private static function xmlText(string $xml, array $rules): string
    {
        $text = strip_tags(preg_replace(array_keys($rules), array_values($rules), $xml));

        return html_entity_decode($text, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    private static function utf8(string $text): string
    {
        $text = str_replace("\f", "\n", $text);
        if (str_starts_with($text, "\xEF\xBB\xBF")) {
            $text = substr($text, 3);
        }

        return mb_check_encoding($text, 'UTF-8') ? $text : mb_convert_encoding($text, 'UTF-8', 'Windows-1251');
    }
}
