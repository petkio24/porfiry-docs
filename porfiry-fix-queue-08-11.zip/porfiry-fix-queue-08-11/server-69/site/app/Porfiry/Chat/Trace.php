<?php

namespace App\Porfiry\Chat;

use Illuminate\Support\Carbon;

/**
 * Журнал чата: одна строка на ответ — чем кончился, сколько ждали, скорость модели.
 * Текст вопросов, ответов и кода сюда не пишется.
 */
final class Trace
{
    public static function write(string $text): void
    {
        // Управляющие символы (переводы строк из текста ошибок) — в пробел: строка журнала
        // не должна распадаться на «поддельные» строки. Без /u — работает и на битом UTF-8.
        $text = preg_replace('/[\x00-\x1F\x7F]+/', ' ', $text);
        $line = Carbon::now(config('llm.timezone'))->format('Y-m-d H:i:s') . ' ' . $text . "\n";

        // Журнал сайта недоступен (права, нет места) — строка уходит в журнал PHP.
        if (@file_put_contents(config('llm.trace_log'), $line, FILE_APPEND | LOCK_EX) === false) {
            error_log('PORFIRY ' . $line);
        }
    }

    /** Скорость из последней строки потока Ollama: «prompt=N@X t/s eval=N@X t/s». */
    public static function speed(array $chunk): string
    {
        $rate = function (string $count, string $time) use ($chunk): string {
            $n = (int) ($chunk[$count] ?? 0);
            $ns = (int) ($chunk[$time] ?? 0);

            return sprintf('%d@%.1ft/s', $n, $ns > 0 ? $n * 1e9 / $ns : 0);
        };

        return 'prompt=' . $rate('prompt_eval_count', 'prompt_eval_duration')
            . ' eval=' . $rate('eval_count', 'eval_duration');
    }
}
