<?php

namespace App\Porfiry\Chat;

use Closure;
use Throwable;

/**
 * Потоковый POST к Ollama (или исполнителю кода) через ext-curl.
 *
 * Зачем не Guzzle: пока Ollama не прислала первый байт (очередь, разбор длинного
 * вопроса, загрузка модели с диска), Guzzle блокируется и отмену проверить нельзя.
 * cURL вызывает PROGRESSFUNCTION и во время ожидания, и между кусками — оттуда
 * проверяется «Стоп»; вернуть 1 = закрыть соединение, после чего Ollama сама
 * останавливает генерацию. XFERINFOFUNCTION в PHP 8.1 нет, поэтому PROGRESSFUNCTION.
 */
class CurlStream
{
    // Чаще дёргать onTick незачем: отмену и так проверяют раз в 0,5 с.
    private const TICK_INTERVAL = 0.2;

    /**
     * $onData(string $bytes) получает тело ответа кусками по мере прихода.
     * $onTick(): ?string — вернуть причину, чтобы прервать передачу.
     *
     * Итог: ok, reason (null | причина из onTick | ttft | stall | timeout | connect | http | error),
     * http, errno, error, bytes.
     */
    public function post(string $url, array $body, Closure $onData, Closure $onTick, int $timeout): array
    {
        $start = microtime(true);
        $state = [
            'status' => 0, 'firstByteAt' => null, 'lastByteAt' => null, 'tickAt' => 0.0,
            'abort' => null, 'exception' => null, 'errorBody' => '', 'bytes' => 0,
        ];
        $ttft = (int) config('llm.ttft_timeout');
        $stall = (int) config('llm.stall_timeout');

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Expect:'],
            CURLOPT_CONNECTTIMEOUT => (int) config('llm.connect_timeout'),
            CURLOPT_TIMEOUT => $timeout,
            // Серверы моделей в своей сети: системный прокси (http_proxy) не нужен.
            CURLOPT_PROXY => '',
            CURLOPT_NOPROXY => '*',
            CURLOPT_NOSIGNAL => true,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_NOPROGRESS => false,
            CURLOPT_HEADERFUNCTION => function ($ch, string $line) use (&$state): int {
                if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $m)) {
                    $state['status'] = (int) $m[1];
                }

                return strlen($line);
            },
            CURLOPT_WRITEFUNCTION => function ($ch, string $data) use (&$state, $onData): int {
                $now = microtime(true);
                $state['firstByteAt'] ??= $now;
                $state['lastByteAt'] = $now;
                $state['bytes'] += strlen($data);
                if ($state['status'] !== 200) {
                    $state['errorBody'] .= substr($data, 0, 2000 - strlen($state['errorBody']));

                    return strlen($data);
                }
                try {
                    $onData($data);
                } catch (Throwable $e) {
                    // Исключение внутри обратного вызова cURL не пробросит — запоминаем.
                    $state['exception'] = $e;

                    return 0;
                }

                return $state['abort'] === null ? strlen($data) : 0;
            },
            CURLOPT_PROGRESSFUNCTION => function ($ch, $dlTotal, $dlNow, $ulTotal, $ulNow) use (&$state, $onTick, $start, $ttft, $stall): int {
                if ($state['abort'] !== null || $state['exception'] !== null) {
                    return 1;
                }
                $now = microtime(true);
                if ($state['firstByteAt'] === null && $now - $start > $ttft) {
                    $state['abort'] = 'ttft';

                    return 1;
                }
                if ($state['lastByteAt'] !== null && $now - $state['lastByteAt'] > $stall) {
                    $state['abort'] = 'stall';

                    return 1;
                }
                if ($now - $state['tickAt'] < self::TICK_INTERVAL) {
                    return 0;
                }
                $state['tickAt'] = $now;
                try {
                    $state['abort'] = $onTick();
                } catch (Throwable $e) {
                    $state['exception'] = $e;

                    return 1;
                }

                return $state['abort'] === null ? 0 : 1;
            },
        ]);

        curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $connected = curl_getinfo($ch, CURLINFO_CONNECT_TIME) > 0 || $state['status'] > 0;
        curl_close($ch);

        if ($state['exception'] !== null) {
            throw $state['exception'];
        }

        $reason = $state['abort'];
        if ($reason === null && $errno !== 0) {
            $reason = match (true) {
                ! $connected => 'connect',
                $errno === CURLE_OPERATION_TIMEDOUT => 'timeout',
                default => 'error',
            };
        }
        if ($reason === null && $state['status'] !== 200) {
            $reason = 'http';
            $error = trim($state['errorBody']);
        }

        return [
            'ok' => $reason === null,
            'reason' => $reason,
            'http' => $state['status'],
            'errno' => $errno,
            'error' => $error,
            'bytes' => $state['bytes'],
        ];
    }
}
