<?php

namespace App\Porfiry\Chat;

use Illuminate\Cache\FileStore;
use Illuminate\Cache\Repository;
use Illuminate\Filesystem\Filesystem;

/**
 * Свой файловый кэш чата (слоты, очередь, отмена). Не зависит от CACHE_DRIVER сайта:
 * cache:clear и тесты сайта его не стирают.
 */
final class Store
{
    public static function get(): Repository
    {
        return new Repository(new FileStore(new Filesystem(), config('llm.cache_path')));
    }
}
