<?php

namespace App\Porfiry\Chat;

use Closure;
use Illuminate\Cache\Repository;
use Illuminate\Support\Carbon;

/**
 * Отмена ответа. Не зависит от connection_aborted() (на Astra он срабатывал ложно):
 * - «Стоп» в браузере шлёт POST /chat/cancel → ключ отмены;
 * - новый вопрос в том же чате той же вкладки (сессия + номер вкладки) вытесняет
 *   предыдущий (ключ active); другая вкладка или устройство с той же сессией ждёт в очереди;
 * - браузер во время ответа шлёт пульс; без пульса ответ считается брошенным.
 */
final class Cancellation
{
    // Чаще ключи не перечитываем: проверка идёт из цикла потока несколько раз в секунду.
    private const CHECK_INTERVAL = 0.5;

    private Closure $clock;

    private float $checkedAt = -INF;

    private ?string $reason = null;

    public function __construct(
        private Repository $store,
        private string $sid,
        private string $chat,
        private string $rid,
        ?Closure $clock = null,
        private string $tab = ''
    ) {
        $this->clock = $clock ?? static fn (): float => microtime(true);
    }

    /** Для журнала: кусок хэша сессии и номера вкладки — одно устройство спрашивало или разные. */
    public function who(): string
    {
        return substr(sha1($this->sid), 0, 6) . '/' . ($this->tab === '' ? '-' : substr($this->tab, 0, 4));
    }

    public static function cancel(Repository $store, string $sid, string $rid): void
    {
        // Отмена может прийти раньше начала ответа; дольше двух минут её не ждём.
        $store->put(self::cancelKey($sid, $rid), 1, 120);
    }

    public static function ping(Repository $store, string $sid, string $rid): void
    {
        // Пульс пишется, только если ответ ещё жив: чужой rid ключ не заведёт.
        if ($store->has(self::aliveKey($sid, $rid))) {
            $store->put(self::aliveKey($sid, $rid), Carbon::now()->getTimestamp(), self::ttl());
        }
    }

    /** Этот ответ стал текущим в чате; предыдущий ответ того же чата будет вытеснен. */
    public function begin(): void
    {
        // «Стоп» обогнал сам вопрос: такой ответ не начнётся и не должен вытеснять живой.
        if (! $this->store->has(self::cancelKey($this->sid, $this->rid))) {
            $this->store->put($this->activeKey(), $this->rid, self::ttl());
        }
        $this->store->put(self::aliveKey($this->sid, $this->rid), Carbon::now()->getTimestamp(), self::ttl());
    }

    /** Причина остановки: cancelled, replaced, gone или null — ответ продолжается. */
    public function check(): ?string
    {
        $now = ($this->clock)();
        if ($this->reason !== null || $now - $this->checkedAt < self::CHECK_INTERVAL) {
            return $this->reason;
        }
        $this->checkedAt = $now;

        if ($this->store->has(self::cancelKey($this->sid, $this->rid))) {
            return $this->reason = 'cancelled';
        }
        $active = $this->store->get($this->activeKey());
        if ($active !== null && $active !== $this->rid) {
            return $this->reason = 'replaced';
        }
        $alive = $this->store->get(self::aliveKey($this->sid, $this->rid));
        $timeout = (int) config('llm.queue.alive_timeout');
        if ($alive !== null && Carbon::now()->getTimestamp() - (int) $alive > $timeout) {
            return $this->reason = 'gone';
        }

        return null;
    }

    /**
     * Ответ закончен. Ключ active не трогаем: удаление «если там наш rid» не атомарно
     * и могло бы стереть rid нового вопроса. Ключ истекает сам.
     */
    public function finish(): void
    {
        $this->store->forget(self::aliveKey($this->sid, $this->rid));
    }

    private function activeKey(): string
    {
        return "llm:active:{$this->sid}:{$this->tab}:{$this->chat}";
    }

    private static function cancelKey(string $sid, string $rid): string
    {
        return "llm:cancel:{$sid}:{$rid}";
    }

    private static function aliveKey(string $sid, string $rid): string
    {
        return "llm:alive:{$sid}:{$rid}";
    }

    private static function ttl(): int
    {
        return (int) config('llm.queue.max_wait') + (int) config('llm.answer_timeout') + 60;
    }
}
