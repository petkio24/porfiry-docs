<?php

namespace App\Porfiry\Chat;

use Closure;
use Illuminate\Cache\Repository;
use Illuminate\Contracts\Cache\LockTimeoutException;
use Illuminate\Support\Carbon;

/**
 * Не больше max_per_ip ответов сразу с одного адреса в одном чате: один скрипт
 * или зациклившаяся страница не займут все места в очереди.
 * Ответ подтверждает себя сердцебиением; без него через BEAT_TTL выбывает сам.
 */
final class IpLimit
{
    private const BEAT_TTL = 30;

    private string $key;

    public function __construct(private Repository $store, string $chat, string $ip)
    {
        $this->key = "llm:ip:{$chat}:" . sha1($ip);
    }

    /** false — с этого адреса уже идёт max_per_ip ответов (0 — без ограничения). */
    public function enter(string $rid): bool
    {
        return $this->mutex(function () use ($rid): bool {
            $now = Carbon::now()->getTimestamp();
            $active = $this->active($now);
            $max = (int) config('llm.queue.max_per_ip');
            if ($max > 0 && ! isset($active[$rid]) && count($active) >= $max) {
                return false;
            }
            $active[$rid] = $now;
            $this->store->put($this->key, $active, 3600);

            return true;
        }, true);
    }

    public function beat(string $rid): void
    {
        $this->mutex(function () use ($rid): bool {
            $now = Carbon::now()->getTimestamp();
            $active = $this->active($now);
            $active[$rid] = $now;
            $this->store->put($this->key, $active, 3600);

            return true;
        }, true);
    }

    public function leave(string $rid): void
    {
        $this->mutex(function () use ($rid): bool {
            $active = $this->active(Carbon::now()->getTimestamp());
            unset($active[$rid]);
            $this->store->put($this->key, $active, 3600);

            return true;
        }, true);
    }

    private function active(int $now): array
    {
        $active = $this->store->get($this->key, []);

        return array_filter(is_array($active) ? $active : [], fn ($beat) => $now - (int) $beat <= self::BEAT_TTL);
    }

    /** Замок занят дольше 2 с — пропускаем (лимит — защита, а не повод отказать). */
    private function mutex(Closure $callback, bool $fallback): bool
    {
        try {
            return $this->store->lock($this->key . ':mx', 5)->block(2, $callback);
        } catch (LockTimeoutException) {
            return $fallback;
        }
    }
}
