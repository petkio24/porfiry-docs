<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Порфирий</title>

    <link rel="stylesheet" href="{{ asset('vendor/katex/katex.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/highlight/github.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/chat.css') }}?v={{ @filemtime(public_path('css/chat.css')) }}">
</head>
<body>

<div class="chat" id="chat">
    <header class="chat-header">
        <div class="chat-brand">
            <span class="chat-logo">AI</span>
            <div>
                <h1>Ассистент Порфирий</h1>
                <p>Работает внутри сети компании — вопросы никуда не уходят</p>
            </div>
        </div>

        <nav class="chat-tabs" role="tablist">
            @foreach ($chats as $key => $chat)
                <button type="button" class="chat-tab" role="tab" aria-controls="chat-log" data-type="{{ $key }}">{{ $chat['title'] }}</button>
            @endforeach
        </nav>
    </header>

    <main class="chat-log" id="chat-log" role="tabpanel"></main>
    <div class="sr-only" id="chat-status" aria-live="polite"></div>

    <form class="chat-form" id="chat-form">
        <div class="chat-chip" id="chat-chip" hidden></div>
        <textarea id="chat-input" rows="1" placeholder="Задайте вопрос…" aria-label="Вопрос"></textarea>
        <div class="chat-form-bar">
            <span class="chat-hint">Enter — отправить, Shift+Enter — новая строка</span>
            <span class="chat-counter" id="chat-counter"></span>
            <label class="chat-deep" id="chat-deep-wrap" hidden
                   title="Модель сначала рассуждает: точнее в расчётах, но ответ идёт несколько минут">
                <input type="checkbox" id="chat-deep"> Подумать тщательнее
            </label>
            <button type="button" class="btn btn-ghost" id="chat-doc" hidden>Документ</button>
            <button type="button" class="btn btn-ghost" id="chat-new">Новый чат</button>
            <button type="submit" class="btn btn-send" id="chat-send">Отправить</button>
        </div>
    </form>

    <p class="chat-note">Модель может ошибаться. Проверяйте важные факты, числа и код.</p>
</div>

<script>
    window.CHAT_CONFIG = @json($pageConfig);
</script>
<script src="{{ asset('vendor/marked/marked.min.js') }}" defer></script>
<script src="{{ asset('vendor/dompurify/purify.min.js') }}" defer></script>
<script src="{{ asset('vendor/highlight/highlight.min.js') }}" defer></script>
<script src="{{ asset('vendor/highlight/fortran.min.js') }}" defer></script>
<script src="{{ asset('vendor/katex/katex.min.js') }}" defer></script>
<script src="{{ asset('js/documents.js') }}?v={{ @filemtime(public_path('js/documents.js')) }}" defer></script>
<script src="{{ asset('js/chat.js') }}?v={{ @filemtime(public_path('js/chat.js')) }}" defer></script>
</body>
</html>
