<?php

namespace Tests\Porfiry;

use ZipArchive;

/** Маленькие DOCX/ODT/XLSX для тестов: только те части, которые читает код. */
final class OfficeFiles
{
    private const W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"';

    /** Абзац Word; каждая строка — отдельный кусок (run), как их режет Word. */
    public static function p(string ...$runs): string
    {
        $xml = '';
        foreach ($runs as $run) {
            $xml .= '<w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">' . htmlspecialchars($run, ENT_XML1) . '</w:t></w:r>';
        }

        return '<w:p>' . $xml . '</w:p>';
    }

    public static function docx(string $path, string $body): string
    {
        return self::zip($path, [
            '[Content_Types].xml' => '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>',
            'word/document.xml' => '<?xml version="1.0" encoding="UTF-8"?><w:document ' . self::W . '><w:body>' . $body . '</w:body></w:document>',
        ]);
    }

    public static function odt(string $path, string ...$paragraphs): string
    {
        $body = '';
        foreach ($paragraphs as $text) {
            $body .= '<text:p>' . htmlspecialchars($text, ENT_XML1) . '</text:p>';
        }

        return self::zip($path, [
            'mimetype' => 'application/vnd.oasis.opendocument.text',
            'content.xml' => '<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
                . 'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0"><office:body><office:text>' . $body
                . '</office:text></office:body></office:document-content>',
        ]);
    }

    public static function xlsx(string $path, string ...$strings): string
    {
        $items = '';
        foreach ($strings as $text) {
            $items .= '<si><t>' . htmlspecialchars($text, ENT_XML1) . '</t></si>';
        }

        return self::zip($path, [
            '[Content_Types].xml' => '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>',
            'xl/sharedStrings.xml' => '<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' . $items . '</sst>',
            'xl/worksheets/sheet1.xml' => '<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData/></worksheet>',
        ]);
    }

    public static function part(string $path, string $name): string
    {
        $zip = new ZipArchive();
        $zip->open($path);
        $xml = (string) $zip->getFromName($name);
        $zip->close();

        return $xml;
    }

    private static function zip(string $path, array $parts): string
    {
        $zip = new ZipArchive();
        $zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        foreach ($parts as $name => $content) {
            $zip->addFromString($name, $content);
        }
        $zip->close();

        return $path;
    }
}
