<?php

namespace Tests\Porfiry;

use RuntimeException;

/** Поднимает tests/fixtures/fake-ollama.php во встроенном сервере PHP на свободном порту. */
final class FakeOllamaServer
{
    /** @var resource */
    private $process;

    public int $port;

    public function __construct()
    {
        $this->port = $this->freePort();
        $script = base_path('tests/fixtures/fake-ollama.php');
        $this->process = proc_open(
            [PHP_BINARY, '-S', '127.0.0.1:' . $this->port, $script],
            [0 => ['pipe', 'r'], 1 => ['file', $this->nullDevice(), 'w'], 2 => ['file', $this->nullDevice(), 'w']],
            $pipes,
            base_path()
        );
        if (! is_resource($this->process)) {
            throw new RuntimeException('не запустился php -S');
        }
        $this->waitUntilListening();
    }

    public function url(): string
    {
        return 'http://127.0.0.1:' . $this->port;
    }

    public function stop(): void
    {
        if (is_resource($this->process)) {
            proc_terminate($this->process);
            proc_close($this->process);
        }
    }

    private function waitUntilListening(): void
    {
        for ($i = 0; $i < 100; $i++) {
            $socket = @fsockopen('127.0.0.1', $this->port, $errno, $error, 0.1);
            if ($socket) {
                fclose($socket);

                return;
            }
            usleep(50_000);
        }
        throw new RuntimeException('php -S не слушает порт ' . $this->port);
    }

    private function freePort(): int
    {
        $socket = stream_socket_server('tcp://127.0.0.1:0');
        $name = stream_socket_get_name($socket, false);
        fclose($socket);

        return (int) substr($name, strrpos($name, ':') + 1);
    }

    private function nullDevice(): string
    {
        return PHP_OS_FAMILY === 'Windows' ? 'NUL' : '/dev/null';
    }
}
