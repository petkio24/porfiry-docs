<?php

namespace Tests\Porfiry;

use App\Porfiry\Chat\CurlStream;
use Closure;

/**
 * Подмена CurlStream для тестов контроллера: без сети и без сна.
 * Сценарий по адресу сервера модели: строки ответа Ollama или готовый итог (сбой).
 */
class FakeCurlStream extends CurlStream
{
    public array $calls = [];

    /** @param array<string, array{lines?: array, result?: array}> $plans ключ — начало адреса */
    public function __construct(private array $plans)
    {
    }

    public function post(string $url, array $body, Closure $onData, Closure $onTick, int $timeout): array
    {
        $this->calls[] = ['url' => $url, 'body' => $body];
        $plan = $this->plan($url);

        if (isset($plan['result'])) {
            return $plan['result'] + ['ok' => false, 'reason' => 'error', 'http' => 0, 'errno' => 0, 'error' => '', 'bytes' => 0];
        }
        foreach ($plan['lines'] ?? [] as $line) {
            if ($line instanceof Closure) {
                $line();

                continue;
            }
            if (($reason = $onTick()) !== null) {
                return $this->result($reason);
            }
            $onData((is_string($line) ? $line : json_encode($line, JSON_UNESCAPED_UNICODE)) . "\n");
        }

        return $this->result($onTick());
    }

    private function plan(string $url): array
    {
        foreach ($this->plans as $prefix => $plan) {
            if (str_starts_with($url, $prefix)) {
                return $plan;
            }
        }

        return [];
    }

    private function result(?string $reason): array
    {
        return ['ok' => $reason === null, 'reason' => $reason, 'http' => 200, 'errno' => 0, 'error' => '', 'bytes' => 1];
    }
}
