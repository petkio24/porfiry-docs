<?php

namespace Tests\Porfiry;

use Illuminate\Filesystem\Filesystem;

/**
 * Кэш и журнал чата во временной папке: тесты не трогают кэш и журнал сайта,
 * поэтому их можно запускать на работающем сервере.
 */
trait UsesTempStore
{
    protected string $porfiryTmp;

    protected function setUpTempStore(): void
    {
        $this->porfiryTmp = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'porfiry-test-' . bin2hex(random_bytes(6));
        mkdir($this->porfiryTmp, 0777, true);
        config([
            'llm.cache_path' => $this->porfiryTmp . DIRECTORY_SEPARATOR . 'cache',
            'llm.trace_log' => $this->porfiryTmp . DIRECTORY_SEPARATOR . 'porfiry.log',
            // Шаблоны, ГОСТы и индекс — тоже свои: настоящие файлы сервера тесты не видят.
            'llm.docs.templates_path' => $this->porfiryTmp . DIRECTORY_SEPARATOR . 'templates',
            'llm.docs.soffice' => 'porfiry-no-soffice',
            'llm.kb.docs_path' => $this->porfiryTmp . DIRECTORY_SEPARATOR . 'gost',
            'llm.kb.index_path' => $this->porfiryTmp . DIRECTORY_SEPARATOR . 'kb-index',
            'llm.kb.pdftotext' => 'porfiry-no-pdftotext',
        ]);
    }

    protected function tearDownTempStore(): void
    {
        (new Filesystem())->deleteDirectory($this->porfiryTmp);
    }

    protected function traceText(): string
    {
        $file = config('llm.trace_log');

        return is_file($file) ? file_get_contents($file) : '';
    }
}
