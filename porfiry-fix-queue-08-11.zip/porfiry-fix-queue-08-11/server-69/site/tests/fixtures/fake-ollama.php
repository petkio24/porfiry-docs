<?php

// Поддельная Ollama для тестов CurlStream: php -S 127.0.0.1:ПОРТ tests/fixtures/fake-ollama.php
// Поведение задаётся полем "fake" в теле запроса:
//   status       — код ответа (по умолчанию 200);
//   header_delay — секунд до первого байта (заголовки уходят вместе с ним);
//   lines        — строки ответа (каждая с \n);
//   gap          — пауза между строками, с;
//   tail_sleep   — пауза после последней строки, с;
//   log          — файл, куда пишется «gone», если клиент ушёл посреди ответа.
ignore_user_abort(true);
set_time_limit(120);

$request = json_decode((string) file_get_contents('php://input'), true) ?: [];
$fake = $request['fake'] ?? [];
$log = $fake['log'] ?? null;

http_response_code((int) ($fake['status'] ?? 200));
header('Content-Type: application/x-ndjson');
usleep((int) (($fake['header_delay'] ?? 0) * 1e6));

foreach ($fake['lines'] ?? [] as $i => $line) {
    if ($i > 0) {
        usleep((int) (($fake['gap'] ?? 0) * 1e6));
    }
    echo $line, "\n";
    @ob_flush();
    flush();
    if (connection_aborted()) {
        if ($log) {
            file_put_contents($log, "gone\n", FILE_APPEND);
        }
        exit;
    }
}
usleep((int) (($fake['tail_sleep'] ?? 0) * 1e6));
