<?php

namespace Tests\Unit\Documents;

use App\Porfiry\Documents\Templates;
use Illuminate\Filesystem\Filesystem;
use PHPUnit\Framework\TestCase;
use Tests\Porfiry\OfficeFiles;

class TemplatesTest extends TestCase
{
    private string $dir;

    protected function setUp(): void
    {
        $this->dir = sys_get_temp_dir() . '/porfiry-tpl-' . bin2hex(random_bytes(5));
        mkdir($this->dir);
    }

    protected function tearDown(): void
    {
        (new Filesystem())->deleteDirectory($this->dir);
    }

    private function contract(): void
    {
        // Word режет «${Продавец}» на куски — шаблон всё равно читается.
        OfficeFiles::docx("{$this->dir}/Договор.docx", OfficeFiles::p('Продавец: $', '{Прода', 'вец}')
            . OfficeFiles::p('Дата: ${Дата договора}') . OfficeFiles::p('${Условия}, ${Продавец}'));
        file_put_contents("{$this->dir}/Договор.json", json_encode([
            'title' => 'Договор купли-продажи',
            'description' => 'Проба',
            'keywords' => ['договор', 'купли'],
            'fields' => ['Продавец' => ['label' => 'Продавец', 'hint' => 'ФИО полностью'], 'Лишнее' => ['label' => 'Нет в файле']],
        ], JSON_UNESCAPED_UNICODE));
    }

    public function test_lists_template_with_manifest_and_fields_in_document_order(): void
    {
        $this->contract();

        $all = (new Templates($this->dir))->all();

        $this->assertCount(1, $all);
        $this->assertSame('Договор.docx', $all[0]['id']);
        $this->assertSame('Договор купли-продажи', $all[0]['title']);
        $this->assertSame(['договор', 'купли'], $all[0]['keywords']);
        $this->assertSame(['Продавец', 'Дата договора', 'Условия'], array_column($all[0]['fields'], 'name'));
        $this->assertSame('ФИО полностью', $all[0]['fields'][0]['hint']);
    }

    public function test_field_types_guessed_from_names(): void
    {
        $this->contract();

        $types = array_column((new Templates($this->dir))->all()[0]['fields'], 'type', 'name');

        $this->assertSame('date', $types['Дата договора']);
        $this->assertSame('longtext', $types['Условия']);
        $this->assertSame('text', $types['Продавец']);
    }

    public function test_without_manifest_title_is_file_name(): void
    {
        OfficeFiles::odt("{$this->dir}/Заявление на отпуск.odt", 'Прошу предоставить отпуск с ${Дата начала}');
        OfficeFiles::xlsx("{$this->dir}/Счёт.xlsx", 'Покупатель: ${Покупатель}', 'Сумма');

        $all = (new Templates($this->dir))->all();

        $this->assertSame(['Заявление на отпуск', 'Счёт'], array_column($all, 'title'));
        $this->assertSame(['odt', 'xlsx'], array_column($all, 'format'));
        $this->assertSame('Покупатель', $all[1]['fields'][0]['name']);
    }

    public function test_problems_are_reported_not_listed(): void
    {
        $this->contract();
        file_put_contents("{$this->dir}/Битый.docx", 'не архив');
        OfficeFiles::docx("{$this->dir}/Пустой.docx", OfficeFiles::p('Без полей'));
        file_put_contents("{$this->dir}/Кривой.json", '{');

        [$list, $problems] = (new Templates($this->dir))->scan();

        $this->assertSame(['Договор.docx'], array_column($list, 'id'));
        $this->assertArrayHasKey('Битый.docx', $problems);
        $this->assertArrayHasKey('Пустой.docx', $problems);
        $this->assertStringContainsString('Лишнее', implode(' ', $problems['Договор.docx'] ?? []));
    }

    public function test_find_only_by_listed_id(): void
    {
        $this->contract();
        $templates = new Templates($this->dir);

        $this->assertSame('Договор.docx', $templates->find('Договор.docx')['id']);
        $this->assertNull($templates->find('../Договор.docx'));
        $this->assertNull($templates->find('Нет такого.docx'));
    }

    public function test_missing_folder_gives_empty_list(): void
    {
        $this->assertSame([], (new Templates($this->dir . '/нет'))->all());
    }
}
