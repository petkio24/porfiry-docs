<?php

namespace Tests\Unit\Kb;

use App\Porfiry\Kb\Index;
use Illuminate\Filesystem\Filesystem;
use PHPUnit\Framework\TestCase;

class IndexTest extends TestCase
{
    private string $dir;

    private const GOST_LINKS = "ГОСТ Р 7.0.5—2008\nБИБЛИОГРАФИЧЕСКАЯ ССЫЛКА\n"
        . "1 Область применения\nНастоящий стандарт устанавливает общие требования и правила составления библиографической ссылки.\n"
        . "4.1 Библиографическая ссылка является частью справочного аппарата документа.\n"
        . "4.2 Ссылки бывают внутритекстовые, подстрочные и затекстовые.\n";

    private const GOST_TEXTS = "ГОСТ 2.105—95\nОБЩИЕ ТРЕБОВАНИЯ К ТЕКСТОВЫМ ДОКУМЕНТАМ\n"
        . "4.1.1 Текст документа при необходимости разделяют на разделы и подразделы.\n"
        . "4.2 Нумерация страниц документа должна быть сквозной, поля 10 мм от края.\n";

    protected function setUp(): void
    {
        $this->dir = sys_get_temp_dir() . '/porfiry-kb-' . bin2hex(random_bytes(5));
    }

    protected function tearDown(): void
    {
        (new Filesystem())->deleteDirectory($this->dir);
    }

    private function build(): Index
    {
        $index = new Index($this->dir);
        $index->build([
            ['file' => 'ссылки.docx', 'code' => Index::docCode(self::GOST_LINKS), 'chunks' => Index::chunks(self::GOST_LINKS)],
            ['file' => 'тексты.pdf', 'code' => Index::docCode(self::GOST_TEXTS), 'chunks' => Index::chunks(self::GOST_TEXTS)],
        ]);

        return $index;
    }

    public function test_stem_unifies_word_forms(): void
    {
        $this->assertSame(Index::stem('записка'), Index::stem('записки'));
        $this->assertSame(Index::stem('записка'), Index::stem('запиской'));
        $this->assertSame(Index::stem('оформление'), Index::stem('оформления'));
        $this->assertSame(Index::stem('Ёлка'), Index::stem('елки'));
    }

    public function test_terms_skip_stop_words_and_keep_dotted_numbers(): void
    {
        $terms = Index::terms('Что сказано в ГОСТ Р 7.0.5 о ссылке?');

        $this->assertContains('7.0.5', $terms);
        $this->assertNotContains('что', $terms);
        $this->assertNotContains('в', $terms);
    }

    public function test_doc_code_is_found_and_normalized(): void
    {
        $this->assertSame('ГОСТ Р 7.0.5-2008', Index::docCode(self::GOST_LINKS));
        $this->assertSame('ГОСТ 2.105-95', Index::docCode(self::GOST_TEXTS));
        $this->assertNull(Index::docCode('Просто текст без обозначения'));
    }

    public function test_chunks_follow_clauses(): void
    {
        $long = str_repeat('Очень длинный пункт про оформление таблиц. ', 80);
        $chunks = Index::chunks("1 Область\nКоротко.\n2 Ссылки\nТоже коротко.\n3 Таблицы\n{$long}\n4 Конец\nВсё.");

        $clauses = array_column($chunks, 'clause');
        $this->assertSame('1–2', $clauses[0]);
        $this->assertContains('3', $clauses);
        // Короткие соседние пункты склеены, длинный разрезан.
        $this->assertStringContainsString('Тоже коротко', $chunks[0]['text']);
        foreach ($chunks as $chunk) {
            $this->assertLessThanOrEqual(2200, mb_strlen($chunk['text']));
        }
    }

    public function test_numbers_like_10_mm_do_not_start_clause(): void
    {
        $chunks = Index::chunks("5 Поля\nОтступ слева:\n10 мм от края листа.\n" . str_repeat('Текст. ', 300));

        $this->assertSame(['5'], array_values(array_unique(array_column($chunks, 'clause'))));
    }

    public function test_search_finds_clause_by_other_word_forms(): void
    {
        $hits = $this->build()->search('Как составить библиографические ссылки?');

        $this->assertNotEmpty($hits);
        $this->assertSame('ГОСТ Р 7.0.5-2008', $hits[0]['doc']);
        $this->assertStringContainsString('библиографической ссылки', $hits[0]['text']);
    }

    public function test_unrelated_question_finds_nothing(): void
    {
        $this->assertSame([], $this->build()->search('Какая сегодня погода в Москве?'));
    }

    public function test_clause_number_in_question_is_preferred(): void
    {
        $hits = $this->build()->search('Что говорит пункт 4.2 про нумерацию страниц документа?');

        $this->assertSame('ГОСТ 2.105-95', $hits[0]['doc']);
        $this->assertStringStartsWith('4.2', $hits[0]['clause']);
    }

    public function test_missing_index_is_not_an_error(): void
    {
        $index = new Index($this->dir);

        $this->assertFalse($index->exists());
        $this->assertSame([], $index->search('ссылка'));
    }

    public function test_rebuild_removes_old_generation(): void
    {
        $this->build();
        $this->build();

        $files = glob($this->dir . '/*');
        $generations = array_unique(array_map(fn ($f) => preg_replace('/^text-(\d+)-.*$/', '$1', basename($f)), preg_grep('/text-/', $files)));
        $this->assertCount(1, $generations);
    }
}
