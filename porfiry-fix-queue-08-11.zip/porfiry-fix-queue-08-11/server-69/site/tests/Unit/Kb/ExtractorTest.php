<?php

namespace Tests\Unit\Kb;

use App\Porfiry\Kb\Extractor;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Facades\Process;
use RuntimeException;
use Tests\Porfiry\OfficeFiles;
use Tests\TestCase;

class ExtractorTest extends TestCase
{
    private string $dir;

    private string $long;

    protected function setUp(): void
    {
        parent::setUp();
        $this->dir = sys_get_temp_dir() . '/porfiry-ex-' . bin2hex(random_bytes(5));
        mkdir($this->dir);
        $this->long = str_repeat('Требования к оформлению документов. ', 10);
    }

    protected function tearDown(): void
    {
        (new Filesystem())->deleteDirectory($this->dir);
        parent::tearDown();
    }

    public function test_txt_in_utf8_and_cp1251(): void
    {
        file_put_contents("{$this->dir}/a.txt", $this->long);
        file_put_contents("{$this->dir}/b.txt", mb_convert_encoding($this->long, 'Windows-1251', 'UTF-8'));

        $this->assertStringContainsString('Требования', (new Extractor())->text("{$this->dir}/a.txt"));
        $this->assertStringContainsString('Требования', (new Extractor())->text("{$this->dir}/b.txt"));
    }

    public function test_docx_paragraphs_and_table_cells(): void
    {
        $table = '<w:tbl><w:tr><w:tc>' . OfficeFiles::p('Ячейка 1') . '</w:tc><w:tc>' . OfficeFiles::p('Ячейка 2') . '</w:tc></w:tr></w:tbl>';
        OfficeFiles::docx("{$this->dir}/a.docx", OfficeFiles::p('4.1 Первый', ' пункт') . OfficeFiles::p($this->long) . $table);

        $text = (new Extractor())->text("{$this->dir}/a.docx");

        $this->assertStringContainsString("4.1 Первый пункт\n", $text);
        $this->assertStringContainsString('Ячейка 1 | Ячейка 2', $text);
    }

    public function test_odt_paragraphs(): void
    {
        OfficeFiles::odt("{$this->dir}/a.odt", '5 Раздел', $this->long);

        $this->assertStringContainsString("5 Раздел\n", (new Extractor())->text("{$this->dir}/a.odt"));
    }

    public function test_pdf_goes_through_pdftotext_with_argument_array(): void
    {
        file_put_contents("{$this->dir}/a.pdf", '%PDF-1.4');
        Process::fake(['*' => Process::result($this->long)]);

        $text = (new Extractor('pdftotext'))->text("{$this->dir}/a.pdf");

        $this->assertStringContainsString('Требования', $text);
        Process::assertRan(fn ($process) => $process->command === ['pdftotext', '-layout', '-enc', 'UTF-8', "{$this->dir}/a.pdf", '-']);
    }

    public function test_pdf_without_pdftotext_explains_what_to_install(): void
    {
        file_put_contents("{$this->dir}/a.pdf", '%PDF-1.4');

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('poppler-utils');
        (new Extractor(null))->text("{$this->dir}/a.pdf");
    }

    public function test_scan_without_text_is_reported(): void
    {
        file_put_contents("{$this->dir}/a.pdf", '%PDF-1.4');
        Process::fake(['*' => Process::result("\f\f")]);

        $this->expectExceptionMessage('скан');
        (new Extractor('pdftotext'))->text("{$this->dir}/a.pdf");
    }

    public function test_unknown_format_rejected(): void
    {
        file_put_contents("{$this->dir}/a.djvu", 'x');

        $this->expectExceptionMessage('не поддерживается');
        (new Extractor())->text("{$this->dir}/a.djvu");
    }

    public function test_broken_docx_reported(): void
    {
        file_put_contents("{$this->dir}/a.docx", 'не архив');

        $this->expectException(RuntimeException::class);
        (new Extractor())->text("{$this->dir}/a.docx");
    }
}
