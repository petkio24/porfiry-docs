<?php

namespace Tests\Unit\Chat;

use App\Porfiry\Chat\Store;
use App\Porfiry\Chat\Trace;
use Illuminate\Support\Facades\Cache;
use Tests\Porfiry\UsesTempStore;
use Tests\TestCase;

class StoreTraceTest extends TestCase
{
    use UsesTempStore;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTempStore();
    }

    protected function tearDown(): void
    {
        $this->tearDownTempStore();
        parent::tearDown();
    }

    public function test_flush_of_default_cache_does_not_touch_porfiry_store(): void
    {
        Store::get()->put('k', 'v', 60);

        Cache::flush();

        $this->assertSame('v', Store::get()->get('k'));
        $this->assertDirectoryExists(config('llm.cache_path'));
    }

    public function test_store_supports_atomic_add_and_locks(): void
    {
        $store = Store::get();

        $this->assertTrue($store->add('slot', 'a', 60));
        $this->assertFalse($store->add('slot', 'b', 60));
        $this->assertSame('a', $store->get('slot'));

        $lock = $store->lock('mx', 5);
        $this->assertTrue($lock->get());
        $this->assertFalse($store->lock('mx', 5)->get());
        $lock->release();
        $this->assertTrue($store->lock('mx', 5)->get());
    }

    public function test_writes_line_to_configured_file(): void
    {
        Trace::write('chat=office end=done');
        Trace::write("chat=code\nend=cancelled");

        $lines = explode("\n", trim($this->traceText()));
        $this->assertCount(2, $lines);
        $this->assertMatchesRegularExpression('/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d chat=office end=done$/', $lines[0]);
        $this->assertStringEndsWith('chat=code end=cancelled', $lines[1]);
    }

    public function test_falls_back_to_error_log_when_file_unwritable(): void
    {
        config(['llm.trace_log' => $this->porfiryTmp]);
        $errorLog = $this->porfiryTmp . DIRECTORY_SEPARATOR . 'php-error.log';
        $saved = ini_set('error_log', $errorLog);

        try {
            Trace::write('chat=office end=done');
        } finally {
            ini_set('error_log', $saved === false ? '' : $saved);
        }

        $this->assertStringContainsString('PORFIRY', file_get_contents($errorLog));
        $this->assertStringContainsString('chat=office end=done', file_get_contents($errorLog));
    }

    public function test_speed_from_final_ollama_line(): void
    {
        $text = Trace::speed([
            'prompt_eval_count' => 200, 'prompt_eval_duration' => 2_000_000_000,
            'eval_count' => 30, 'eval_duration' => 3_000_000_000,
        ]);

        $this->assertSame('prompt=200@100.0t/s eval=30@10.0t/s', $text);
        $this->assertSame('prompt=0@0.0t/s eval=0@0.0t/s', Trace::speed([]));
    }
}
