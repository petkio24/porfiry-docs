<?php

namespace Tests\Unit\Chat;

use App\Porfiry\Chat\CurlStream;
use RuntimeException;
use Tests\Porfiry\FakeOllamaServer;
use Tests\Porfiry\UsesTempStore;
use Tests\TestCase;

/** Настоящий cURL против поддельной Ollama (php -S). */
class CurlStreamTest extends TestCase
{
    use UsesTempStore;

    // Свой сервер на каждый тест: php -S однопоточный, прерванный запрос
    // прошлого теста задержал бы следующий.
    private ?FakeOllamaServer $server = null;

    protected function setUp(): void
    {
        parent::setUp();
        if (! extension_loaded('curl')) {
            $this->markTestSkipped('нет ext-curl');
        }
        $this->server = new FakeOllamaServer();
        $this->setUpTempStore();
        config(['llm.connect_timeout' => 3, 'llm.ttft_timeout' => 900, 'llm.stall_timeout' => 300]);
    }

    protected function tearDown(): void
    {
        $this->server?->stop();
        $this->tearDownTempStore();
        parent::tearDown();
    }

    private function stream(array $fake, ?\Closure $onData = null, ?\Closure $onTick = null, int $timeout = 60): array
    {
        return (new CurlStream())->post(
            $this->server->url() . '/api/chat',
            ['model' => 'office', 'fake' => $fake],
            $onData ?? fn () => null,
            $onTick ?? fn () => null,
            $timeout
        );
    }

    public function test_delivers_lines_as_they_arrive(): void
    {
        $arrivals = [];
        $text = '';
        $start = microtime(true);

        $result = $this->stream(['lines' => ['{"n":1}', '{"n":2}', '{"n":3}'], 'gap' => 0.4], function (string $data) use (&$arrivals, &$text, $start) {
            $arrivals[] = microtime(true) - $start;
            $text .= $data;
        });

        $this->assertTrue($result['ok'], json_encode($result));
        $this->assertSame("{\"n\":1}\n{\"n\":2}\n{\"n\":3}\n", $text);
        $this->assertGreaterThan(0.6, end($arrivals) - $arrivals[0]);
    }

    public function test_tick_runs_while_waiting_for_headers(): void
    {
        $ticksBeforeData = 0;
        $gotData = false;

        $this->stream(['header_delay' => 1.5, 'lines' => ['{"n":1}']], function () use (&$gotData) {
            $gotData = true;
        }, function () use (&$ticksBeforeData, &$gotData) {
            if (! $gotData) {
                $ticksBeforeData++;
            }

            return null;
        });

        $this->assertGreaterThanOrEqual(2, $ticksBeforeData);
    }

    public function test_abort_during_header_wait_under_one_second(): void
    {
        $start = microtime(true);

        $result = $this->stream(['header_delay' => 6, 'lines' => ['{"n":1}']], null, function () use ($start) {
            return microtime(true) - $start > 1 ? 'cancelled' : null;
        });

        $this->assertFalse($result['ok']);
        $this->assertSame('cancelled', $result['reason']);
        $this->assertLessThan(2.5, microtime(true) - $start);
    }

    public function test_abort_mid_stream_closes_socket(): void
    {
        $log = $this->porfiryTmp . DIRECTORY_SEPARATOR . 'fake.log';
        $lines = array_map(fn ($i) => '{"n":' . $i . '}', range(1, 40));
        $count = 0;

        $result = $this->stream(['lines' => $lines, 'gap' => 0.1, 'log' => $log], function () use (&$count) {
            $count++;
        }, function () use (&$count) {
            return $count >= 3 ? 'cancelled' : null;
        });

        $this->assertSame('cancelled', $result['reason']);
        $this->assertLessThan(15, $count);
        // Поддельная Ollama замечает ушедшего клиента при следующей записи.
        for ($i = 0; $i < 30 && ! is_file($log); $i++) {
            usleep(100_000);
        }
        $this->assertFileExists($log);
    }

    public function test_connect_refused_fails_fast(): void
    {
        $socket = stream_socket_server('tcp://127.0.0.1:0');
        $name = stream_socket_get_name($socket, false);
        fclose($socket);
        $start = microtime(true);

        $result = (new CurlStream())->post('http://' . $name . '/api/chat', [], fn () => null, fn () => null, 60);

        $this->assertSame('connect', $result['reason']);
        $this->assertLessThan(4, microtime(true) - $start);
    }

    public function test_stall_timeout_aborts(): void
    {
        config(['llm.stall_timeout' => 1]);
        $start = microtime(true);

        $result = $this->stream(['lines' => ['{"n":1}'], 'tail_sleep' => 6]);

        $this->assertSame('stall', $result['reason']);
        $this->assertLessThan(4, microtime(true) - $start);
    }

    public function test_slow_first_byte_is_not_stall(): void
    {
        config(['llm.stall_timeout' => 1, 'llm.ttft_timeout' => 5]);

        $result = $this->stream(['header_delay' => 2, 'lines' => ['{"n":1}', '{"n":2}']]);

        $this->assertTrue($result['ok'], json_encode($result));
    }

    public function test_ttft_timeout_aborts(): void
    {
        config(['llm.ttft_timeout' => 1]);

        $result = $this->stream(['header_delay' => 6, 'lines' => ['{"n":1}']]);

        $this->assertSame('ttft', $result['reason']);
    }

    public function test_total_timeout_aborts(): void
    {
        $lines = array_map(fn ($i) => '{"n":' . $i . '}', range(1, 20));

        $result = $this->stream(['lines' => $lines, 'gap' => 0.2], null, null, 1);

        $this->assertSame('timeout', $result['reason']);
    }

    public function test_http_error_reports_body(): void
    {
        $result = $this->stream(['status' => 404, 'lines' => ['{"error":"model \'x\' not found"}']]);

        $this->assertSame('http', $result['reason']);
        $this->assertSame(404, $result['http']);
        $this->assertStringContainsString('not found', $result['error']);
    }

    public function test_exception_in_callback_is_captured_not_lost(): void
    {
        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('сбой разбора');

        $this->stream(['lines' => ['{"n":1}', '{"n":2}']], function () {
            throw new RuntimeException('сбой разбора');
        });
    }
}
