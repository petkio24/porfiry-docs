#!/bin/bash
# Проверка и исправление чата «Порфирия» на веб-сервере 172.19.101.69: файлы чата, .env,
# права на папки, место на диске, журнал, связь с серверами моделей, очередь.
# Что не так — исправляет и пишет «ИСПРАВЛЕНО  где: что было»; чего не исправить
# автоматически — «ПРОБЛЕМА». Повторный запуск безопасен.
#
#   sudo bash fix-web.sh /путь/к/сайту
#
# Запускать, когда чатом никто не пользуется: в конце перезапускаются Apache и PHP,
# идущие ответы оборвутся. Копии всего, что меняется, — в /opt/porfiry/backup-fix-ДАТА.
HERE=$(cd "$(dirname "$0")" && pwd)
SITE=$(cd "${1:-}" 2>/dev/null && pwd)
BAK=/opt/porfiry/backup-fix-$(date +%d%m-%H%M)
FIXED=0
PROBLEMS=0

ok()    { echo "OK  $*"; }
fixed() { echo "ИСПРАВЛЕНО  $*"; FIXED=$((FIXED + 1)); }
warn()  { echo "ВНИМАНИЕ  $*"; }
bad()   { echo "ПРОБЛЕМА  $*"; PROBLEMS=$((PROBLEMS + 1)); }
die()   { echo "ПРОБЛЕМА  $*"; echo "ИТОГ: ПРОБЛЕМА — исправление остановлено, сайт не менялся"; exit 1; }
# Копия файла сайта (путь от папки сайта) перед заменой.
backup() { [ -e "$1" ] || return 0; mkdir -p "$BAK/$(dirname "$1")"; cp -p "$1" "$BAK/$1"; }

[ "$(id -u)" = 0 ] || die "запустите через sudo: sudo bash $0 /путь/к/сайту"
[ -f "$SITE/artisan" ] || die "в «${1:-}» нет artisan — укажите папку сайта"
[ -d "$HERE/site" ] || die "рядом нет папки site — распакуйте архив заново"
[ -f "$SITE/.env" ] || die "в папке сайта нет .env"
cd "$SITE" || exit 1
for f in $(find "$HERE/site" -name '*.php'); do
    php -l "$f" >/dev/null 2>&1 || die "файл $f в архиве повреждён — распакуйте архив заново"
done

# ------------------------------------------------------------------------------
echo "### 1. Файлы чата"
changed=0
while read -r rel; do
    cmp -s "$HERE/site/$rel" "$rel" && continue
    [ -f "$rel" ] && what="отличался от текущей версии" || what="отсутствовал"
    backup "$rel"
    mkdir -p "$(dirname "$rel")"
    cp "$HERE/site/$rel" "$rel"
    fixed "$rel: $what — заменён"
    changed=$((changed + 1))
done < <(cd "$HERE/site" && find . -type f | sed 's#^\./##' | sort)
[ "$changed" = 0 ] && ok "все $(find "$HERE/site" -type f | wc -l) файлов чата — текущей версии"
if grep -q "porfiry.php" routes/web.php; then
    ok "routes/web.php подключает маршруты чата"
else
    backup routes/web.php
    printf "\nrequire __DIR__ . '/porfiry.php';\n" >> routes/web.php
    fixed "routes/web.php: не подключал маршруты чата (routes/porfiry.php) — строка добавлена"
fi

# ------------------------------------------------------------------------------
echo; echo "### 2. Настройки .env"
backup .env
if grep -q $'\r' .env; then
    sed -i 's/\r$//' .env
    fixed ".env: строки с концом Windows (CR) — значения читались с лишним символом, исправлено"
fi
# Значение ключа так, как его видит Laravel: первая строка (следующие игнорируются), без кавычек.
env_get() { grep -E "^$1=" .env | head -1 | cut -d= -f2- | sed -E "s/^[\"']//; s/[\"']$//"; }
env_put() {
    local cur n
    cur=$(env_get "$1")
    n=$(grep -cE "^$1=" .env)
    sed -i "/^$1=/d" .env
    echo "$1=$2" >> .env
    fixed ".env $1: было «${cur}»$([ "$n" -gt 1 ] && echo " (строк с ним: $n)"), стало $2 — $3"
}
if grep -q '^LLM_CODE_' .env; then
    sed -i 's/^LLM_CODE_/LLM_SCIENCE_/' .env
    fixed ".env: строки LLM_CODE_ (старое имя научного чата) — переименованы в LLM_SCIENCE_"
fi
for key in LLM_OFFICE_SLOTS LLM_SCIENCE_SLOTS; do
    n=$(grep -cE "^$key=" .env)
    if [ "$n" = 0 ] || { [ "$n" = 1 ] && [ "$(env_get $key)" = 1 ]; }; then
        ok "$key = 1: модель отвечает одному, остальные ждут в очереди"
    else
        env_put "$key" 1 "сервер модели на процессоре отвечает одному за раз, остальные ждут в очереди"
    fi
done
case "$(env_get SESSION_DRIVER)" in
    array) env_put SESSION_DRIVER file "с array сессия не сохраняется: отмена и очередь путают пользователей" ;;
    *) ok "SESSION_DRIVER = $(env_get SESSION_DRIVER || true)" ;;
esac
if [ "$(env_get SESSION_SECURE_COOKIE)" = true ]; then
    env_put SESSION_SECURE_COOKIE false "сайт работает по HTTP: с true браузер не возвращает сессию"
fi
domain=$(env_get SESSION_DOMAIN)
if [ -n "$domain" ] && [ "$domain" != null ] && ! [[ "$domain" =~ ^[0-9.]+$ ]]; then
    warn ".env SESSION_DOMAIN=$domain — при входе по адресу 172.19.101.69 cookie не уйдёт; проверьте"
fi
[ "$(env_get APP_DEBUG)" = true ] && warn ".env APP_DEBUG=true — при ошибке пользователи видят внутренности сервера (не меняю, решать вам)"

# ------------------------------------------------------------------------------
echo; echo "### 3. Права на папки (сайт работает от www-data)"
for d in storage/logs storage/framework/sessions storage/framework/views storage/framework/cache \
         storage/framework/porfiry-cache storage/app bootstrap/cache; do
    if [ ! -d "$d" ]; then
        mkdir -p "$d"
        fixed "$d: папки не было — создана"
    fi
done
others=$(find storage bootstrap/cache ! -user www-data 2>/dev/null)
locked=$(find storage bootstrap/cache -type d ! -perm -u=rwx 2>/dev/null)
if [ -n "$others$locked" ]; then
    count=$(printf '%s\n%s\n' "$others" "$locked" | grep -c .)
    example=$(printf '%s\n%s\n' "$others" "$locked" | grep . | head -3 | tr '\n' ' ')
    chown -R www-data:www-data storage bootstrap/cache
    chmod -R u+rwX storage bootstrap/cache
    fixed "storage, bootstrap/cache: $count файлов и папок не принадлежали www-data или закрыты на запись"
    echo "      например: $example"
    echo "      (так бывает после команд сайта от root: sudo php artisan ...; запускайте sudo -u www-data php artisan ...)"
else
    ok "storage и bootstrap/cache принадлежат www-data"
fi
DATA=$(env_get LLM_TEMPLATES_PATH); DATA=${DATA:-/srv/porfiry-data/templates}; DATA=$(dirname "$DATA")
if [ -d "$DATA" ]; then
    hidden=$(sudo -u www-data find "$DATA" ! -readable 2>/dev/null; find "$DATA" -type d ! -perm -o=x 2>/dev/null)
    if [ -z "$hidden" ]; then
        ok "$DATA (шаблоны, ГОСТы) сайт читает"
    else
        chmod -R a+rX "$DATA"
        fixed "$DATA: сайт не мог прочитать $(echo "$hidden" | head -2 | tr '\n' ' ')— права на чтение выданы"
    fi
fi

# ------------------------------------------------------------------------------
echo; echo "### 4. Место на диске"
for p in "$SITE" /tmp; do
    mb=$(df -Pm "$p" | awk 'NR==2{print $4}')
    inodes=$(df -Pi "$p" | awk 'NR==2{print $4}')
    if [ "${mb:-0}" -lt 500 ]; then
        bad "на разделе с $p свободно ${mb} МБ — освободите место (крупные журналы: du -sh $SITE/storage/logs/*)"
    elif [ "$inodes" != "-" ] && [ "${inodes:-0}" -lt 10000 ]; then
        bad "на разделе с $p кончаются inode (свободно $inodes) — слишком много мелких файлов"
    else
        ok "раздел с $p: свободно ${mb} МБ"
    fi
done
logs_mb=$(du -sm storage/logs 2>/dev/null | cut -f1)
[ "${logs_mb:-0}" -gt 1024 ] && warn "журналы storage/logs занимают ${logs_mb} МБ — их можно сжать или удалить старые"

# ------------------------------------------------------------------------------
echo; echo "### 5. Журнал чата: чем кончались последние ответы"
LOG=storage/logs/porfiry.log
if [ -f "$LOG" ]; then
    tail -500 "$LOG" | grep -o 'end=[a-z]*' | sort | uniq -c | sort -rn | sed 's/^ */      /'
    replaced=$(tail -500 "$LOG" | grep -c 'end=replaced')
    [ "$replaced" -gt 0 ] && warn "ответов, оборванных новым вопросом: $replaced. Раньше вопрос с другого устройства с той же
      сессией (общий прокси, удалённый стол, вторая вкладка) обрывал чужой ответ — теперь он ждёт в очереди"
    tail -500 "$LOG" | grep -E 'end=(storage|exception|backend|model|cut)' | tail -3 | cut -c1-220 | sed 's/^/      /'
else
    ok "журнала ещё нет"
fi
if [ -f /etc/cron.d/porfiry ] && grep -q "$SITE/storage/framework/porfiry-cache" /etc/cron.d/porfiry; then
    ok "уборка кэша чата по расписанию настроена (/etc/cron.d/porfiry)"
else
    [ -f /etc/cron.d/porfiry ] && cp -p /etc/cron.d/porfiry "$BAK/cron.d-porfiry"
    cat > /etc/cron.d/porfiry <<EOF
# Порфирий: уборка просроченных ключей кэша чата (ставит fix-web.sh)
17 * * * * www-data find $SITE/storage/framework/porfiry-cache -type f -mmin +120 -delete 2>/dev/null
# Порфирий: ночная пересборка поиска по ГОСТам (новые файлы в $DATA/gost)
40 3 * * * www-data cd $SITE && php artisan porfiry:kb-index > storage/logs/porfiry-kb.log 2>&1
EOF
    chmod 644 /etc/cron.d/porfiry
    fixed "/etc/cron.d/porfiry: не было уборки кэша чата для этого сайта — восстановлена"
fi

# ------------------------------------------------------------------------------
echo; echo "### 6. Серверы моделей"
check_model() {
    local name=$1 url=$2 model=$3 tags ps
    tags=$(curl -s --noproxy '*' -m 15 "$url/api/tags")
    if [ -z "$tags" ]; then
        bad "$name: сервер модели $url не отвечает — на нём: sudo bash fix-models.sh (служба, файрвол)"
        return
    fi
    if ! grep -q "\"$model[:\"]" <<<"$tags"; then
        bad "$name: на $url нет модели $model — на нём: sudo bash fix-models.sh"
        return
    fi
    ps=$(curl -s --noproxy '*' -m 15 "$url/api/ps")
    if grep -q "\"$model[:\"]" <<<"$ps"; then
        ok "$name: $url отвечает, модель $model в памяти"
    else
        warn "$name: модель $model не в памяти — первый ответ начнётся через минуты; на сервере модели: sudo bash fix-models.sh"
    fi
}
office_url=$(env_get LLM_OFFICE_URL); science_url=$(env_get LLM_SCIENCE_URL)
office_model=$(env_get LLM_OFFICE_MODEL); science_model=$(env_get LLM_SCIENCE_MODEL)
check_model "Офисный" "${office_url:-http://172.19.101.171:11434}" "${office_model:-office}"
check_model "Научный" "${science_url:-http://172.19.101.170:11434}" "${science_model:-science}"

# ------------------------------------------------------------------------------
echo; echo "### 7. Кэши сайта, состояние очереди, перезапуск"
HAD_CONFIG=no; [ -f bootstrap/cache/config.php ] && HAD_CONFIG=yes
HAD_ROUTES=no; ls bootstrap/cache/routes-*.php >/dev/null 2>&1 && HAD_ROUTES=yes
for c in config:clear route:clear view:clear; do
    sudo -u www-data php artisan "$c" >/dev/null 2>&1 || bad "php artisan $c не прошёл: sudo -u www-data php artisan $c"
done
[ "$HAD_CONFIG" = yes ] && { sudo -u www-data php artisan config:cache >/dev/null 2>&1 || bad "config:cache не прошёл"; }
[ "$HAD_ROUTES" = yes ] && { sudo -u www-data php artisan route:cache >/dev/null 2>&1 || bad "route:cache не прошёл"; }
ok "кэши сайта пересобраны"
# Места и очередь живут в файлах; после перезапуска служб старые записи не нужны.
stale=$(find storage/framework/porfiry-cache -type f 2>/dev/null | wc -l)
find storage/framework/porfiry-cache -mindepth 1 -delete 2>/dev/null
ok "состояние очереди сброшено (файлов: $stale)"
PHPV=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
systemctl is-active --quiet "php$PHPV-fpm" && systemctl restart "php$PHPV-fpm"
if systemctl restart apache2; then
    ok "Apache и PHP перезапущены"
else
    bad "apache2 не перезапустился — sudo apache2ctl configtest"
fi

# ------------------------------------------------------------------------------
echo; echo "### 8. Проверка"
code=$(curl -s --noproxy '*' -o /dev/null -w '%{http_code}' http://127.0.0.1/chat)
[ "$code" = 200 ] && ok "страница /chat открывается" || bad "страница /chat отвечает HTTP $code"
curl -s --noproxy '*' -D - -o /dev/null http://127.0.0.1/chat | grep -qi '^cache-control:.*no-store' \
    && ok "страницу чата не кэшируют прокси (no-store)" \
    || warn "у страницы /chat нет заголовка no-store — проверьте настройки Apache"
echo "--- очередь: второе устройство спрашивает, пока первому отвечают (до 5 минут)"
sudo -u www-data python3 "$HERE/check-web.py" --queue | grep -E '^(OK|ВНИМАНИЕ|ПРОБЛЕМА)' | tee /tmp/porfiry-fix-queue.txt
grep -q '^ПРОБЛЕМА' /tmp/porfiry-fix-queue.txt && PROBLEMS=$((PROBLEMS + 1))
rm -f /tmp/porfiry-fix-queue.txt

echo
[ "$FIXED" -gt 0 ] && echo "Копии изменённых файлов: $BAK"
if [ "$PROBLEMS" -gt 0 ]; then
    echo "ИТОГ: ПРОБЛЕМА — исправлено мест: $FIXED, осталось проблем: $PROBLEMS (строки ПРОБЛЕМА выше)"
    exit 1
fi
[ "$FIXED" -gt 0 ] && echo "ИТОГ: OK — исправлено мест: $FIXED" || echo "ИТОГ: OK — всё было в порядке"
