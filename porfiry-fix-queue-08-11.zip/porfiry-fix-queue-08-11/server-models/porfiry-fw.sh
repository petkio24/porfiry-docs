#!/bin/bash
# Файрвол сервера модели: порты Ollama (и в следующих волнах — поиска и исполнителя)
# открыты только веб-серверу. У Ollama нет паролей: без файрвола любой в сети может
# удалить модель (/api/delete) или загрузить сервер.
#
#   sudo bash porfiry-fw.sh 172.19.101.69            — порт 11434
#   sudo bash porfiry-fw.sh 172.19.101.69 11434 6333 — несколько портов
#   sudo bash porfiry-fw.sh --off                     — снять правила (откат)
#
# Правила живут в своей цепочке PORFIRY и восстанавливаются после перезагрузки
# своей службой porfiry-fw (пакет iptables-persistent не нужен).
set -euo pipefail

say() { echo "$1  $2"; }
die() { echo "ПРОБЛЕМА  $*" >&2; echo "ИТОГ: файрвол не настроен" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "запустите от root: sudo bash $0 ..."
command -v iptables >/dev/null 2>&1 || die "нет iptables (пакет iptables из репозитория Astra)"

CONF=/etc/porfiry-fw.conf
UNIT=/etc/systemd/system/porfiry-fw.service
SELF=/usr/local/sbin/porfiry-fw.sh

remove_rules() {
    while iptables -S INPUT 2>/dev/null | grep -q -- '-j PORFIRY'; do
        rule=$(iptables -S INPUT | grep -- '-j PORFIRY' | head -1 | sed 's/^-A /-D /')
        eval "iptables $rule"
    done
    iptables -F PORFIRY 2>/dev/null || true
    iptables -X PORFIRY 2>/dev/null || true
}

if [ "${1:-}" = --off ]; then
    remove_rules
    systemctl disable porfiry-fw >/dev/null 2>&1 || true
    rm -f "$UNIT" "$CONF"
    systemctl daemon-reload
    say OK "правила PORFIRY сняты, автозапуск убран"
    echo "ИТОГ: файрвол Порфирия выключен"
    exit 0
fi

# Режим службы при загрузке: адрес и порты из сохранённого файла.
BOOT=no
if [ "${1:-}" = --boot ]; then
    BOOT=yes
    [ -f "$CONF" ] || exit 0
    set -- $(cat "$CONF")
fi

WEB_IP="${1:-172.19.101.69}"
shift || true
PORTS="${*:-11434}"
[[ "$WEB_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "неверный адрес веб-сервера: $WEB_IP"
for p in $PORTS; do [[ "$p" =~ ^[0-9]+$ ]] || die "неверный порт: $p"; done

remove_rules
iptables -N PORFIRY
iptables -A PORFIRY -i lo -j ACCEPT
iptables -A PORFIRY -s "$WEB_IP" -j ACCEPT
iptables -A PORFIRY -j DROP
for p in $PORTS; do
    iptables -I INPUT -p tcp --dport "$p" -j PORFIRY
done
say OK "порты $PORTS: разрешены только $WEB_IP и сам сервер"

if [ "$BOOT" = no ]; then
    echo "$WEB_IP $PORTS" > "$CONF"
    [ "$(readlink -f "$0")" = "$SELF" ] || install -m 755 "$0" "$SELF"
    cat > "$UNIT" <<EOF
[Unit]
Description=Porfiry: firewall rules for model ports
After=network-pre.target
Before=network.target ollama.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=$SELF --boot

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable porfiry-fw >/dev/null 2>&1
    say OK "правила восстановятся после перезагрузки (служба porfiry-fw)"
fi

if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q 'Status: active'; then
    say ВНИМАНИЕ "включён ufw. Наши правила стоят раньше его правил, но после «ufw reload» проверьте: sudo iptables -S INPUT | grep PORFIRY"
fi

iptables -S PORFIRY
echo "ИТОГ: OK — к портам $PORTS пускается только $WEB_IP"
