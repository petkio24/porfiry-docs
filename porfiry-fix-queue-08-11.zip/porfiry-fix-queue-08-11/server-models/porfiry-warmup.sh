#!/bin/bash
# Загружает модель в память после старта Ollama, чтобы первый пользователь
# не ждал чтения десятков гигабайт с диска. Запускается службой porfiry-warmup.
# Запуск вручную: sudo /usr/local/sbin/porfiry-warmup.sh office
MODEL="${1:?укажите модель}"
API=http://127.0.0.1:11434

python3 - "$API" "$MODEL" <<'PY'
import json, sys, time, urllib.request
api, model = sys.argv[1], sys.argv[2]
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

def call(path, body=None, timeout=10):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(api + path, data, {'Content-Type': 'application/json'})
    return opener.open(req, timeout=timeout).read().decode()

for _ in range(120):                     # Ollama после старта службы — до 2 минут
    try:
        call('/api/version')
        break
    except Exception:
        time.sleep(1)
start = time.time()
# Запрос без prompt только загружает модель; keep_alive -1 — не выгружать.
call('/api/generate', {'model': model, 'keep_alive': -1}, timeout=1800)
print('porfiry-warmup: модель %s в памяти за %.0f с' % (model, time.time() - start))
PY
