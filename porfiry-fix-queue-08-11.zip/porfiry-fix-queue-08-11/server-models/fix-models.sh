#!/bin/bash
# Проверка и исправление сервера модели «Порфирия»: 172.19.101.171 — офисный,
# 172.19.101.170 — научный. Служба Ollama и её настройки, права на файлы, модель в памяти,
# прогрев после перезагрузки, файрвол, место на диске, пробный ответ.
# Что не так — исправляет и пишет «ИСПРАВЛЕНО  где: что было»; чего не исправить
# автоматически — «ПРОБЛЕМА». Повторный запуск безопасен.
#
#   sudo bash fix-models.sh            — роль сервера определится сама
#   sudo bash fix-models.sh office     — или указать: office (.171) / science (.170)
#
# Если что-то исправлено, Ollama перезапускается и модель грузится заново (до 10 минут):
# запускать, когда чатом никто не пользуется.
HERE=$(cd "$(dirname "$0")" && pwd)
API=http://127.0.0.1:11434
UNIT=/etc/systemd/system/ollama.service
WEB_IP=172.19.101.69
BAK=/opt/porfiry/backup-fix-$(date +%d%m-%H%M)
FIXED=0
PROBLEMS=0
RESTART=no

ok()    { echo "OK  $*"; }
fixed() { echo "ИСПРАВЛЕНО  $*"; FIXED=$((FIXED + 1)); }
warn()  { echo "ВНИМАНИЕ  $*"; }
bad()   { echo "ПРОБЛЕМА  $*"; PROBLEMS=$((PROBLEMS + 1)); }
die()   { echo "ПРОБЛЕМА  $*"; echo "ИТОГ: ПРОБЛЕМА — исправление остановлено"; exit 1; }
backup() { [ -e "$1" ] || return 0; mkdir -p "$BAK"; cp -p "$1" "$BAK/$(basename "$1")"; }
# Действующие строки файла службы: без комментариев и пустых.
effective() { grep -vE '^[[:space:]]*(#|$)' "$1" 2>/dev/null; }

[ "$(id -u)" = 0 ] || die "запустите через sudo: sudo bash $0"
[ -x /usr/bin/ollama ] || [ -f /usr/bin/ollama ] || die "нет /usr/bin/ollama — Ollama не установлена (install-ollama.sh)"

ROLE=${1:-}
if [ -z "$ROLE" ]; then
    ROLE=$(grep -o 'Porfiry: [a-z]*' "$UNIT" 2>/dev/null | awk '{print $2}')
    [ "$ROLE" = code ] && ROLE=science
fi
if [ -z "$ROLE" ]; then
    case " $(hostname -I) " in
        *" 172.19.101.171 "*) ROLE=office ;;
        *" 172.19.101.170 "*) ROLE=science ;;
    esac
fi
case "$ROLE" in
    office|science) ;;
    *) die "не понял, какой это сервер — укажите: sudo bash $0 office  или  sudo bash $0 science" ;;
esac
[ -f "$HERE/ollama-$ROLE.service" ] || die "рядом нет ollama-$ROLE.service — распакуйте архив заново"
echo "Сервер: $(hostname), роль: $ROLE ($([ "$ROLE" = office ] && echo офисный || echo научный) чат)"

# ------------------------------------------------------------------------------
echo; echo "### 1. Настройки службы Ollama ($UNIT)"
if [ "$(effective "$UNIT")" = "$(effective "$HERE/ollama-$ROLE.service")" ]; then
    ok "настройки службы — как в комплекте (по одному ответу за раз, модель не выгружается)"
else
    if [ -f "$UNIT" ]; then
        echo "      отличия (< было, > станет):"
        diff <(effective "$UNIT") <(effective "$HERE/ollama-$ROLE.service") | grep '^[<>]' | sed 's/^/      /'
        what="отличались от комплекта"
    else
        what="файла не было"
    fi
    backup "$UNIT"
    install -m 644 "$HERE/ollama-$ROLE.service" "$UNIT"
    systemctl daemon-reload
    RESTART=yes
    fixed "$UNIT: настройки $what — поставлены из комплекта"
fi
systemctl is-enabled --quiet ollama 2>/dev/null || { systemctl enable ollama >/dev/null 2>&1; fixed "служба ollama не включалась при загрузке — включена"; }

# ------------------------------------------------------------------------------
echo; echo "### 2. Пользователь и права на файлы Ollama"
if ! id ollama >/dev/null 2>&1; then
    useradd -r -s /bin/false -U -m -d /usr/share/ollama ollama
    fixed "не было пользователя ollama — создан"
fi
others=$(find /usr/share/ollama ! -user ollama 2>/dev/null | head -3)
if [ -n "$others" ]; then
    chown -R ollama:ollama /usr/share/ollama
    fixed "/usr/share/ollama (модели): были файлы не пользователя ollama ($(echo "$others" | head -2 | tr '\n' ' ')) — владелец исправлен"
    RESTART=yes
else
    ok "/usr/share/ollama принадлежит ollama"
fi
closed=$(find /usr/bin/ollama /usr/lib/ollama \( -type d ! -perm -o=rx \) -o \( -type f ! -perm -o=r \) 2>/dev/null | head -3)
if [ ! -x /usr/bin/ollama ] || [ -n "$closed" ]; then
    chmod 755 /usr/bin/ollama
    chmod -R a+rX /usr/lib/ollama 2>/dev/null
    fixed "/usr/bin/ollama, /usr/lib/ollama: были закрыты для ollama ($(echo "$closed" | head -2 | tr '\n' ' ')) — права выданы"
    RESTART=yes
else
    ok "программа Ollama доступна пользователю ollama"
fi

# ------------------------------------------------------------------------------
echo; echo "### 3. Служба"
if [ "$RESTART" = yes ] || ! systemctl is-active --quiet ollama; then
    what="перезапущена после исправлений"
    systemctl is-active --quiet ollama || what="не работала — запущена"
    systemctl restart ollama
    for _ in $(seq 60); do curl -s --noproxy '*' -m 2 "$API/api/version" >/dev/null && break; sleep 1; done
    if curl -s --noproxy '*' -m 5 "$API/api/version" >/dev/null; then
        fixed "служба ollama: $what"
    else
        bad "служба ollama не запускается. Журнал: sudo journalctl -u ollama -n 30
      Если там «permission denied», а права в порядке, — мешает МКЦ Astra (решает администратор безопасности)"
    fi
else
    ok "служба ollama работает"
fi

# ------------------------------------------------------------------------------
echo; echo "### 4. Модель"
if ! curl -s --noproxy '*' -m 10 "$API/api/tags" | grep -q "\"$ROLE[:\"]"; then
    bad "в Ollama нет модели $ROLE — нужно заново перенести папку модели (install-ollama.sh $ROLE)"
elif curl -s --noproxy '*' -m 10 "$API/api/ps" | grep -q "\"$ROLE[:\"]"; then
    ok "модель $ROLE в памяти"
else
    echo "      модель $ROLE не в памяти — загружаю (с диска до 10 минут)..."
    started=$(date +%s)
    if curl -s --noproxy '*' -m 1800 "$API/api/generate" -d "{\"model\": \"$ROLE\", \"keep_alive\": -1}" >/dev/null \
        && curl -s --noproxy '*' -m 10 "$API/api/ps" | grep -q "\"$ROLE[:\"]"; then
        fixed "модель $ROLE не была в памяти (первый ответ ждал бы минуты) — загружена за $(( $(date +%s) - started )) с"
    else
        bad "модель $ROLE не загрузилась в память — журнал: sudo journalctl -u ollama -n 30"
    fi
fi
if [ -f /etc/systemd/system/porfiry-warmup.service ] && [ -x /usr/local/sbin/porfiry-warmup.sh ] \
    && grep -q "porfiry-warmup.sh $ROLE\$" /etc/systemd/system/porfiry-warmup.service; then
    systemctl is-enabled --quiet porfiry-warmup 2>/dev/null \
        && ok "после перезагрузки модель загрузится сама (porfiry-warmup)" \
        || { systemctl enable porfiry-warmup >/dev/null 2>&1; fixed "прогрев после перезагрузки был выключен — включён"; }
else
    install -m 755 "$HERE/porfiry-warmup.sh" /usr/local/sbin/porfiry-warmup.sh
    sed "s#@MODEL@#$ROLE#" "$HERE/porfiry-warmup.service" > /etc/systemd/system/porfiry-warmup.service
    systemctl daemon-reload
    systemctl enable porfiry-warmup >/dev/null 2>&1
    fixed "прогрев после перезагрузки (porfiry-warmup) не был настроен на модель $ROLE — настроен"
fi

# ------------------------------------------------------------------------------
echo; echo "### 5. Файрвол: к Ollama пускается только веб-сервер $WEB_IP"
if iptables -S PORFIRY 2>/dev/null | grep -q -- "-s $WEB_IP/32 -j ACCEPT" \
    && iptables -S INPUT 2>/dev/null | grep -q -- '-j PORFIRY'; then
    ok "правила PORFIRY на месте"
else
    if bash "$HERE/porfiry-fw.sh" "$WEB_IP" | grep -q '^ИТОГ: OK'; then
        fixed "правил файрвола не было — порт 11434 снова открыт только для $WEB_IP"
    else
        bad "файрвол не настроился — sudo bash $HERE/porfiry-fw.sh $WEB_IP"
    fi
fi

# ------------------------------------------------------------------------------
echo; echo "### 6. Место на диске"
for p in /usr/share/ollama /; do
    gb=$(df -P --block-size=1G "$p" | awk 'NR==2{print $4}')
    [ "${gb:-0}" -lt 2 ] && bad "на разделе с $p свободно ${gb} ГБ — освободите место" || ok "раздел с $p: свободно ${gb} ГБ"
done

# ------------------------------------------------------------------------------
echo; echo "### 7. Ошибки Ollama за сутки"
errors=$(journalctl -u ollama --since "-1 day" --no-pager 2>/dev/null | grep -iE 'error|panic|fatal|denied|killed' \
    | grep -v 'server config' | tail -3 | cut -c1-200)
[ -n "$errors" ] && { warn "в журнале были ошибки (последние):"; echo "$errors" | sed 's/^/      /'; } || ok "ошибок в журнале нет"

# ------------------------------------------------------------------------------
echo; echo "### 8. Пробный ответ"
answer=$(curl -s --noproxy '*' -m 600 -w '\n%{time_total}' "$API/api/chat" -d "{\"model\": \"$ROLE\", \"stream\": false,
    \"think\": false, \"messages\": [{\"role\": \"user\", \"content\": \"Ответь одним словом: столица России?\"}],
    \"options\": {\"num_predict\": 10}}")
if grep -q '"content"' <<<"$answer"; then
    ok "модель ответила за $(tail -1 <<<"$answer" | awk '{printf "%.1f", $1}') с"
else
    bad "модель не ответила: $(head -c 200 <<<"$answer")"
fi

echo
[ "$FIXED" -gt 0 ] && [ -d "$BAK" ] && echo "Копии изменённых файлов: $BAK"
if [ "$PROBLEMS" -gt 0 ]; then
    echo "ИТОГ: ПРОБЛЕМА — исправлено мест: $FIXED, осталось проблем: $PROBLEMS (строки ПРОБЛЕМА выше)"
    exit 1
fi
[ "$FIXED" -gt 0 ] && echo "ИТОГ: OK — исправлено мест: $FIXED" || echo "ИТОГ: OK — всё было в порядке"
