#!/bin/bash
# Диагностика сервера модели «Порфирия»: процессор, память, Ollama, прогрев, скорость.
#
#   sudo bash diag-models.sh
#
# Всё печатается на экран и сохраняется в /opt/porfiry/diag-<сервер>-<дата-время>.txt —
# этот файл прислать. Замер скорости — 5–10 минут; чат в это время отвечает медленнее,
# поэтому запускать до начала работы.
HERE=$(cd "$(dirname "$0")" && pwd)
OUT=/opt/porfiry/diag-$(hostname)-$(date +%d%m-%H%M).txt
API=http://127.0.0.1:11434

[ "$(id -u)" = 0 ] || { echo "ПРОБЛЕМА  запустите через sudo: sudo bash $0"; exit 1; }
command -v ollama >/dev/null 2>&1 || { echo "ПРОБЛЕМА  на этом сервере нет Ollama"; exit 1; }
mkdir -p /opt/porfiry
exec > >(tee "$OUT") 2>&1

echo "### Сервер: $(hostname), адреса: $(hostname -I), $(date '+%d.%m.%Y %H:%M')"

echo; echo "### Процессор"
LC_ALL=C lscpu | grep -E '^(Model name|CPU\(s\)|Thread|Core|Socket|NUMA node|CPU max MHz|CPU MHz|L3)'
cores=$(LC_ALL=C lscpu | awk -F: '/^Core\(s\) per socket/{gsub(/ /,"",$2); print $2}')
sockets=$(LC_ALL=C lscpu | awk -F: '/^Socket\(s\)/{gsub(/ /,"",$2); print $2}')
phys=$(( ${cores:-0} * ${sockets:-1} ))
logical=$(nproc --all)
echo "физических ядер: $phys, логических потоков: $logical"
grep -qw avx2 /proc/cpuinfo && echo "AVX2: есть" || echo "AVX2: НЕТ — модель работает в разы медленнее"
grep -qw avx512f /proc/cpuinfo && echo "AVX-512: есть" || echo "AVX-512: нет"
echo "режим частоты (governor): $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo 'не задаётся системой')"

echo; echo "### Память"
LC_ALL=C free -g

echo; echo "### Ollama"
ollama --version 2>&1 | tail -1
systemctl show ollama -p Environment --value | tr ' ' '\n' | grep -E 'OLLAMA|LLAMA'
ollama list
echo "--- сейчас в памяти:"
ollama ps

echo; echo "### Прогрев после перезагрузки (porfiry-warmup)"
echo "включён: $(systemctl is-enabled porfiry-warmup 2>&1), состояние: $(systemctl is-active porfiry-warmup 2>&1)"
grep -E '^(Description|ExecStart)' /etc/systemd/system/porfiry-warmup.service 2>/dev/null
journalctl -u porfiry-warmup -n 8 --no-pager 2>/dev/null

echo; echo "### Журнал Ollama за 2 дня (ошибки, загрузка модели, потоки)"
journalctl -u ollama --since "-2 days" --no-pager 2>/dev/null \
    | grep -iE 'error|fail|parallel|n_threads|starting llama|model loaded|offload'     | grep -v 'server config' | cut -c1-250 | tail -20

role=$(ollama list | awk 'NR>1{sub(/:.*/,"",$1); print $1}' | grep -xE 'office|science' | head -1)
if [ -z "$role" ]; then
    echo; echo "ПРОБЛЕМА  нет модели office или science — замер пропущен"
else
    echo; echo "### Замер скорости ($role): потоки — как решит Ollama"
    python3 "$HERE/bench-ollama.py" "$role"
    if [ "$logical" -gt "$phys" ] && [ "$phys" -gt 0 ]; then
        echo; echo "### Замер скорости ($role): все логические потоки ($logical)"
        python3 "$HERE/bench-ollama.py" "$role" --threads "$logical"
    fi
    echo; echo "### Возврат модели к обычным настройкам"
    curl -s --noproxy '*' -m 1800 "$API/api/generate" -d "{\"model\": \"$role\", \"keep_alive\": -1}" >/dev/null \
        && echo "OK  модель $role снова в памяти с настройками по умолчанию"
    ollama ps
fi

echo
echo "ИТОГ: диагностика записана в $OUT — пришлите этот файл"
