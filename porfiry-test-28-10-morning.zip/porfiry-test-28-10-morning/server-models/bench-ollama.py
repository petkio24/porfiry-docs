#!/usr/bin/env python3
"""Замер скорости модели «Порфирия» при разном числе одновременных вопросов.

Запуск на сервере модели (или с веб-сервера, указав --url):
    python3 bench-ollama.py office          — офисный сервер, окно 16384
    python3 bench-ollama.py science         — научный сервер, окно 32768

Печатает суммарную скорость (токенов в секунду на всех), скорость одного ответа,
скорость чтения вопроса и вывод по порогам: OK / ВНИМАНИЕ / ПРОБЛЕМА.
Решение менять число одновременных ответов (OLLAMA_NUM_PARALLEL) принимает владелец.

Python 3.7+, без сторонних библиотек.
"""
import argparse
import json
import sys
import threading
import time
import urllib.request

ROLES = {
    'office': {'ctx': 16384, 'think': False},
    # Скорость меряем без рассуждения: так видно чистое число токенов в секунду.
    'science': {'ctx': 32768, 'think': False},
}
# Потоков процессора на ответ (--threads); None — как решит Ollama (обычно по числу ядер).
NUM_THREAD = None
QUESTION = 'Объясни в пяти предложениях, как устроена очередь сообщений и зачем она нужна.'
# Длинный вопрос (~2 тыс. токенов): так читается вопрос с фрагментами документов.
LONG_TEXT = ('Пункт {n}. Документ оформляется на бланке организации, реквизиты располагаются '
             'в установленном порядке, дата записывается арабскими цифрами. ')
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))

# Пороги приёмки (план v2, §6 А8).
ONE_MIN, FIVE_MIN, PROMPT_MIN = 8.0, 3.0, 40.0
ONE_WEAK, FIVE_WEAK = 4.0, 1.5


def ask(url, model, ctx, think, tokens, question, results, index):
    body = {
        'model': model,
        'stream': False,
        'messages': [{'role': 'user', 'content': question}],
        'options': dict({'num_ctx': ctx, 'num_predict': tokens}, **({'num_thread': NUM_THREAD} if NUM_THREAD else {})),
    }
    if think is not None:
        body['think'] = think
    request = urllib.request.Request(url + '/api/chat', json.dumps(body, ensure_ascii=False).encode('utf-8'),
                                     {'Content-Type': 'application/json'})
    started = time.time()
    try:
        with OPENER.open(request, timeout=3600) as response:
            data = json.loads(response.read().decode('utf-8'))
        results[index] = {
            'ok': True,
            'tokens': data.get('eval_count', 0),
            'eval_s': data.get('eval_duration', 0) / 1e9,
            'prompt': data.get('prompt_eval_count', 0),
            'prompt_s': data.get('prompt_eval_duration', 0) / 1e9,
            'wall_s': time.time() - started,
        }
    except Exception as error:  # отчёт должен показать любой сбой, а не упасть
        results[index] = {'ok': False, 'error': str(error), 'wall_s': time.time() - started}


def run_level(args, level, tokens, question):
    results = [None] * level
    threads = [threading.Thread(target=ask, args=(args.url, args.model, args.ctx, args.think, tokens, question, results, i))
               for i in range(level)]
    started = time.time()
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    wall = time.time() - started
    good = [r for r in results if r and r['ok']]
    per_answer = [r['tokens'] / r['eval_s'] for r in good if r['eval_s'] > 0]
    prompt = [r['prompt'] / r['prompt_s'] for r in good if r['prompt_s'] > 0]
    return {
        'level': level,
        'ok': len(good),
        'errors': [r['error'] for r in results if r and not r['ok']],
        'total_tps': sum(r['tokens'] for r in good) / wall if wall > 0 else 0,
        'answer_tps': sum(per_answer) / len(per_answer) if per_answer else 0,
        'prompt_tps': sum(prompt) / len(prompt) if prompt else 0,
        'wall': wall,
    }


def verdict(level_one, level_five, prompt_tps):
    lines = []
    worst = 'OK'

    def mark(ok, weak, text):
        nonlocal worst
        level = 'OK' if ok else ('ВНИМАНИЕ' if not weak else 'ПРОБЛЕМА')
        if level == 'ПРОБЛЕМА' or (level == 'ВНИМАНИЕ' and worst == 'OK'):
            worst = level
        lines.append('{}  {}'.format(level, text))

    if level_one is not None:
        mark(level_one >= ONE_MIN, level_one < ONE_WEAK,
             'один пользователь: {:.1f} ток/с (норма от {:.0f})'.format(level_one, ONE_MIN))
    if level_five is not None:
        mark(level_five >= FIVE_MIN, level_five < FIVE_WEAK,
             'пятеро сразу: {:.1f} ток/с на ответ (норма от {:.0f})'.format(level_five, FIVE_MIN))
    if prompt_tps is not None:
        mark(prompt_tps >= PROMPT_MIN, prompt_tps < PROMPT_MIN / 4,
             'чтение вопроса: {:.0f} ток/с (норма от {:.0f})'.format(prompt_tps, PROMPT_MIN))
    if worst == 'ПРОБЛЕМА':
        lines.append('Совет: процессор не тянет модель. Варианты — меньше одновременных ответов '
                     '(OLLAMA_NUM_PARALLEL и LLM_*_SLOTS) или запасная модель поменьше (решает владелец).')
    return lines, worst


def main():
    parser = argparse.ArgumentParser(description='Замер скорости модели Порфирия')
    parser.add_argument('role', choices=sorted(ROLES), help='office или science')
    parser.add_argument('--url', default='http://127.0.0.1:11434')
    parser.add_argument('--model', help='по умолчанию — как роль (алиас на сервере)')
    # Ответы идут по одному (OLLAMA_NUM_PARALLEL=1), поэтому по умолчанию — один вопрос.
    parser.add_argument('--levels', default='1', help='сколько вопросов сразу, через запятую')
    parser.add_argument('--threads', type=int, help='потоков процессора на ответ (по умолчанию — как решит Ollama)')
    parser.add_argument('--tokens', type=int, default=150, help='длина каждого ответа в токенах')
    args = parser.parse_args()
    role = ROLES[args.role]
    args.model = args.model or args.role
    args.ctx = role['ctx']
    args.think = role['think']
    levels = [int(x) for x in args.levels.split(',') if x.strip()]
    global NUM_THREAD
    NUM_THREAD = args.threads
    print('Потоков на ответ: {}'.format(args.threads or 'как решит Ollama'))

    print('Прогрев: загрузка модели в память (с HDD — до 15 минут)...')
    warm = run_level(args, 1, 5, QUESTION)
    if warm['errors']:
        print('ПРОБЛЕМА  Ollama не отвечает: ' + warm['errors'][0])
        print('ИТОГ: ПРОБЛЕМА')
        return 1

    print('')
    print('Сразу | Успешно | Всего ток/с | Ток/с на ответ | Время, с')
    print('------+---------+-------------+----------------+---------')
    speeds = {}
    for level in levels:
        r = run_level(args, level, args.tokens, QUESTION)
        speeds[level] = r['answer_tps']
        print('{:>5} | {:>7} | {:>11.1f} | {:>14.1f} | {:>7.0f}'.format(
            r['level'], '{}/{}'.format(r['ok'], level), r['total_tps'], r['answer_tps'], r['wall']))
        for error in r['errors'][:3]:
            print('    ошибка: ' + error)

    long_question = ''.join(LONG_TEXT.format(n=n) for n in range(1, 60)) + '\n\nКратко перескажи главное.'
    long_run = run_level(args, 1, 30, long_question)
    prompt_tps = long_run['prompt_tps'] if long_run['ok'] else None
    print('')
    print('Длинный вопрос (~2 тыс. токенов): чтение {:.0f} ток/с, весь ответ {:.0f} с'.format(
        long_run['prompt_tps'], long_run['wall']))

    lines, worst = verdict(speeds.get(1), speeds.get(5), prompt_tps)
    print('')
    for line in lines:
        print(line)
    print('ИТОГ: ' + worst)
    return 0 if worst != 'ПРОБЛЕМА' else 1


if __name__ == '__main__':
    sys.exit(main())
