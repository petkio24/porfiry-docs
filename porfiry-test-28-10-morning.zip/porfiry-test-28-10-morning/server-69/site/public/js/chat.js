/*
 * Чат с моделями. Обычный JavaScript, без сборки.
 * История каждой вкладки чата хранится в sessionStorage браузера
 * и пропадает при закрытии вкладки. Сервер ничего не хранит.
 */
(function () {
    'use strict';

    var config = window.CHAT_CONFIG;
    var csrf = document.querySelector('meta[name="csrf-token"]').content;

    var STORAGE_PREFIX = 'llm-chat:';
    var HISTORY_MAX = 50;          // записей истории в браузере на один чат
    var PING_MS = config.pingMs || 20000; // пульс открытой страницы, пока идёт ответ
    var STOP_GUARD_MS = 700;       // защита от двойного клика: сразу после отправки «Стоп» не срабатывает
    var STOP_WAIT_MS = 2000;       // сколько ждать ответа на «Стоп», прежде чем оборвать поток
    var SILENCE_MS = 60000;        // сервер шлёт пульс раз в 10 с; минута тишины — связь оборвалась

    var ERRORS = {
        offline: 'Нет связи с сервером. Проверьте сеть и попробуйте ещё раз.',
        broken: 'Сервер прислал повреждённый ответ. Попробуйте ещё раз.',
        cut: 'Ответ прервался. Попробуйте ещё раз.',
        empty: 'Модель вернула пустой ответ. Попробуйте переформулировать вопрос.',
        stale: 'Страница устарела. Обновите её (F5) — текст вопроса сохранится.',
        busy: 'Слишком много запросов. Подождите минуту.',
        lost: 'Ответ не получен: страница была перезагружена во время ответа.',
        rejected: 'Сервер не принял вопрос. Обновите страницу (F5) и попробуйте ещё раз.',
        silent: 'Сервер перестал отвечать. Попробуйте ещё раз.'
    };

    var els = {
        root: document.getElementById('chat'),
        log: document.getElementById('chat-log'),
        status: document.getElementById('chat-status'),
        form: document.getElementById('chat-form'),
        input: document.getElementById('chat-input'),
        counter: document.getElementById('chat-counter'),
        send: document.getElementById('chat-send'),
        newChat: document.getElementById('chat-new'),
        docBtn: document.getElementById('chat-doc'),
        deep: document.getElementById('chat-deep'),
        deepWrap: document.getElementById('chat-deep-wrap'),
        chip: document.getElementById('chat-chip'),
        tabs: document.querySelectorAll('.chat-tab')
    };

    var state = {
        type: null, history: [], controller: null, rid: null,
        startedAt: 0, stopping: false, pingTimer: 0,
        template: null // выбранный шаблон документа: следующий вопрос заполняет его поля
    };
    var docs = window.PorfiryDocs && config.docs ? window.PorfiryDocs : null;

    /* ---------- Хранилище ---------- */

    function load(key, fallback) {
        try {
            var raw = sessionStorage.getItem(STORAGE_PREFIX + key);
            return raw ? JSON.parse(raw) : fallback;
        } catch (e) {
            return fallback; // хранилище недоступно или испорчено — начинаем с чистого
        }
    }

    function save(key, value) {
        try {
            sessionStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
            return true;
        } catch (e) {
            return false; // переполнено или недоступно
        }
    }

    function saveHistory() {
        var list = state.history.slice(-HISTORY_MAX);
        // Переполнено (общий лимит ~5 МБ на сайт) — выбрасываем старые записи, пока не влезет.
        while (!save('history:' + state.type, list) && list.length > 1) {
            list = list.slice(Math.ceil(list.length / 4));
        }
        state.history = list;
    }

    function loadHistory(type) {
        var list = load('history:' + type, []);
        if (!Array.isArray(list)) return [];
        return list.filter(function (m) {
            return m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string';
        });
    }

    function forgetOldChats() {
        // Чаты, которых больше нет: v1 (general, science со старой историей до v2) и «code» (стал science).
        ['general', 'code'].forEach(function (key) {
            try { sessionStorage.removeItem(STORAGE_PREFIX + 'history:' + key); } catch (e) { /* нет хранилища */ }
        });
    }

    /* ---------- Отрисовка Markdown и формул ---------- */

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Формулы: $$...$$, \[...\], \(...\), $...$ (но не «$5 и $10» — после $ не цифра).
    var MATH_RE = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|\$(?!\d)([^\s$](?:[^$\n]*?[^\s$])?)\$/g;
    // Код не трогаем: ```…```, ~~~…~~~ (в том числе ещё не закрытый при потоке) и `…`.
    var CODE_RE = /(```[\s\S]*?(?:```|$)|~~~[\s\S]*?(?:~~~|$)|`[^`\n]*`)/;

    // Заменяет формулы метками до Markdown (иначе он съест обратные слэши LaTeX).
    function protectMath(text, store) {
        return text.split(CODE_RE).map(function (part, i) {
            if (i % 2 === 1) return part; // это код
            return part.replace(MATH_RE, function (m, d1, d2, i1, i2) {
                var isDisplay = d1 !== undefined || d2 !== undefined;
                var tex = d1 || d2 || i1 || i2;
                store.push(katex.renderToString(tex, {
                    displayMode: isDisplay, throwOnError: false,
                    trust: false, strict: 'ignore', maxSize: 20, maxExpand: 500
                }));
                return '%%MATH' + (store.length - 1) + '%%';
            });
        }).join('');
    }

    var PURIFY = {
        // Сырой HTML от модели показывается текстом (см. renderer ниже); формы,
        // стили и картинки запрещены и на случай обхода.
        FORBID_TAGS: ['style', 'form', 'input', 'button', 'textarea', 'select', 'img'],
        ADD_TAGS: ['semantics', 'annotation'], // MathML от KaTeX
        ADD_ATTR: ['encoding', 'target']
    };

    function setupRendering() {
        if (window.marked) {
            marked.use({
                renderer: {
                    html: function (token) {
                        return escapeHtml(typeof token === 'string' ? token : (token.text || token.raw || ''));
                    }
                }
            });
        }
        if (window.DOMPurify) {
            DOMPurify.addHook('afterSanitizeAttributes', function (node) {
                if (node.tagName === 'A') {
                    node.setAttribute('target', '_blank');
                    node.setAttribute('rel', 'noopener noreferrer');
                }
            });
        }
    }

    function renderMarkdown(text) {
        // Без marked или DOMPurify показываем простой текст — небезопасный HTML не выводим.
        if (!window.marked || !window.DOMPurify) {
            return '<p>' + escapeHtml(text).replace(/\n/g, '<br>') + '</p>';
        }
        var math = [];
        var source = window.katex ? protectMath(text, math) : text;
        var html = marked.parse(source, { breaks: true }).replace(/%%MATH(\d+)%%/g, function (m, i) {
            return math[i] || '';
        });
        // Формулы подставлены ДО санитайзера: проверяется всё, что попадёт на страницу.
        return DOMPurify.sanitize(html, PURIFY);
    }

    /* ---------- Код: подсветка и копирование ---------- */

    function enhanceCode(container) {
        container.querySelectorAll('pre > code').forEach(function (code) {
            if (window.hljs) hljs.highlightElement(code);
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'copy-btn';
            btn.textContent = 'Копировать';
            btn.addEventListener('click', function () { copyText(code.textContent, btn); });
            code.parentElement.appendChild(btn);
        });
    }

    function copyText(text, btn) {
        var show = function (label) {
            btn.textContent = label;
            setTimeout(function () { btn.textContent = 'Копировать'; }, 1500);
        };
        var fallback = function () {
            show(legacyCopy(text) ? 'Скопировано' : 'Не вышло — выделите и Ctrl+C');
        };
        // navigator.clipboard работает только по HTTPS; в локальной сети по HTTP — запасной способ.
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(function () { show('Скопировано'); }, fallback);
        } else {
            fallback();
        }
    }

    function legacyCopy(text) {
        var area = document.createElement('textarea');
        area.value = text;
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        var isCopied = false;
        try {
            isCopied = document.execCommand('copy');
        } catch (e) {
            isCopied = false;
        }
        area.remove();
        return isCopied;
    }

    /* ---------- Лента сообщений ---------- */

    function announce(text) {
        if (els.status) els.status.textContent = text;
    }

    function isNearBottom() {
        return els.log.scrollHeight - els.log.scrollTop - els.log.clientHeight < 80;
    }

    function scrollDown() {
        els.log.scrollTop = els.log.scrollHeight;
    }

    // «Источники: [1] ГОСТ …, п. 4.6» — какие фрагменты документов получила модель.
    function sourcesLine(kb) {
        var line = document.createElement('p');
        line.className = 'msg-sources';
        line.textContent = 'Источники: ' + kb.map(function (s) {
            return '[' + s.n + '] ' + s.doc + (s.clause ? ', п. ' + s.clause : '');
        }).join('; ');
        return line;
    }

    function addMessage(role, content, cut, isNew, entry) {
        var wrap = document.createElement('div');
        // Анимация появления — только у нового сообщения, а не у всей ленты при перерисовке.
        wrap.className = 'msg msg-' + role + (isNew ? ' is-new' : '');
        var body = document.createElement('div');
        body.className = 'msg-body';
        if (role === 'assistant' && entry && entry.doc && docs) {
            body.appendChild(docs.card(entry.doc, saveHistory));
        } else if (role === 'assistant') {
            body.innerHTML = renderMarkdown(content);
            enhanceCode(body);
            if (entry && entry.kb && entry.kb.length) body.appendChild(sourcesLine(entry.kb));
            if (cut) {
                var mark = document.createElement('p');
                mark.className = 'msg-cut';
                mark.textContent = cut === 'stop' ? '— ответ остановлен'
                    : (cut === 'length' ? '— ответ обрезан: слишком длинный, попросите продолжить' : '— ответ оборван');
                body.appendChild(mark);
            }
        } else {
            body.textContent = content;
        }
        wrap.appendChild(body);
        els.log.appendChild(wrap);
        return body;
    }

    function addError(text, canRetry) {
        var body = addMessage('error', text, null, true);
        body.parentElement.setAttribute('role', 'alert');
        if (canRetry) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn btn-ghost btn-retry';
            btn.textContent = 'Повторить';
            btn.addEventListener('click', retry);
            body.appendChild(btn);
        }
    }

    // Под последним оборванным ответом — «Повторить» и после перерисовки.
    function addRetry() {
        var wrap = document.createElement('div');
        wrap.className = 'msg msg-retry';
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-ghost btn-retry';
        btn.textContent = 'Повторить';
        btn.addEventListener('click', retry);
        wrap.appendChild(btn);
        els.log.appendChild(wrap);
    }

    function renderEmpty() {
        var chat = config.chats[state.type] || {};
        var greeting = chat.greeting || { title: 'Задайте вопрос', text: '' };
        var box = document.createElement('div');
        box.className = 'empty';

        var title = document.createElement('h2');
        title.textContent = greeting.title;
        var text = document.createElement('p');
        text.textContent = greeting.text;
        var list = document.createElement('div');
        list.className = 'examples';

        (chat.examples || []).forEach(function (example) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'example';
            btn.textContent = example;
            btn.addEventListener('click', function () {
                els.input.value = example;
                onInput();
                els.input.focus();
            });
            list.appendChild(btn);
        });

        box.append(title, text, list);
        els.log.appendChild(box);
    }

    function lastIsDanglingQuestion() {
        var last = state.history[state.history.length - 1];
        return !state.controller && last && last.role === 'user';
    }

    function renderLog(errorText, canRetry) {
        els.log.innerHTML = '';
        if (state.history.length === 0) {
            renderEmpty();
        }
        state.history.forEach(function (m) { addMessage(m.role, m.content, m.cut, false, m); });
        var last = state.history[state.history.length - 1];
        if (errorText) {
            addError(errorText, canRetry);
        } else if (lastIsDanglingQuestion()) {
            addError(ERRORS.lost, true);
        } else if (last && last.role === 'assistant' && last.cut) {
            addRetry();
        }
        scrollDown();
    }

    /* ---------- Вкладки чатов ---------- */

    function softColor(hex) {
        // Светлый оттенок акцента для фона (смесь с белым 88 %).
        var m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
        if (!m) return '';
        var n = parseInt(m[1], 16);
        var mix = function (c) { return Math.round(c + (255 - c) * 0.88); };
        return 'rgb(' + mix(n >> 16) + ',' + mix((n >> 8) & 255) + ',' + mix(n & 255) + ')';
    }

    function selectTab(type) {
        state.type = type;
        state.history = loadHistory(type);
        els.root.dataset.chat = type;
        var accent = config.chats[type].accent;
        if (accent) {
            els.root.style.setProperty('--accent', accent);
            els.root.style.setProperty('--accent-soft', softColor(accent));
        }
        els.tabs.forEach(function (tab) {
            tab.setAttribute('aria-selected', tab.dataset.type === type ? 'true' : 'false');
            tab.tabIndex = tab.dataset.type === type ? 0 : -1;
        });
        save('active', type);
        // «Подумать тщательнее» — только в чате, где модель умеет рассуждать; выбор помним во вкладке.
        if (els.deepWrap) {
            els.deepWrap.hidden = !config.chats[type].thinkToggle;
            els.deep.checked = Boolean(config.chats[type].thinkToggle && load('deep:' + type, false));
        }
        setTemplate(null);
        if (els.docBtn) els.docBtn.hidden = !(docs && type === 'office');
        if (docs && type === 'office') docs.load(); // заранее: подсказки «Составить документ»
        els.input.value = load('draft:' + type, '') || '';
        renderLog();
        onInput();
        els.input.focus();
    }

    /* ---------- Форма ---------- */

    function onInput() {
        els.input.style.height = 'auto';
        els.input.style.height = Math.min(els.input.scrollHeight, 200) + 'px';
        var max = config.chats[state.type].maxInput;
        var length = els.input.value.length;
        els.counter.textContent = length > 0 ? length + ' / ' + max : '';
        els.counter.classList.toggle('is-over', length > max);
        save('draft:' + state.type, els.input.value);
    }

    function setBusy(isBusy) {
        els.send.textContent = isBusy ? 'Стоп' : 'Отправить';
        els.send.disabled = false;
        els.send.classList.toggle('is-stop', isBusy);
        els.newChat.disabled = isBusy;
        if (els.docBtn) els.docBtn.disabled = isBusy;
        els.tabs.forEach(function (tab) { tab.disabled = isBusy; });
    }

    /* ---------- Документы по шаблонам ---------- */

    function setTemplate(template) {
        state.template = template;
        if (!els.chip) return;
        els.chip.hidden = !template;
        els.chip.innerHTML = '';
        els.input.placeholder = template ? 'Опишите данные: кто, что, суммы, даты — или отправьте пустым и заполните поля сами' : 'Задайте вопрос…';
        if (!template) return;
        var label = document.createElement('span');
        label.textContent = 'Документ: «' + template.title + '»';
        var close = document.createElement('button');
        close.type = 'button';
        close.className = 'chip-close';
        close.setAttribute('aria-label', 'Отменить документ');
        close.textContent = '×';
        close.addEventListener('click', function () { setTemplate(null); els.input.focus(); });
        els.chip.append(label, close);
    }

    function newDoc(template, values, note) {
        var doc = { id: template.id, title: template.title, formats: template.formats, fields: template.fields, values: values };
        if (note) doc.note = note;
        return { role: 'assistant', content: docs.summary(doc), doc: doc };
    }

    // Пустое описание — форма без модели: человек заполняет поля сам.
    function manualDoc(template) {
        if (state.history.length === 0) els.log.innerHTML = '';
        state.history.push(newDoc(template, {}, null));
        saveHistory();
        setTemplate(null);
        renderLog();
    }

    // Под ответом офиса — «Составить документ», если вопрос похож на шаблон.
    function offerDocuments(question) {
        docs.load().then(function () {
            var found = docs.match(question);
            if (!found.length || state.controller) return;
            var wrap = document.createElement('div');
            wrap.className = 'msg msg-offer';
            found.slice(0, 3).forEach(function (template) {
                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'btn btn-ghost';
                btn.textContent = 'Составить документ: «' + template.title + '»';
                btn.addEventListener('click', function () {
                    wrap.remove();
                    setTemplate(template);
                    els.input.value = question;
                    onInput();
                    els.input.focus();
                });
                wrap.appendChild(btn);
            });
            els.log.appendChild(wrap);
            scrollDown();
        });
    }

    /* ---------- Отмена ---------- */

    function newRid() {
        // crypto.randomUUID по HTTP недоступен, getRandomValues работает везде.
        var bytes = new Uint8Array(16);
        crypto.getRandomValues(bytes);
        return Array.prototype.map.call(bytes, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
    }

    function postCancel(body) {
        return fetch(config.cancelUrl, {
            method: 'POST',
            keepalive: true,
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': csrf },
            body: JSON.stringify(body)
        }).catch(function () { /* сеть: новый вопрос всё равно вытеснит старый ответ */ });
    }

    function stop() {
        if (!state.controller || state.stopping) return;
        state.stopping = true;
        els.send.textContent = 'Останавливаю…';
        els.send.disabled = true;
        var controller = state.controller;
        // Сначала сервер останавливает модель, потом обрываем поток — но не ждём дольше 2 с.
        var wait = new Promise(function (resolve) { setTimeout(resolve, STOP_WAIT_MS); });
        Promise.race([postCancel({ rid: state.rid }), wait]).then(function () { controller.abort(); });
    }

    function startPing(rid) {
        state.pingTimer = setInterval(function () { postCancel({ rid: rid, alive: 1 }); }, PING_MS);
    }

    /* ---------- Отправка и потоковый ответ ---------- */

    function requestWord(n) {
        var n10 = n % 10, n100 = n % 100;
        return n10 === 1 && n100 !== 11 ? 'запрос'
            : (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14) ? 'запроса' : 'запросов');
    }

    // Для экранного диктора: «В очереди: 3-й, перед вами 3 запроса».
    function queueLabel(place, ahead) {
        var label = 'В очереди: ' + place + '-й';
        return typeof ahead === 'number' && ahead > 0 ? label + ', перед вами ' + ahead + ' ' + requestWord(ahead) : label;
    }

    /* ---------- Карточка очереди ---------- */
    // Место, сколько запросов впереди, сколько ждём и полоса: насколько очередь сдвинулась
    // с момента, когда встали в неё. Сервер присылает место при каждой смене.

    var QUEUE_READY_MS = 1500; // «Ваша очередь» на экране, потом обычная строка состояния

    function queueCard(body, statusLine) {
        var card = document.createElement('div');
        card.className = 'queue-card';
        card.innerHTML = '<div class="queue-num"></div><div><p class="queue-title"></p><p class="queue-sub"></p></div>'
            + '<div class="queue-bar"><div></div></div><p class="queue-moved"></p>';
        statusLine.hidden = true;
        body.appendChild(card);
        var q = { card: card, statusLine: statusLine, startedAt: Date.now(), first: 0, place: 0, ahead: 0, ready: false };
        q.timer = setInterval(function () { drawQueue(q); }, 1000);
        return q;
    }

    function drawQueue(q) {
        var part = function (selector) { return q.card.querySelector(selector); };
        var waited = formatClock(Math.round((Date.now() - q.startedAt) / 1000));
        var moved = Math.max(0, q.first - q.ahead);
        part('.queue-num').textContent = q.ready ? '\u2713' : String(q.place);
        part('.queue-title').textContent = q.ready ? 'Ваша очередь' : (q.place === 1 ? 'Вы следующий' : 'Ваше место в очереди');
        part('.queue-sub').textContent = q.ready ? 'Ждали ' + waited + ' · модель читает вопрос…'
            : 'Перед вами ' + q.ahead + ' ' + requestWord(q.ahead) + ' · ждёте ' + waited;
        part('.queue-bar > div').style.width = q.ready ? '100%' : (q.first ? Math.round(100 * moved / q.first) : 0) + '%';
        part('.queue-moved').textContent = q.ready ? ''
            : (moved > 0 ? 'Очередь сдвинулась на ' + moved + ' из ' + q.first : 'Ждём, пока модель освободится');
    }

    function updateQueue(q, place, ahead) {
        var count = typeof ahead === 'number' ? ahead : place;
        if (place !== q.place) announce(queueLabel(place, count));
        q.place = place;
        q.ahead = count;
        q.first = Math.max(q.first, count);
        drawQueue(q);
    }

    function removeQueue(q) {
        clearInterval(q.timer);
        q.card.remove();
        q.statusLine.hidden = false;
    }

    // Читает строки NDJSON от сервера и раздаёт события.
    // Итог: {done: встретилось ли {"done": true}, cut: пометка сервера (length) или null}.
    async function readStream(response, on) {
        var reader = response.body.getReader();
        var decoder = new TextDecoder();
        var buffer = '';
        var sawDone = false;
        var cut = null;
        for (;;) {
            var chunk = await reader.read();
            if (chunk.done) break;
            on.alive();
            buffer += decoder.decode(chunk.value, { stream: true });
            var pos;
            while ((pos = buffer.indexOf('\n')) !== -1) {
                var line = buffer.slice(0, pos).trim();
                buffer = buffer.slice(pos + 1);
                if (!line) continue;
                var data = JSON.parse(line);
                if (data.error) {
                    var err = new Error(data.error);
                    err.code = data.code || '';
                    throw err;
                }
                if (data.done) {
                    sawDone = true;
                    cut = data.cut || null;
                }
                else if (typeof data.t === 'string') on.text(data.t);
                else if (Array.isArray(data.kb)) on.kb(data.kb);
                else if (data.q) on.queue(data.q, data.ahead);
                else if (data.s === 'model') on.model();
                else if (data.s === 'think') on.think();
                // остальные ключи (пульс {"w":1}, события следующих волн) пропускаем
            }
        }
        return { done: sawDone, cut: cut };
    }

    async function errorFromResponse(response) {
        if (response.status === 419) return new Error(ERRORS.stale);
        var message = '';
        try {
            message = (await response.json()).message || '';
        } catch (e) {
            // ответ не JSON — ниже общее сообщение
        }
        // Свои сообщения сервера — по-русски; английские (стандартные Laravel, «Server Error»)
        // пользователю не показываем.
        if (/[а-яё]/i.test(message)) return new Error(message);
        if (response.status === 429) return new Error(ERRORS.busy);
        if (response.status === 422) return new Error(ERRORS.rejected);
        return new Error('Ошибка сервера (' + response.status + '). Попробуйте ещё раз.');
    }

    function friendlyError(e) {
        if (e instanceof TypeError) return ERRORS.offline;
        if (e instanceof SyntaxError) return ERRORS.broken;
        return e.message;
    }

    function formatClock(seconds) {
        var m = Math.floor(seconds / 60);
        var s = seconds % 60;
        return m + ':' + (s < 10 ? '0' : '') + s;
    }

    async function send(text, template) {
        var chat = config.chats[state.type];
        if (!text.trim() || state.controller) return;
        if (text.length > chat.maxInput) {
            renderLog('Вопрос длиннее ' + chat.maxInput + ' символов — сократите его.');
            return;
        }

        if (state.history.length === 0) els.log.innerHTML = '';
        state.history.push({ role: 'user', content: text });
        saveHistory();
        addMessage('user', text, null, true);
        els.input.value = '';
        onInput();
        setTemplate(null);
        var kb = null;
        var queue = null; // карточка очереди, пока ждём места

        var body = addMessage('assistant', '', null, true);
        var statusLine = document.createElement('span');
        statusLine.className = 'status';
        statusLine.textContent = 'Отправляю';
        body.appendChild(statusLine);
        scrollDown();

        state.rid = newRid();
        state.controller = new AbortController();
        state.startedAt = Date.now();
        state.stopping = false;
        setBusy(true);
        startPing(state.rid);

        var answer = '';
        var frame = 0;
        var clock = 0;
        var phase = 'Модель читает вопрос'; // сменится на «рассуждает», когда модель начнёт думать
        var errorText = null;
        var cut = null;
        var result = { done: false, cut: null };
        var lastByteAt = Date.now();
        var silent = false;
        var controller = state.controller;
        var watchdog = setInterval(function () {
            if (Date.now() - lastByteAt > SILENCE_MS) {
                silent = true;
                controller.abort();
            }
        }, 5000);
        var showStatus = function (label) {
            if (!answer) statusLine.textContent = label;
            announce(label);
        };

        try {
            var response = await fetch(chat.url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': csrf },
                body: JSON.stringify({
                    rid: state.rid,
                    messages: state.history.slice(-config.historyLimit).map(function (m) {
                        return { role: m.role, content: m.content };
                    }),
                    template: template ? template.id : undefined,
                    deep: chat.thinkToggle && els.deep ? els.deep.checked : undefined
                }),
                signal: state.controller.signal
            });
            if (!response.ok) throw await errorFromResponse(response);

            result = await readStream(response, {
                alive: function () { lastByteAt = Date.now(); },
                status: showStatus,
                model: function () {
                    // Очередь подошла: «Ваша очередь» на секунду, затем строка состояния.
                    if (queue) {
                        var shown = queue;
                        shown.ready = true;
                        drawQueue(shown);
                        clearInterval(shown.timer);
                        setTimeout(function () { if (queue === shown) { removeQueue(shown); queue = null; } }, QUEUE_READY_MS);
                    }
                    // Счётчик, пока модель читает вопрос: на процессоре это бывает долго.
                    var since = Date.now();
                    showStatus(phase);
                    clock = setInterval(function () {
                        if (!answer) statusLine.textContent = phase + '… ' + formatClock(Math.round((Date.now() - since) / 1000));
                    }, 1000);
                },
                kb: function (list) { kb = list; },
                queue: function (place, ahead) {
                    queue = queue || queueCard(body, statusLine);
                    updateQueue(queue, place, ahead);
                },
                think: function () { phase = 'Модель рассуждает'; showStatus(phase); },
                text: function (piece) {
                    if (queue) { removeQueue(queue); queue = null; }
                    answer += piece;
                    // Поля документа приходят JSON-ом — показываем форму в конце, не текст.
                    if (template) {
                        statusLine.textContent = 'Заполняю поля документа… ' + answer.length + ' зн.';
                        return;
                    }
                    if (frame) return;
                    // Перерисовываем не чаще кадра экрана, иначе длинный ответ тормозит.
                    frame = requestAnimationFrame(function () {
                        frame = 0;
                        var stick = isNearBottom();
                        body.classList.add('is-streaming');
                        body.innerHTML = renderMarkdown(answer);
                        if (stick) scrollDown();
                    });
                }
            });
            if (!result.done) {
                errorText = ERRORS.cut;
                cut = 'error';
            } else if (result.cut) {
                cut = result.cut;
            }
        } catch (e) {
            if (e.name === 'AbortError' && silent) {
                errorText = ERRORS.silent;
                cut = 'error';
            } else if (e.name === 'AbortError') {
                cut = 'stop';
            } else {
                errorText = friendlyError(e);
                cut = e.code === 'cancelled' ? 'stop' : 'error';
            }
        } finally {
            if (queue) clearInterval(queue.timer);
            clearInterval(clock);
            clearInterval(watchdog);
            clearInterval(state.pingTimer);
            cancelAnimationFrame(frame);
            state.controller = null;
            state.rid = null;
            state.stopping = false;
            setBusy(false);
        }

        var isAnswered = false;
        if (template && result.done && !errorText) {
            var parsed = docs.parseFields(answer, template);
            state.history.push(newDoc(template, parsed.values, parsed.ok ? null : 'Модель не заполнила поля — впишите их сами.'));
        } else if (answer.trim() && !template) {
            var entry = { role: 'assistant', content: answer };
            if (cut) entry.cut = cut;
            if (kb) entry.kb = kb;
            state.history.push(entry);
            isAnswered = !cut;
        } else {
            // Ответа нет — убираем вопрос из истории и возвращаем его в поле, чтобы отправить снова
            // (если пользователь уже набирает новый текст — его не трогаем).
            state.history.pop();
            if (!els.input.value.trim()) {
                els.input.value = text;
                onInput();
            }
            if (!errorText && cut !== 'stop') errorText = ERRORS.empty;
        }
        saveHistory();
        renderLog(errorText, Boolean(errorText) && answer.trim() !== '' && !template);
        announce(errorText || (cut === 'stop' ? 'Ответ остановлен' : 'Ответ получен'));
        if (isAnswered && docs && state.type === 'office') offerDocuments(text);
    }

    function retry() {
        if (state.controller) return;
        var last = state.history[state.history.length - 1];
        if (last && last.role === 'assistant') state.history.pop();
        var question = state.history.pop();
        saveHistory();
        if (question && question.role === 'user') {
            renderLog();
            send(question.content);
        } else {
            renderLog();
        }
    }

    /* ---------- События ---------- */

    els.form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (state.controller) {
            // Остановить можно только кнопкой и не сразу после отправки (двойной клик).
            if (e.submitter === els.send && Date.now() - state.startedAt > STOP_GUARD_MS) stop();
            return;
        }
        if (state.template && !els.input.value.trim()) {
            manualDoc(state.template);
            return;
        }
        send(els.input.value, state.template);
    });

    if (els.deep) {
        els.deep.addEventListener('change', function () { save('deep:' + state.type, els.deep.checked); });
    }

    if (els.docBtn) {
        els.docBtn.addEventListener('click', function () {
            if (docs) docs.pick(els.docBtn, function (template) { setTemplate(template); els.input.focus(); });
        });
    }

    els.input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
            e.preventDefault();
            // Enter только отправляет; идущий ответ он не останавливает.
            if (!state.controller) els.form.requestSubmit();
        }
    });

    els.input.addEventListener('input', onInput);

    els.newChat.addEventListener('click', function () {
        if (state.history.length && !confirm('Начать новый чат? Текущая переписка будет удалена.')) return;
        state.history = [];
        saveHistory();
        renderLog();
        els.input.focus();
    });

    els.tabs.forEach(function (tab) {
        tab.addEventListener('click', function () { selectTab(tab.dataset.type); });
    });

    // Закрыли или перезагрузили страницу посреди ответа — сервер останавливает модель.
    window.addEventListener('pagehide', function () {
        if (!state.controller || !state.rid || !navigator.sendBeacon) return;
        var form = new FormData();
        form.append('_token', csrf);
        form.append('rid', state.rid);
        navigator.sendBeacon(config.cancelUrl, form);
    });

    setupRendering();
    forgetOldChats();
    var saved = load('active', null);
    var isKnown = Object.prototype.hasOwnProperty.call(config.chats, saved);
    selectTab(isKnown ? saved : Object.keys(config.chats)[0]);
})();
