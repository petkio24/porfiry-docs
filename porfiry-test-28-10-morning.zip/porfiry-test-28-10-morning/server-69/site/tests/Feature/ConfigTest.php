<?php

namespace Tests\Feature;

use Tests\TestCase;

class ConfigTest extends TestCase
{
    private const KEYS = [
        'LLM_OFFICE_URL', 'LLM_OFFICE_MODEL', 'LLM_OFFICE_SLOTS', 'LLM_OFFICE_NUM_CTX', 'LLM_OFFICE_NUM_PREDICT',
        'LLM_SCIENCE_URL', 'LLM_SCIENCE_MODEL', 'LLM_SCIENCE_SLOTS', 'LLM_SCIENCE_NUM_CTX', 'LLM_SCIENCE_NUM_PREDICT',
        'LLM_SCIENCE_TEMPERATURE', 'LLM_SCIENCE_TOP_P', 'LLM_SCIENCE_TOP_K', 'LLM_ANSWER_TIMEOUT', 'LLM_QUEUE_MAX_WAIT',
        'LLM_HISTORY_MAX_CHARS', 'LLM_TTFT_TIMEOUT', 'LLM_STALL_TIMEOUT', 'LLM_CONNECT_TIMEOUT',
    ];

    /** config/llm.php, прочитанный с заданными значениями .env. */
    private function load(array $values): array
    {
        $saved = array_intersect_key($_SERVER, array_flip(self::KEYS));
        try {
            foreach (self::KEYS as $key) {
                $_SERVER[$key] = $values[$key] ?? '';
            }

            return require config_path('llm.php');
        } finally {
            $_SERVER = array_diff_key($_SERVER, array_flip(self::KEYS)) + $saved;
        }
    }

    public function test_two_chats_office_and_code_with_own_url_slots_ctx(): void
    {
        $llm = $this->load([]);

        $this->assertSame(['office', 'science'], array_keys($llm['chats']));
        $this->assertSame('http://172.19.101.171:11434', $llm['chats']['office']['url']);
        $this->assertSame('http://172.19.101.170:11434', $llm['chats']['science']['url']);
        // Модели отвечают по одному (Ollama не ведёт их ответы параллельно) — остальные в очереди сайта.
        $this->assertSame([1, 1], array_column($llm['chats'], 'slots'));
        $this->assertSame([16384, 32768], array_column($llm['chats'], 'num_ctx'));
        $this->assertFalse($llm['chats']['office']['think']);
        // Научный чат: Qwen3.6 рассуждает перед ответом — точнее в расчётах.
        // Рассуждение — по галочке «Подумать тщательнее»; по умолчанию быстрый ответ.
        $this->assertFalse($llm['chats']['science']['think']);
        $this->assertTrue($llm['chats']['science']['think_toggle']);
        $this->assertArrayNotHasKey('think_toggle', $llm['chats']['office']);
        $this->assertSame('Научный', $llm['chats']['science']['title']);
        $this->assertSame(8192, $llm['chats']['science']['num_predict']);
    }

    public function test_empty_env_values_fall_back_to_defaults(): void
    {
        // Пустая строка в .env (LLM_X=) не должна давать '' или 0.
        $llm = $this->load([]);

        $this->assertSame('office', $llm['chats']['office']['model']);
        $this->assertSame('science', $llm['chats']['science']['model']);
        $this->assertSame([2048, 8192], array_column($llm['chats'], 'num_predict'));
        $this->assertSame(0.6, $llm['chats']['science']['options']['temperature']);
        $this->assertSame(20, $llm['chats']['science']['options']['top_k']);
        $this->assertSame(2700, $llm['answer_timeout']);
        $this->assertSame(1800, $llm['queue']['max_wait']);
        $this->assertSame(24000, $llm['history']['max_chars']);
        $this->assertSame(3, $llm['connect_timeout']);
    }

    public function test_env_values_override_defaults(): void
    {
        $llm = $this->load(['LLM_SCIENCE_URL' => 'http://10.0.0.5:11434', 'LLM_SCIENCE_SLOTS' => '3', 'LLM_SCIENCE_MODEL' => 'qwen-demo']);

        $this->assertSame('http://10.0.0.5:11434', $llm['chats']['science']['url']);
        $this->assertSame(3, $llm['chats']['science']['slots']);
        $this->assertSame('qwen-demo', $llm['chats']['science']['model']);
    }

    public function test_php_time_limit_covers_wait_and_answer(): void
    {
        // set_time_limit = max_wait + answer_timeout + 60; Apache Timeout считает паузы, а пауз нет (пульс 10 с).
        $llm = $this->load([]);

        $this->assertLessThanOrEqual(4600, $llm['queue']['max_wait'] + $llm['answer_timeout'] + 60);
        $this->assertGreaterThan($llm['ttft_timeout'], $llm['answer_timeout']);
    }
}
