<?php

namespace Tests\Unit\Documents;

use App\Porfiry\Documents\Renderer;
use App\Porfiry\Documents\Templates;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Facades\Process;
use RuntimeException;
use Tests\Porfiry\OfficeFiles;
use Tests\TestCase;

class RendererTest extends TestCase
{
    private string $dir;

    protected function setUp(): void
    {
        parent::setUp();
        $this->dir = sys_get_temp_dir() . '/porfiry-rnd-' . bin2hex(random_bytes(5));
        mkdir($this->dir);
    }

    protected function tearDown(): void
    {
        (new Filesystem())->deleteDirectory($this->dir);
        parent::tearDown();
    }

    /** Результат рендера — байты файла; для проверки кладём их на диск. */
    private function saved(string $bytes, string $ext = 'docx'): string
    {
        $path = "{$this->dir}/out-" . bin2hex(random_bytes(3)) . ".{$ext}";
        file_put_contents($path, $bytes);

        return $path;
    }

    private function template(string $name): array
    {
        return (new Templates($this->dir))->find($name);
    }

    private function docx(): array
    {
        OfficeFiles::docx("{$this->dir}/Договор.docx", OfficeFiles::p('Продавец: $', '{Прода', 'вец}')
            . OfficeFiles::p('Условия: ${Условия}') . OfficeFiles::p('Подпись: ${Подпись}'));

        return $this->template('Договор.docx');
    }

    public function test_docx_fields_replaced_escaped_and_multiline(): void
    {
        $file = $this->saved((new Renderer(null))->render($this->docx(), [
            'Продавец' => 'ООО «Рога & Копыта» <главный>',
            'Условия' => "Первая строка\nВторая строка",
        ], 'docx'));

        $xml = OfficeFiles::part($file, 'word/document.xml');
        $this->assertStringContainsString('ООО «Рога &amp; Копыта» &lt;главный&gt;', $xml);
        $this->assertStringContainsString('Первая строка</w:t><w:br/><w:t xml:space="preserve">Вторая строка', $xml);
        $this->assertStringNotContainsString('${', $xml);
        // Пустое поле — линия для подписи от руки.
        $this->assertStringContainsString('Подпись: ____________', $xml);
        $this->assertNotFalse(simplexml_load_string($xml));
    }

    public function test_values_cannot_inject_placeholders_or_control_chars(): void
    {
        $file = $this->saved((new Renderer(null))->render($this->docx(), ['Продавец' => "\${Условия}\x07"], 'docx'));

        $xml = OfficeFiles::part($file, 'word/document.xml');
        $this->assertStringNotContainsString("\x07", $xml);
        $this->assertStringContainsString('{Условия}', $xml);
        $this->assertStringNotContainsString('${Условия}', $xml);
    }

    public function test_odt_and_xlsx_filled(): void
    {
        OfficeFiles::odt("{$this->dir}/Заявление.odt", 'Прошу с ${Дата}');
        OfficeFiles::xlsx("{$this->dir}/Счёт.xlsx", 'Покупатель: ${Покупатель}');
        $renderer = new Renderer(null);

        $odt = $this->saved($renderer->render($this->template('Заявление.odt'), ['Дата' => "01.02.2026\nвключительно"], 'odt'), 'odt');
        $xlsx = $this->saved($renderer->render($this->template('Счёт.xlsx'), ['Покупатель' => 'Иванов'], 'xlsx'), 'xlsx');

        $this->assertStringContainsString('Прошу с 01.02.2026<text:line-break/>включительно', OfficeFiles::part($odt, 'content.xml'));
        $this->assertStringContainsString('Покупатель: Иванов', OfficeFiles::part($xlsx, 'xl/sharedStrings.xml'));
    }

    public function test_formats_depend_on_libreoffice(): void
    {
        $docx = $this->docx();
        OfficeFiles::xlsx("{$this->dir}/Счёт.xlsx", '${Покупатель}');
        $xlsx = $this->template('Счёт.xlsx');

        $this->assertSame(['docx'], (new Renderer(null))->formats($docx));
        $this->assertSame(['docx', 'odt', 'pdf'], (new Renderer('soffice'))->formats($docx));
        $this->assertSame(['xlsx', 'pdf'], (new Renderer('soffice'))->formats($xlsx));
    }

    public function test_pdf_converted_by_libreoffice_with_own_profile(): void
    {
        Process::fake(function ($process) {
            // «LibreOffice» кладёт результат в --outdir.
            $outdir = $process->command[array_search('--outdir', $process->command, true) + 1];
            file_put_contents($outdir . '/document.pdf', '%PDF-1.4 готово');

            return Process::result();
        });

        $pdf = (new Renderer('soffice'))->render($this->docx(), ['Продавец' => 'Иванов'], 'pdf');

        $this->assertSame('%PDF-1.4 готово', $pdf);
        Process::assertRan(function ($process) {
            $command = $process->command;

            // Без экрана: на Astra LibreOffice собран с Qt и иначе ищет X-сервер (xcb).
            return ($process->environment['SAL_USE_VCLPLUGIN'] ?? null) === 'svp'
                && str_starts_with((string) ($process->environment['XDG_RUNTIME_DIR'] ?? ''), sys_get_temp_dir())
                && ($process->environment['QT_QPA_PLATFORM'] ?? null) === 'offscreen'
                && $command[0] === 'soffice' && in_array('--headless', $command, true)
                && str_starts_with($command[array_search('--convert-to', $command, true) + 1], 'pdf')
                && collect($command)->contains(fn ($a) => str_starts_with($a, '-env:UserInstallation=file://'));
        });
    }

    public function test_failed_conversion_is_reported(): void
    {
        // Предупреждения LibreOffice на Astra (java, Qt) — шум; показать надо настоящую причину.
        Process::fake(['*' => Process::result('', "Warning: failed to launch javaldx - java may not function correctly\n"
            . "QStandardPaths: XDG_RUNTIME_DIR not set, defaulting to '/tmp/runtime-www-data'\n"
            . "Error: source file could not be loaded\n", 1)]);

        try {
            (new Renderer('soffice'))->render($this->docx(), [], 'pdf');
            $this->fail('нет исключения');
        } catch (RuntimeException $e) {
            $this->assertStringContainsString('source file could not be loaded', $e->getMessage());
            $this->assertStringNotContainsString('javaldx', $e->getMessage());
            $this->assertStringNotContainsString('XDG_RUNTIME_DIR', $e->getMessage());
        }
    }

    public function test_format_not_offered_is_rejected(): void
    {
        $this->expectException(RuntimeException::class);
        (new Renderer(null))->render($this->docx(), [], 'pdf');
    }
}
