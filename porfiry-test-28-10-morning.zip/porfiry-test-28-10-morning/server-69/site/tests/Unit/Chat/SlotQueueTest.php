<?php

namespace Tests\Unit\Chat;

use App\Porfiry\Chat\SlotQueue;
use App\Porfiry\Chat\Store;
use Tests\Porfiry\UsesTempStore;
use Tests\TestCase;

class SlotQueueTest extends TestCase
{
    use UsesTempStore;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTempStore();
        config(['llm.queue.max_wait' => 600, 'llm.queue.max_waiting' => 20, 'llm.queue.slot_ttl' => 20, 'llm.queue.waiter_ttl' => 10]);
    }

    protected function tearDown(): void
    {
        $this->tearDownTempStore();
        parent::tearDown();
    }

    /** Очередь с «часами»: каждый сон сдвигает время на секунду, а не ждёт. */
    private function queue(string $chat = 'office', int $slots = 1, ?\Closure $onSleep = null): SlotQueue
    {
        return new SlotQueue(Store::get(), $chat, $slots, function () use ($onSleep) {
            $this->travel(1)->seconds();
            if ($onSleep) {
                $onSleep();
            }
        });
    }

    public function test_takes_free_slot(): void
    {
        $q = $this->queue();

        $this->assertSame(0, $q->enter('x'));
        $this->assertSame('x', Store::get()->get('llm:slot:office:0'));
    }

    public function test_reports_position_when_all_busy(): void
    {
        $this->assertSame(0, $this->queue()->enter('x'));
        $this->assertSame(1, $this->queue()->enter('a'));
        $this->assertSame(2, $this->queue()->enter('b'));
    }

    public function test_busy_counts_answers_in_progress(): void
    {
        $x = $this->queue('office', 2);

        $this->assertSame(0, $x->busy());
        $x->enter('x');
        $this->queue('office', 2)->enter('y');
        $this->assertSame(2, $x->busy());
        $x->release('x');
        $this->assertSame(1, $x->busy());
    }

    public function test_fifo_two_waiters(): void
    {
        $x = $this->queue();
        $x->enter('x');
        $this->queue()->enter('a');
        $this->queue()->enter('b');

        $x->release('x');

        $this->assertSame(2, $this->queue()->enter('b'));
        $this->assertSame(0, $this->queue()->enter('a'));
        $this->assertSame(1, $this->queue()->enter('b'));
    }

    public function test_rejects_when_waiting_over_max(): void
    {
        config(['llm.queue.max_waiting' => 2]);
        $this->queue()->enter('x');
        $this->queue()->enter('a');
        $this->queue()->enter('b');

        $this->assertSame(-1, $this->queue()->enter('c'));
    }

    public function test_gives_up_after_max_wait(): void
    {
        // Время двигают только «сны» очереди: настоящая секунда не должна перещёлкнуть посреди теста.
        $this->freezeTime();
        config(['llm.queue.max_wait' => 5]);
        $this->queue()->enter('x');
        $positions = [];

        $reason = $this->queue()->acquire('a', function (int $pos) use (&$positions) {
            $positions[] = $pos;
            return null;
        });

        $this->assertSame('timeout', $reason);
        // Ждали 5 секунд: проверка на 0-й…5-й секунде.
        $this->assertSame([1, 1, 1, 1, 1, 1], $positions);
        $this->assertSame(1, $this->queue()->enter('b'));
    }

    public function test_leaves_queue_when_cancelled(): void
    {
        $this->queue()->enter('x');
        $calls = 0;

        $reason = $this->queue()->acquire('a', function () use (&$calls) {
            return ++$calls === 2 ? 'cancelled' : null;
        });

        $this->assertSame('cancelled', $reason);
        $this->assertSame(1, $this->queue()->enter('b'));
    }

    public function test_acquire_waits_until_slot_frees(): void
    {
        $x = $this->queue();
        $x->enter('x');
        $sleeps = 0;
        $a = $this->queue('office', 1, function () use ($x, &$sleeps) {
            if (++$sleeps === 3) {
                $x->release('x');
            }
        });
        $positions = [];

        $reason = $a->acquire('a', function (int $pos) use (&$positions) {
            $positions[] = $pos;
            return null;
        });

        $this->assertNull($reason);
        $this->assertSame([1, 1, 1], $positions);
        $this->assertSame('a', Store::get()->get('llm:slot:office:0'));
    }

    public function test_drops_waiter_without_heartbeat(): void
    {
        $this->queue()->enter('x');
        $this->queue()->enter('a');
        $this->assertSame(2, $this->queue()->enter('b'));

        // b подтверждает себя, a молчит: выбывает только a.
        $this->travel(6)->seconds();
        $this->queue()->enter('b');
        $this->travel(5)->seconds();

        $this->assertSame(1, $this->queue()->enter('b'));
    }

    public function test_slot_without_heartbeat_frees_after_ttl(): void
    {
        $this->queue()->enter('x');

        $this->travel(21)->seconds();

        $this->assertSame(0, $this->queue()->enter('a'));
    }

    public function test_heartbeat_keeps_slot(): void
    {
        $x = $this->queue();
        $x->enter('x');

        $this->travel(15)->seconds();
        $x->heartbeat('x');
        $this->travel(15)->seconds();

        $this->assertSame(1, $this->queue()->enter('a'));
    }

    public function test_release_only_own_rid(): void
    {
        $x = $this->queue();
        $x->enter('x');

        $other = $this->queue();
        $other->release('y');

        $this->assertSame('x', Store::get()->get('llm:slot:office:0'));
    }

    public function test_slots_are_per_chat(): void
    {
        $this->queue('office')->enter('x');

        $this->assertSame(0, $this->queue('science')->enter('a'));
    }

    public function test_several_slots_used_before_queueing(): void
    {
        $this->assertSame(0, $this->queue('office', 3)->enter('a'));
        $this->assertSame(0, $this->queue('office', 3)->enter('b'));
        $this->assertSame(0, $this->queue('office', 3)->enter('c'));
        $this->assertSame(1, $this->queue('office', 3)->enter('d'));
    }
}
