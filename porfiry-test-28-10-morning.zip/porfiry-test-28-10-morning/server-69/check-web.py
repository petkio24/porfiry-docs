#!/usr/bin/env python3
"""Проверка чата «Порфирий» v2 на веб-сервере — как браузер.

    sudo -u www-data python3 check-web.py --site /путь/к/сайту [--base http://127.0.0.1]

Проверяет:
  1. настройки сайта (.env): отладка выключена, сессия работает по HTTP, часовой пояс;
  2. страница /chat открывается, есть оба чата и адрес отмены;
  3. ответ идёт потоком, по HTTP/1.0 (строка Apache для /chat/ действует);
  4. «Стоп»: отмена во время ответа обрывает его за секунды, следующий вопрос
     сразу принимается (без «Дождитесь ответа»);
  5. чат «Научный» отвечает;
  6. документы: список шаблонов, первый собирается;
  7. ГОСТы: вопрос находит фрагменты документов;
  8. журнал чата пишет, чем кончились ответы.
В конце строка ИТОГ. Python 3.7+, без сторонних библиотек.
"""
import argparse
import http.cookiejar
import json
import os
import re
import secrets
import sys
import threading
import time
import urllib.error
import urllib.request

CSRF_RE = re.compile(r'<meta name="csrf-token" content="([^"]+)"')
CONFIG_RE = re.compile(r'window\.CHAT_CONFIG = (\{.*?\});', re.S)
RESULTS = []


def say(level, label, text):
    RESULTS.append(level)
    print('{}  {}: {}'.format(level, label, text), flush=True)


class Site:
    def __init__(self, base):
        self.base = base.rstrip('/')
        self.jar = http.cookiejar.CookieJar()
        # Системный прокси (http_proxy) не должен перехватывать запросы к своему сайту.
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                                  urllib.request.HTTPCookieProcessor(self.jar))
        self.token = ''
        self.config = {}

    def open_page(self):
        page = self.opener.open(self.base + '/chat', timeout=60)
        html = page.read().decode('utf-8', 'replace')
        match = CSRF_RE.search(html)
        self.token = match.group(1) if match else ''
        conf = CONFIG_RE.search(html)
        self.config = json.loads(conf.group(1)) if conf else {}
        return page.status

    def post(self, path, body, timeout):
        data = json.dumps(body, ensure_ascii=False).encode('utf-8')
        request = urllib.request.Request(self.base + path, data, {
            'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': self.token})
        return self.opener.open(request, timeout=timeout)


def read_events(response, on_event=None, limit=None):
    """Читает строки NDJSON; on_event(event, seconds) вернёт True — остановиться."""
    started = time.time()
    events = []
    for raw in response:
        line = raw.decode('utf-8', 'replace').strip()
        if not line:
            continue
        event = json.loads(line)
        events.append((event, time.time() - started))
        if on_event and on_event(event, time.time() - started):
            break
        if limit and len(events) >= limit:
            break
    return events


def check_env(site_dir):
    path = os.path.join(site_dir, '.env')
    try:
        env = dict(line.strip().split('=', 1) for line in open(path, encoding='utf-8', errors='replace')
                   if '=' in line and not line.strip().startswith('#'))
    except OSError as error:
        say('ВНИМАНИЕ', 'НАСТРОЙКИ', 'не прочитан .env ({}): запустите от www-data или root'.format(error))
        return
    value = lambda k: env.get(k, '').strip().strip('"').strip("'").lower()
    if value('APP_DEBUG') == 'true':
        say('ПРОБЛЕМА', 'НАСТРОЙКИ', 'APP_DEBUG=true — пользователи увидят тексты ошибок сервера; поставьте false')
    else:
        say('OK', 'НАСТРОЙКИ', 'APP_DEBUG выключен')
    if value('SESSION_SECURE_COOKIE') == 'true':
        say('ПРОБЛЕМА', 'НАСТРОЙКИ', 'SESSION_SECURE_COOKIE=true — по HTTP сессия не работает (вечный 419)')
    if value('SESSION_DRIVER') == 'array':
        say('ПРОБЛЕМА', 'НАСТРОЙКИ', 'SESSION_DRIVER=array — отмена и вытеснение не найдут сессию')
    domain = value('SESSION_DOMAIN')
    if domain and domain not in ('null',) and not re.match(r'^[0-9.]+$', domain):
        say('ВНИМАНИЕ', 'НАСТРОЙКИ', 'SESSION_DOMAIN={} — при входе по IP cookie не уйдёт'.format(domain))
    if not value('LLM_TIMEZONE'):
        say('ВНИМАНИЕ', 'НАСТРОЙКИ', 'нет LLM_TIMEZONE — время в журнале чата будет по UTC')
    proxies = os.path.join(site_dir, 'app', 'Http', 'Middleware', 'TrustProxies.php')
    if os.path.exists(proxies) and re.search(r"\$proxies\s*=\s*'\*'", open(proxies, encoding='utf-8').read()):
        say('ВНИМАНИЕ', 'НАСТРОЙКИ', "TrustProxies: $proxies = '*' — лимиты по IP обходятся заголовком X-Forwarded-For")


class Alive:
    """Как браузер: раз в 20 с «страница открыта», пока читаем ответ. Без этого сайт через
    150 с (модель грузится с диска или рассуждает) решит, что страницу закрыли (gone)."""

    def __init__(self, site, rid):
        self.site, self.rid, self.stop = site, rid, threading.Event()

    def run(self):
        while not self.stop.wait(20):
            try:
                self.site.post('/chat/cancel', {'rid': self.rid, 'alive': 1}, 30).read()
            except (urllib.error.URLError, OSError):
                pass

    def __enter__(self):
        threading.Thread(target=self.run, daemon=True).start()
        return self

    def __exit__(self, *exc):
        self.stop.set()


def ask(site, chat, question, rid=None, timeout=1900):
    rid = rid or secrets.token_hex(16)
    response = site.post(site.config['chats'][chat]['url'], {
        'rid': rid, 'messages': [{'role': 'user', 'content': question}]}, timeout)
    return rid, response


def check_answer(site, chat, label):
    try:
        rid, response = ask(site, chat, 'Ответь одним коротким предложением: что такое атом?')
    except urllib.error.HTTPError as error:
        say('ПРОБЛЕМА', label, 'вопрос отклонён: HTTP {} {}'.format(error.code, error.read()[:200]))
        return None
    with Alive(site, rid):
        events = read_events(response)
    texts = [e for e, _ in events if 't' in e]
    errors = [e for e, _ in events if 'error' in e]
    if errors:
        say('ПРОБЛЕМА', label, 'ошибка в ответе: {} ({})'.format(errors[0]['error'], errors[0].get('code')))
        return response
    if not any(e.get('done') for e, _ in events):
        say('ПРОБЛЕМА', label, 'поток кончился без {"done":true}')
        return response
    first = next(t for e, t in events if 't' in e) if texts else 0
    say('OK', label, 'ответ целиком: кусков {}, первый через {:.0f} с, всего {:.0f} с'.format(
        len(texts), first, events[-1][1]))
    return response


def check_stop(site):
    """Отмена во время ответа и сразу новый вопрос."""
    question = 'Подробно, по пунктам, опиши правила оформления служебной записки.'
    rid, response = ask(site, 'office', question)
    seen = {}

    def first_text(event, seconds):
        if 't' in event:
            seen['text_at'] = seconds
            return True
        return False

    with Alive(site, rid):
        read_events(response, first_text)
    if 'text_at' not in seen:
        say('ПРОБЛЕМА', 'СТОП', 'ответ кончился раньше первого куска текста')
        return
    started = time.time()
    cancel = site.post('/chat/cancel', {'rid': rid}, 30)
    if cancel.status != 204:
        say('ПРОБЛЕМА', 'СТОП', '/chat/cancel ответил {}'.format(cancel.status))
        return
    rest = read_events(response)
    took = time.time() - started
    codes = [e.get('code') for e, _ in rest if 'error' in e]
    if codes == ['cancelled'] and took < 5:
        say('OK', 'СТОП', 'ответ остановлен за {:.1f} с после отмены'.format(took))
    else:
        say('ПРОБЛЕМА', 'СТОП', 'после отмены: {} за {:.1f} с (ожидалось cancelled за < 5 с)'.format(codes or 'нет ошибки', took))

    started = time.time()
    try:
        rid_again, again = ask(site, 'office', 'Ответь одним словом: какого цвета небо?')
    except urllib.error.HTTPError as error:
        say('ПРОБЛЕМА', 'СТОП', 'новый вопрос после отмены отклонён: HTTP {}'.format(error.code))
        return
    with Alive(site, rid_again):
        events = read_events(again)
    first = next((t for e, t in events if 't' in e or e.get('s') == 'model'), None)
    errors = [e for e, _ in events if 'error' in e]
    if errors:
        say('ПРОБЛЕМА', 'СТОП', 'новый вопрос: {} ({})'.format(errors[0]['error'], errors[0].get('code')))
    elif first is not None and first < 5:
        say('OK', 'СТОП', 'новый вопрос принят сразу (модель взялась за {:.1f} с)'.format(first))
    else:
        say('ВНИМАНИЕ', 'СТОП', 'новый вопрос ждал {:.0f} с'.format(time.time() - started))


def check_documents(site):
    """Список шаблонов и сборка первого из них (без модели: поля пустые)."""
    try:
        data = json.loads(site.opener.open(site.base + site.config['docs']['templatesUrl'], timeout=60).read())
    except (urllib.error.URLError, OSError, ValueError, KeyError) as error:
        say('ПРОБЛЕМА', 'ДОКУМЕНТЫ', 'список шаблонов не получен: {}'.format(error))
        return
    templates = data.get('templates', [])
    if not templates:
        say('ВНИМАНИЕ', 'ДОКУМЕНТЫ', 'шаблонов нет — положите их в /srv/porfiry-data/templates')
        return
    first = templates[0]
    try:
        body = site.post(site.config['docs']['renderUrl'], {
            'template': first['id'], 'format': first['formats'][0], 'fields': {}}, 120).read()
    except urllib.error.HTTPError as error:
        say('ПРОБЛЕМА', 'ДОКУМЕНТЫ', '«{}» не собран: HTTP {} {}'.format(
            first['title'], error.code, error.read()[:200].decode('utf-8', 'replace')))
        return
    if body[:2] != b'PK':
        say('ПРОБЛЕМА', 'ДОКУМЕНТЫ', '«{}»: пришёл не документ'.format(first['title']))
        return
    formats = sorted({f for t in templates for f in t['formats']})
    say('OK', 'ДОКУМЕНТЫ', 'шаблонов {}, «{}» собран; форматы: {}'.format(len(templates), first['title'], ', '.join(formats)))
    if 'pdf' not in formats:
        say('ВНИМАНИЕ', 'ДОКУМЕНТЫ', 'PDF недоступен: нет LibreOffice (apt install libreoffice-writer libreoffice-calc)')


def check_gost(site):
    """Вопрос по ГОСТу: до ответа модели приходит список найденных фрагментов, затем отмена."""
    rid, response = ask(site, 'office', 'Как оформить подстрочную библиографическую ссылку?')
    found = {}

    def until_model(event, seconds):
        if 'kb' in event:
            found['kb'] = event['kb']
        return 'kb' in event or event.get('s') == 'model' or 'error' in event

    read_events(response, until_model)
    site.post('/chat/cancel', {'rid': rid}, 30)
    read_events(response)
    if found.get('kb'):
        say('OK', 'ГОСТЫ', 'найдено фрагментов: {} ({})'.format(len(found['kb']), found['kb'][0]['doc']))
    else:
        say('ВНИМАНИЕ', 'ГОСТЫ', 'поиск ничего не нашёл — соберите индекс: '
            'sudo -u www-data php artisan porfiry:kb-index')


def main():
    parser = argparse.ArgumentParser(description='Проверка чата Порфирий v2')
    parser.add_argument('--site', help='папка сайта (для проверки .env и журнала)')
    parser.add_argument('--base', default='http://127.0.0.1', help='адрес сайта с этого сервера')
    args = parser.parse_args()

    if args.site:
        check_env(args.site)

    site = Site(args.base)
    try:
        status = site.open_page()
    except (urllib.error.URLError, OSError) as error:
        say('ПРОБЛЕМА', 'СТРАНИЦА', '{}/chat не открылась: {}'.format(args.base, error))
        print('ИТОГ: ПРОБЛЕМА')
        return 1
    chats = sorted(site.config.get('chats', {}))
    if status == 200 and site.token and chats == ['office', 'science'] and site.config.get('cancelUrl'):
        say('OK', 'СТРАНИЦА', '/chat открывается, чаты: Офисный и Научный')
    else:
        say('ПРОБЛЕМА', 'СТРАНИЦА', 'HTTP {}, токен {}, чаты {} — это не v2?'.format(status, bool(site.token), chats))
        print('ИТОГ: ПРОБЛЕМА')
        return 1

    response = check_answer(site, 'office', 'ОФИС')
    if response is not None:
        if getattr(response, 'version', 11) == 10:
            say('OK', 'APACHE', 'ответ чата идёт по HTTP/1.0 — строка потока действует')
        else:
            say('ВНИМАНИЕ', 'APACHE', 'ответ чата по HTTP/1.1 — строки SetEnvIfExpr ... force-response-1.0 нет')
    check_stop(site)
    check_answer(site, 'science', 'НАУЧНЫЙ')
    check_documents(site)
    check_gost(site)

    if args.site:
        log = os.path.join(args.site, 'storage', 'logs', 'porfiry.log')
        try:
            tail = open(log, encoding='utf-8', errors='replace').read().splitlines()[-4:]
            ends = re.findall(r'end=(\w+)', '\n'.join(tail))
            say('OK' if 'cancelled' in ends and 'done' in ends else 'ВНИМАНИЕ', 'ЖУРНАЛ', ' '.join(ends))
        except OSError as error:
            say('ВНИМАНИЕ', 'ЖУРНАЛ', 'не прочитан: {}'.format(error))

    print('')
    if 'ПРОБЛЕМА' in RESULTS:
        print('ИТОГ: ПРОБЛЕМА — см. строки выше')
        return 1
    print('ИТОГ: ' + ('ВНИМАНИЕ — см. строки выше' if 'ВНИМАНИЕ' in RESULTS else 'OK'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
