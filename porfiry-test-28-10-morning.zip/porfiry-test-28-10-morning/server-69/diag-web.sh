#!/bin/bash
# Диагностика веб-сервера «Порфирия»: настройки чата, журнал, LibreOffice (несколько способов).
#
#   sudo bash diag-web.sh /путь/к/сайту
#
# Всё печатается на экран и сохраняется в /opt/porfiry/diag-web-<дата-время>.txt —
# этот файл прислать. Паролей и ключей из .env в файл не попадает (только строки LLM_ и APP_DEBUG).
SITE=$(cd "${1:-}" 2>/dev/null && pwd)
OUT=/opt/porfiry/diag-web-$(date +%d%m-%H%M).txt

[ "$(id -u)" = 0 ] || { echo "ПРОБЛЕМА  запустите через sudo: sudo bash $0 /путь/к/сайту"; exit 1; }
[ -f "$SITE/artisan" ] || { echo "ПРОБЛЕМА  в «${1:-}» нет artisan — укажите папку сайта"; exit 1; }
mkdir -p /opt/porfiry
exec > >(tee "$OUT") 2>&1
cd "$SITE" || exit 1

echo "### Сайт: $SITE, $(date '+%d.%m.%Y %H:%M')"
grep -E '^(APP_ENV|APP_DEBUG|LLM_)' .env
[ -f bootstrap/cache/config.php ] && echo "настройки в кэше (config:cache): да" || echo "настройки в кэше: нет"
php -v | head -1
echo "модули PHP: $(php -m | grep -xE 'curl|zip' | tr '\n' ' ')"

echo; echo "### Журнал чата (последние 20 строк)"
tail -20 storage/logs/porfiry.log 2>/dev/null

echo; echo "### Последние ошибки Laravel"
grep -hE '\.(ERROR|CRITICAL)' storage/logs/laravel*.log 2>/dev/null | tail -5 | cut -c1-300

echo; echo "### LibreOffice"
B=$(command -v soffice)
if [ -z "$B" ]; then
    echo "ПРОБЛЕМА  soffice не найден — LibreOffice не установлен"
else
    REAL=$(readlink -f "$B")
    BIN=$(dirname "$REAL")/soffice.bin
    echo "soffice: $B -> $REAL"
    dpkg -l 2>/dev/null | awk '/^ii +libreoffice-(core|writer|calc) /{print "пакет:", $2, $3}'
    echo "--- настройки, которые запускатель LibreOffice задаёт сам:"
    grep -nE 'SAL_USE_VCLPLUGIN|QT_QPA|VCL' "$REAL" /etc/libreoffice/* 2>/dev/null | head -10
    probe() {
        local name=$1; shift
        local D; D=$(mktemp -d /tmp/porfiry-diag-XXXX)
        echo "проба Порфирия" > "$D/test.txt"
        chown -R www-data "$D"; chmod 700 "$D"
        timeout 180 sudo -u www-data env HOME="$D" XDG_RUNTIME_DIR="$D" "$@" \
            "-env:UserInstallation=file://$D/profile" --convert-to pdf --outdir "$D" "$D/test.txt" > "$D/log" 2>&1
        local code=$?
        if [ -s "$D/test.pdf" ]; then
            echo "OK  $name: PDF получен"
        else
            echo "ПРОБЛЕМА  $name: PDF нет (код выхода $code)"
            grep -viE 'javaldx|java may not|QStandardPaths' "$D/log" | tail -6 | sed 's/^/      /'
        fi
        rm -rf "$D"
    }
    echo "--- пробы от имени www-data (как сайт), до 3 минут каждая:"
    probe "как сайт (svp + offscreen)" env SAL_USE_VCLPLUGIN=svp QT_QPA_PLATFORM=offscreen "$B" --headless --norestore --nologo --nolockcheck
    probe "только Qt offscreen" env QT_QPA_PLATFORM=offscreen "$B" --headless --norestore --nologo --nolockcheck
    [ -x "$BIN" ] && probe "soffice.bin напрямую" env SAL_USE_VCLPLUGIN=svp QT_QPA_PLATFORM=offscreen "$BIN" --headless --norestore --nologo --nolockcheck
fi

echo
echo "ИТОГ: диагностика записана в $OUT — пришлите этот файл"
