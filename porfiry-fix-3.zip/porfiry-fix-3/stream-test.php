<?php
// Временная проверка потока через Apache: 10 строк раз в секунду, как ответ чата.
// Кладёт в public/ и удаляет apache-check.sh. Итог — в storage/logs/porfiry-stream.log.
ignore_user_abort(true);
set_time_limit(300);
$id = preg_replace('/[^\w-]/', '', $_GET['id'] ?? 'x');
$plain = ($_GET['type'] ?? '') === 'plain';
$delay = min(120, max(0, (int) ($_GET['delay'] ?? 0)));
$levels = ob_get_level();

header('Content-Type: ' . ($plain ? 'text/plain' : 'application/x-ndjson'));
header('Cache-Control: no-cache');
header('X-Accel-Buffering: no');

// Пауза перед первой строкой — как модель, которая читает вопрос.
sleep($delay);
$lost = 0;
for ($i = 1; $i <= 10; $i++) {
    echo json_encode(['t' => "строка {$i}"], JSON_UNESCAPED_UNICODE) . "\n";
    if (ob_get_level() > 0) {
        ob_flush();
    }
    flush();
    if ($lost === 0 && connection_aborted()) {
        $lost = $i;
    }
    sleep(1);
}

$info = [
    'id' => $id,
    'sapi' => PHP_SAPI,
    'output_buffering' => ini_get('output_buffering'),
    'zlib' => ini_get('zlib.output_compression'),
    'handler' => ini_get('output_handler'),
    'levels' => $levels,
    'proto' => $_SERVER['SERVER_PROTOCOL'] ?? '',
    'lost' => $lost,
];
$log = __DIR__ . '/../storage/logs/porfiry-stream.log';
file_put_contents($log, json_encode($info) . "\n", FILE_APPEND | LOCK_EX);
