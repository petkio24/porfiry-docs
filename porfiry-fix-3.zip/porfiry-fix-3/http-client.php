<?php
// Клиент для apache-check.sh: читает поток построчно, как браузер.
// php http-client.php АДРЕС [ИМЯ-САЙТА-ДЛЯ-Host]
$url = $argv[1] ?? '';
$host = $argv[2] ?? '';
// Как запрос чата: POST с JSON. Без Accept-Encoding: проверяется сам поток, не сжатие.
$headers = ['Content-Type: application/json', 'Accept: application/json'];
if ($host !== '') {
    $headers[] = 'Host: ' . $host;
}
$ctx = stream_context_create([
    'http' => [
        'method' => 'POST',
        'content' => '{"messages":[]}',
        'header' => implode("\r\n", $headers),
        'timeout' => 200,
        'ignore_errors' => true,
        'protocol_version' => 1.1,
    ],
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false,
        'peer_name' => $host !== '' ? $host : parse_url($url, PHP_URL_HOST),
    ],
]);
$start = microtime(true);
$fp = @fopen($url, 'r', false, $ctx);
if ($fp === false) {
    echo 'нет связи: ' . (error_get_last()['message'] ?? '') . "\n";
    exit(2);
}
$seen = [];
$keep = '/^(HTTP\/|Content-(Type|Encoding|Length)|Transfer-Encoding|Connection)/i';
foreach ($http_response_header as $line) {
    if (preg_match($keep, $line)) {
        $seen[] = $line;
    }
}
$times = [];
while (($line = fgets($fp)) !== false) {
    if (trim($line) !== '') {
        $times[] = microtime(true) - $start;
    }
}
fclose($fp);
$n = count($times);
$first = $times[0] ?? 0;
$last = $n ? $times[$n - 1] : 0;
printf("строк %d из 10, первая через %.0f с, последняя через %.0f с\n", $n, $first, $last);
echo '    ' . implode('; ', $seen) . "\n";
// Поток идёт, если пришли все 10 строк и не одним куском в конце.
exit($n === 10 && $last - $first >= 5 ? 0 : 1);
