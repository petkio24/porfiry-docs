#!/bin/bash
# Правка Apache для потока чата: строки в <VirtualHost> сайта, проверка, перезапуск.
# Запуск: sudo bash apache-fix.sh [файл сайта; по умолчанию 000-default]
HERE=$(cd "$(dirname "$0")" && pwd)
CONF=${1:-/etc/apache2/sites-enabled/000-default}
MARK="# porfiry: поток чата"

if [ "$(id -u)" != 0 ]; then
  echo "ОШИБКА: запустите через sudo"; exit 1
fi
if [ ! -f "$CONF" ]; then
  echo "ОШИБКА: нет файла $CONF — укажите файл сайта первым аргументом"; exit 1
fi
REAL=$(readlink -f "$CONF")
if grep -q "$MARK" "$REAL"; then
  echo "OK  правка уже стоит в $REAL"; exit 0
fi

BAK="$HERE/$(basename "$REAL")-$(date +%Y%m%d-%H%M%S).bak"
cp -p "$REAL" "$BAK"
echo "OK  копия файла: $BAK"

FPM=0
if apache2ctl -M 2>/dev/null | grep -q proxy_fcgi; then FPM=1; fi
# Перед первым </VirtualHost> — наши строки; старое правило для /chat/ убрать.
awk -v fpm="$FPM" -v mark="$MARK" '
  !done && tolower($0) ~ /<\/virtualhost>/ {
    print "    " mark
    print "    Timeout 1900"
    print "    SetEnvIfExpr \"%{THE_REQUEST} =~ m#/chat/#\" force-response-1.0 downgrade-1.0 nokeepalive no-gzip dont-vary"
    if (fpm == 1) {
      print "    <Proxy \"fcgi://localhost\">"
      print "        ProxySet flushpackets=on timeout=1900"
      print "    </Proxy>"
    }
    done = 1
  }
  /SetEnvIfExpr.*\/chat\// { next }
  { print }
' "$BAK" > "$REAL"

if ! OUT=$(apache2ctl configtest 2>&1); then
  cp -p "$BAK" "$REAL"
  echo "ОШИБКА: Apache не принял конфиг — файл возвращён как был:"
  echo "$OUT" | tail -5
  exit 1
fi
echo "OK  конфиг принят, добавлено в $REAL:"
grep -A5 "$MARK" "$REAL" | grep -v '^\s*</VirtualHost>' | sed 's/^/      /'

systemctl restart apache2 || echo "ОШИБКА: не перезапустился apache2"
systemctl restart ollama || echo "ОШИБКА: не перезапустилась ollama"
echo "OK  apache2 и ollama перезапущены"
echo ""
echo "Теперь вопрос в чате в браузере, затем:"
echo "tail -1 /путь/к/сайту/storage/logs/porfiry.log"
echo "Откат:"
echo "sudo cp $BAK $REAL && sudo systemctl restart apache2"
