#!/bin/bash
# Проверка потока через Apache без Ollama и Laravel + настройки Apache и PHP.
# Запуск: sudo bash apache-check.sh /путь/к/сайту http://адрес-сайта
HERE=$(cd "$(dirname "$0")" && pwd)
SITE=$(cd "$1" 2>/dev/null && pwd)
URL=${2%/}
URL=${URL%/chat}

if [ "$(id -u)" != 0 ]; then
  echo "ОШИБКА: запустите через sudo"; exit 1
fi
if [ ! -f "$SITE/artisan" ]; then
  echo "ОШИБКА: в «$1» нет artisan — укажите путь к сайту"; exit 1
fi
if [ -z "$URL" ]; then
  echo "ОШИБКА: второе — адрес сайта, как в браузере"; exit 1
fi

TEST="$SITE/public/porfiry-stream-test.php"
cp "$HERE/stream-test.php" "$TEST" && chmod 644 "$TEST"
trap 'rm -f "$TEST"' EXIT
ID=$$
PV=$(php -r 'echo PHP_MAJOR_VERSION . "." . PHP_MINOR_VERSION;')
declare -A SIZE
for f in /var/log/apache2/*error*.log /var/log/php*-fpm.log; do
  if [ -f "$f" ]; then SIZE[$f]=$(stat -c %s "$f"); fi
done

SUM=""
run() {
  echo "== $1"
  if php "$HERE/http-client.php" "$2" "$3"; then
    echo "OK  поток идёт"
  else
    echo "ПРОБЛЕМА  поток рвётся или копится"; SUM="$SUM $4"
  fi
}
echo "Проверка идёт около 2 минут."
run "1. как чат (ndjson)" "$URL/porfiry-stream-test.php?id=$ID-1" "" 1
run "2. обычный текст" "$URL/porfiry-stream-test.php?id=$ID-2&type=plain" "" 2
run "3. пауза 70 с до первой строки" "$URL/porfiry-stream-test.php?id=$ID-3&delay=70" "" 3
run "4. с правилом для /chat/ (apache-fix.sh)" "$URL/porfiry-stream-test.php?id=$ID-5&p=/chat/" "" 4
HOST=$(echo "$URL" | sed -E 's#^[a-z]+://([^/:]+).*#\1#')
REST=$(echo "$URL" | sed -E 's#^([a-z]+)://[^/]+##')
SCHEME=$(echo "$URL" | sed -E 's#^([a-z]+)://.*#\1#')
if [ "$HOST" != 127.0.0.1 ] && [ "$HOST" != localhost ]; then
  D="$SCHEME://127.0.0.1$REST/porfiry-stream-test.php?id=$ID-4"
  run "5. напрямую в Apache на 127.0.0.1" "$D" "$HOST" 5
fi

echo "== Что видел PHP (lost — после какой строки PHP считал связь оборванной)"
grep "\"$ID-" "$SITE/storage/logs/porfiry-stream.log" 2>/dev/null || echo "записей нет"

echo "== Apache"
apache2ctl -v 2>/dev/null | head -1
M=$(apache2ctl -M 2>/dev/null)
echo "MPM: $(echo "$M" | grep -o 'mpm_[a-z]*' | head -1)"
if echo "$M" | grep -q php; then echo "PHP: модулем Apache (mod_php)"; fi
if echo "$M" | grep -q proxy_fcgi; then echo "PHP: proxy_fcgi (php-fpm)"; fi
L=""
for m in security2 qos evasive20 ratelimit http2 deflate brotli reqtimeout cache buffer sed substitute ext_filter bw lua; do
  if echo "$M" | grep -q " ${m}_module"; then L="$L $m"; fi
done
echo "Модули, которые могут влиять на поток:${L:- нет}"

echo "== Сайт в конфиге Apache"
F=$(grep -Rl -- "$SITE" /etc/apache2/sites-enabled /etc/apache2/conf-enabled 2>/dev/null)
for f in $F; do
  echo "--- $f"; grep -vE '^\s*(#|$)' "$f" | head -60
done
if [ -z "$F" ]; then echo "путь $SITE в sites-enabled и conf-enabled не найден"; fi

echo "== Общие настройки Apache"
K='^\s*(Timeout|ProxyTimeout|RequestReadTimeout|Protocols|SetOutputFilter|AddOutputFilter|SecResponseBody|SecRuleEngine)'
grep -RhiE "$K" /etc/apache2/apache2.conf /etc/apache2/conf-enabled /etc/apache2/mods-enabled /etc/apache2/sites-enabled 2>/dev/null | sort -u | head -30

echo "== public/.htaccess"
grep -vE '^\s*(#|$)' "$SITE/public/.htaccess" 2>/dev/null | head -40

echo "== PHP $PV"
K='^\s*(output_buffering|zlib.output_compression|implicit_flush|output_handler|max_execution_time|disable_functions)\s*='
for f in /etc/php/$PV/apache2/php.ini /etc/php/$PV/fpm/php.ini; do
  if [ -f "$f" ]; then echo "--- $f"; grep -hE "$K" "$f"; fi
done
K='^\s*(listen|request_terminate_timeout|php_(admin_)?(value|flag))'
grep -HE "$K" /etc/php/$PV/fpm/pool.d/*.conf 2>/dev/null

echo "== Новые строки журналов за время проверки"
for f in "${!SIZE[@]}"; do
  N=$(tail -c +$((SIZE[$f] + 1)) "$f" | tail -15)
  if [ -n "$N" ]; then echo "--- $f"; echo "$N" | cut -c1-200; fi
done

echo "ИТОГ:${SUM:+ поток рвётся в проверках$SUM}${SUM:- поток через Apache идёт}"
